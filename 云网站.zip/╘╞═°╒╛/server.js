const express = require('express');
const fileUpload = require('express-fileupload');
const path = require('path');
const fs = require('fs');
const http = require('http');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

// 设置静态文件目录
app.use(express.static(path.join(__dirname, 'public')));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// 中间件配置
app.use(express.json());
app.use(fileUpload({
  limits: {
    fileSize: 100 * 1024 * 1024, // 100MB限制
  },
  createParentPath: true
}));

// 确保uploads目录存在
const uploadsDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir);
}

// 首页路由
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// 文件上传路由
  app.post('/upload', (req, res) => {
    if (!req.files || Object.keys(req.files).length === 0) {
      return res.status(400).json({ success: false, message: '没有文件被上传' });
    }

    try {
      const file = req.files.file;
      // 确保文件名正确编码（处理中文文件名）
      const fileName = file.name;
      const uploadPath = path.join(__dirname, 'uploads', fileName);
      
      file.mv(uploadPath, (err) => {
        if (err) {
          return res.status(500).json({ success: false, message: '文件上传失败' });
        }
        
        res.json({
          success: true,
          message: '文件上传成功',
          fileName: fileName,
          filePath: `/uploads/${encodeURIComponent(fileName)}`
        });
      });
    } catch (error) {
      res.status(500).json({ success: false, message: '服务器错误' });
    }
  });

// 获取文件列表
  app.get('/files', (req, res) => {
    // 使用withFileTypes选项可以获取更多文件信息
    fs.readdir(uploadsDir, { withFileTypes: true }, (err, entries) => {
      if (err) {
        return res.status(500).json({ success: false, message: '获取文件列表失败' });
      }
      
      // 只处理文件（不包括目录）
      const files = entries.filter(entry => entry.isFile()).map(entry => entry.name);
      
      // 获取文件信息
      const fileList = files.map(file => {
        const stats = fs.statSync(path.join(uploadsDir, file));
        return {
          name: file,
          size: stats.size,
          modified: stats.mtime,
          path: `/uploads/${encodeURIComponent(file)}`
        };
      });
      
      res.json({ success: true, files: fileList });
    });
  });

// AI助手路由 (简单实现)
app.post('/ai-chat', (req, res) => {
  const { message } = req.body;
  
  // 简单的AI回复逻辑
  let response = "我是你的AI助手，请问有什么可以帮助你的吗？";
  
  if (message.includes('你好') || message.includes('嗨')) {
    response = "你好！很高兴见到你！";
  } else if (message.includes('时间') || message.includes('日期')) {
    response = `现在是 ${new Date().toLocaleString()}`;
  } else if (message.includes('帮助') || message.includes('功能')) {
    response = "我可以帮助你导航网站、回答问题、播放音乐、玩游戏，还可以上传和下载文件哦！";
  }
  
  setTimeout(() => {
    res.json({ success: true, response });
  }, 500); // 模拟AI思考时间
});

// Socket.io 连接处理
io.on('connection', (socket) => {
  console.log('用户已连接');
  
  socket.on('disconnect', () => {
    console.log('用户已断开连接');
  });
  
  // 游戏相关事件
  socket.on('game-move', (data) => {
    socket.broadcast.emit('game-move', data);
  });
  
  // 聊天相关事件
  socket.on('chat-message', (data) => {
    io.emit('chat-message', {
      user: data.user,
      message: data.message,
      time: new Date().toLocaleTimeString()
    });
  });
});

// 启动服务器
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`服务器运行在 http://localhost:${PORT}`);
});