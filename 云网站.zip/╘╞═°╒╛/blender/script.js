// 全局变量
let scene, camera, renderer;
let orbitControls, transformControls;
let selectedObject = null;
let currentTool = 'select';
let sceneObjects = [];
let nextObjectId = 1;
let history = [];
let historyIndex = -1;
let gridHelper;
let isGridVisible = true;

// DOM元素
const mainViewport = document.getElementById('main-viewport');
const objectsPanel = document.getElementById('scene-objects');
const propertiesPanel = document.getElementById('properties-panel');
const materialModal = document.getElementById('material-modal');
const materialNameInput = document.getElementById('material-name');
const materialColorInput = document.getElementById('material-color');
const materialRoughnessInput = document.getElementById('material-roughness');
const materialMetalnessInput = document.getElementById('material-metalness');
const materialOpacityInput = document.getElementById('material-opacity');
const applyMaterialBtn = document.getElementById('apply-material');
const cancelMaterialBtn = document.getElementById('cancel-material');
const closeMaterialModalBtn = document.getElementById('close-material-modal');
const addMaterialBtn = document.getElementById('add-material');
const fileImportInput = document.getElementById('file-import');

// 导入导出相关变量
let objLoader, gltfLoader, textureLoader;
let objExporter, gltfExporter;

// 雕刻相关变量
let isSculpting = false;
let brushSize = 0.1;
let brushStrength = 0.5;
let sculptMode = 'add'; // add, subtract, smooth

// 预设库相关变量
const modelPresets = [];

// 滑块视觉反馈初始化
function initSliderVisualFeedback() {
    const sliders = document.querySelectorAll('input[type="range"]');
    sliders.forEach(slider => {
        // 设置初始值
        slider.style.setProperty('--value', `${slider.value * 100}%`);
        
        // 监听值变化
        slider.addEventListener('input', function() {
            this.style.setProperty('--value', `${this.value * 100}%`);
        });
    });
}

// 初始化函数
function init() {
    // 初始化滑块视觉反馈
    initSliderVisualFeedback();
    
    // 初始化导入导出相关的加载器和导出器
    initLoadersAndExporters();
    
    // 初始化模型预设库
    initModelPresets();
    
    // 创建场景
    scene = new THREE.Scene();
    scene.background = new THREE.Color(0x1a1a1a);
    
    // 创建相机
    camera = new THREE.PerspectiveCamera(75, mainViewport.clientWidth / mainViewport.clientHeight, 0.1, 1000);
    camera.position.set(10, 10, 10);
    camera.lookAt(0, 0, 0);
    
    // 创建渲染器
    renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(mainViewport.clientWidth, mainViewport.clientHeight);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    mainViewport.appendChild(renderer.domElement);
    
    // 添加光照
    addLights();
    
    // 添加网格
    addGrid();
    
    // 添加控制器
    setupControls();
    
    // 添加事件监听
    setupEventListeners();
    
    // 初始化默认立方体
    createDefaultCube();
    
    // 开始动画循环
    animate();
}

// 添加光照
function addLights() {
    // 环境光
    const ambientLight = new THREE.AmbientLight(0x404040, 2);
    scene.add(ambientLight);
    
    // 方向光
    const directionalLight = new THREE.DirectionalLight(0xffffff, 1);
    directionalLight.position.set(10, 20, 10);
    directionalLight.castShadow = true;
    directionalLight.shadow.mapSize.width = 4096;
    directionalLight.shadow.mapSize.height = 4096;
    directionalLight.shadow.camera.near = 0.1;
    directionalLight.shadow.camera.far = 100;
    directionalLight.shadow.camera.left = -20;
    directionalLight.shadow.camera.right = 20;
    directionalLight.shadow.camera.top = 20;
    directionalLight.shadow.camera.bottom = -20;
    scene.add(directionalLight);
    
    // 辅助点光源
    const pointLight = new THREE.PointLight(0xffffff, 0.5);
    pointLight.position.set(-10, 10, -10);
    scene.add(pointLight);
}

// 添加网格
function addGrid() {
    gridHelper = new THREE.GridHelper(20, 20, 0x333333, 0x222222);
    scene.add(gridHelper);
}

// 设置控制器
function setupControls() {
    // 轨道控制器
    orbitControls = new THREE.OrbitControls(camera, renderer.domElement);
    orbitControls.enableDamping = true;
    orbitControls.dampingFactor = 0.1;
    orbitControls.rotateSpeed = 0.5;
    orbitControls.zoomSpeed = 0.5;
    orbitControls.enablePan = true;
    
    // 变换控制器
    transformControls = new THREE.TransformControls(camera, renderer.domElement);
    transformControls.addEventListener('change', render);
    transformControls.addEventListener('dragging-changed', function (event) {
        orbitControls.enabled = !event.value;
    });
    scene.add(transformControls);
    transformControls.visible = false;
}

// 设置事件监听
function setupEventListeners() {
    // 窗口大小变化
    window.addEventListener('resize', onWindowResize);
    
    // 工具按钮点击
    document.querySelectorAll('.tool-button[data-tool]').forEach(button => {
        button.addEventListener('click', function() {
            document.querySelectorAll('.tool-button[data-tool]').forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            currentTool = this.getAttribute('data-tool');
            updateTransformControls();
        });
    });
    
    // 形状按钮点击
    document.querySelectorAll('.tool-button[data-shape]').forEach(button => {
        button.addEventListener('click', function() {
            const shape = this.getAttribute('data-shape');
            createShape(shape);
        });
    });
    
    // 材质按钮点击
    document.getElementById('add-material').addEventListener('click', function() {
        if (selectedObject) {
            openMaterialEditor();
        }
    });
    
    // 视图切换
    document.getElementById('top-view').addEventListener('click', () => setView('top'));
    document.getElementById('front-view').addEventListener('click', () => setView('front'));
    document.getElementById('side-view').addEventListener('click', () => setView('side'));
    document.getElementById('perspective-view').addEventListener('click', () => setView('perspective'));
    
    // 网格切换
    document.getElementById('toggle-grid').addEventListener('click', toggleGrid);
    
    // 模态框按钮
    document.getElementById('close-material-modal').addEventListener('click', closeMaterialEditor);
    document.getElementById('cancel-material').addEventListener('click', closeMaterialEditor);
    document.getElementById('apply-material').addEventListener('click', applyMaterial);
    
    // 右键菜单
    mainViewport.addEventListener('contextmenu', function(e) {
        e.preventDefault();
    });
    
    // 点击选择对象
    mainViewport.addEventListener('click', onViewportClick);
    
    // 撤销重做
    document.getElementById('undo').addEventListener('click', undo);
    document.getElementById('redo').addEventListener('click', redo);
    
    // 删除
    document.getElementById('delete').addEventListener('click', deleteSelected);
    
    // 全选
    document.addEventListener('keydown', function(e) {
        if (e.ctrlKey && e.key === 'a') {
            e.preventDefault();
            selectAll();
        }
    });
    
    // 文件导入导出相关
    const importModelBtn = document.getElementById('import-model');
    if (importModelBtn) {
        importModelBtn.addEventListener('click', function() {
            document.getElementById('file-import').click();
        });
    }
    
    const fileImport = document.getElementById('file-import');
    if (fileImport) {
        fileImport.addEventListener('change', handleFileImport);
    }
    
    const exportImageBtn = document.getElementById('export-image');
    if (exportImageBtn) {
        exportImageBtn.addEventListener('click', exportImage);
    }
    
    const exportModelObjBtn = document.getElementById('export-model-obj');
    if (exportModelObjBtn) {
        exportModelObjBtn.addEventListener('click', function() {
            exportModel('obj');
        });
    }
    
    const exportModelGltfBtn = document.getElementById('export-model-gltf');
    if (exportModelGltfBtn) {
        exportModelGltfBtn.addEventListener('click', function() {
            exportModel('gltf');
        });
    }
    
    // 纹理导入
    const addMaterialBtn = document.getElementById('add-material');
    const textureImport = document.getElementById('texture-import');
    if (addMaterialBtn && textureImport) {
        addMaterialBtn.addEventListener('click', function() {
            // 保留原有功能并添加纹理选择
            if (selectedObject) {
                openMaterialEditor();
            }
            textureImport.click();
        });
        
        textureImport.addEventListener('change', loadTexture);
    }
    
    // 雕刻相关
    const toggleSculptModeBtn = document.getElementById('toggle-sculpt-mode');
    if (toggleSculptModeBtn) {
        toggleSculptModeBtn.addEventListener('click', toggleSculptMode);
    }
    
    const brushSizeSlider = document.getElementById('brush-size');
    const brushSizeValue = document.getElementById('brush-size-value');
    if (brushSizeSlider && brushSizeValue) {
        brushSizeSlider.addEventListener('input', function() {
            setBrushSize(parseFloat(this.value));
            brushSizeValue.textContent = this.value;
        });
    }
    
    const brushStrengthSlider = document.getElementById('brush-strength');
    const brushStrengthValue = document.getElementById('brush-strength-value');
    if (brushStrengthSlider && brushStrengthValue) {
        brushStrengthSlider.addEventListener('input', function() {
            setBrushStrength(parseFloat(this.value));
            brushStrengthValue.textContent = Math.round(this.value * 100) + '%';
        });
    }
    
    const resetSculptBtn = document.getElementById('reset-sculpt');
    if (resetSculptBtn) {
        resetSculptBtn.addEventListener('click', resetSculpting);
    }
    
    // 渲染相关
    const setupAdvancedRenderingBtn = document.getElementById('setup-advanced-rendering');
    if (setupAdvancedRenderingBtn) {
        setupAdvancedRenderingBtn.addEventListener('click', setupAdvancedRendering);
    }
    
    const renderHighResBtn = document.getElementById('render-high-res');
    if (renderHighResBtn) {
        renderHighResBtn.addEventListener('click', function() {
            renderHighResolution(2048, 1536); // 默认高分辨率
        });
    }
    
    // 3D视图鼠标事件
    if (mainViewport) {
        mainViewport.addEventListener('mousedown', function(event) {
            if (isSculpting) {
                performSculpting(event);
            }
        });
        
        mainViewport.addEventListener('mousemove', function(event) {
            if (isSculpting && event.buttons === 1) { // 左键按下时
                performSculpting(event);
            }
        });
    }
}

// 创建默认立方体
function createDefaultCube() {
    const geometry = new THREE.BoxGeometry(2, 2, 2);
    const material = new THREE.MeshStandardMaterial({
        color: 0xff0000,
        roughness: 0.5,
        metalness: 0
    });
    const cube = new THREE.Mesh(geometry, material);
    cube.name = '立方体' + nextObjectId++;
    cube.userData = {
        id: cube.name,
        type: 'cube',
        properties: {
            position: { x: 0, y: 1, z: 0 },
            rotation: { x: 0, y: 0, z: 0 },
            scale: { x: 1, y: 1, z: 1 },
            color: 0xff0000,
            roughness: 0.5,
            metalness: 0
        }
    };
    cube.position.set(0, 1, 0);
    cube.castShadow = true;
    cube.receiveShadow = true;
    scene.add(cube);
    sceneObjects.push(cube);
    updateObjectsPanel();
    saveState();
}

// 创建形状
function createShape(type) {
    let geometry;
    let name;
    
    switch(type) {
        case 'cube':
            geometry = new THREE.BoxGeometry(2, 2, 2);
            name = '立方体' + nextObjectId++;
            break;
        case 'sphere':
            geometry = new THREE.SphereGeometry(1, 32, 32);
            name = '球体' + nextObjectId++;
            break;
        case 'cylinder':
            geometry = new THREE.CylinderGeometry(0.5, 0.5, 2, 32);
            name = '圆柱体' + nextObjectId++;
            break;
        case 'plane':
            geometry = new THREE.PlaneGeometry(4, 4);
            name = '平面' + nextObjectId++;
            break;
    }
    
    const material = new THREE.MeshStandardMaterial({
        color: Math.floor(Math.random() * 16777215),
        roughness: 0.5,
        metalness: 0
    });
    
    const mesh = new THREE.Mesh(geometry, material);
    mesh.name = name;
    mesh.userData = {
        id: name,
        type: type,
        properties: {
            position: { x: 0, y: 1, z: 0 },
            rotation: { x: 0, y: 0, z: 0 },
            scale: { x: 1, y: 1, z: 1 },
            color: material.color.getHex(),
            roughness: material.roughness,
            metalness: material.metalness
        }
    };
    
    // 随机位置，避免重叠
    const offset = sceneObjects.length * 2.5;
    mesh.position.set(offset % 3 === 0 ? 0 : offset % 3 === 1 ? 3 : -3, 1, Math.floor(offset / 3) * 3);
    
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    scene.add(mesh);
    sceneObjects.push(mesh);
    
    // 选中新创建的对象
    selectObject(mesh);
    
    updateObjectsPanel();
    saveState();
}

// 选择对象
function selectObject(object) {
    // 取消当前选中
    if (selectedObject) {
        selectedObject.material.emissive.setHex(0x000000);
    }
    
    // 选中新对象
    selectedObject = object;
    if (selectedObject) {
        selectedObject.material.emissive.setHex(0x222222);
        transformControls.attach(selectedObject);
        updateTransformControls();
        updatePropertiesPanel();
    } else {
        transformControls.detach();
        propertiesPanel.innerHTML = '<p style="text-align: center; color: #999;">未选中任何对象</p>';
    }
    
    updateObjectsPanel();
    updateStatusBar();
}

// 选择所有对象
function selectAll() {
    // 简化版，只支持单选
    // 在实际应用中可以扩展为支持多选
}

// 取消选择
function deselectObject() {
    selectObject(null);
}

// 更新变换控制器
function updateTransformControls() {
    if (!selectedObject) return;
    
    switch(currentTool) {
        case 'move':
            transformControls.setMode('translate');
            break;
        case 'rotate':
            transformControls.setMode('rotate');
            break;
        case 'scale':
            transformControls.setMode('scale');
            break;
        default:
            transformControls.setMode('translate');
    }
    
    transformControls.visible = selectedObject !== null;
}

// 更新对象面板
function updateObjectsPanel() {
    objectsPanel.innerHTML = '';
    
    if (sceneObjects.length === 0) {
        objectsPanel.innerHTML = '<p style="text-align: center; color: #999;">场景中无对象</p>';
        return;
    }
    
    sceneObjects.forEach(object => {
        const item = document.createElement('div');
        item.className = 'object-item' + (selectedObject === object ? ' selected' : '');
        item.innerHTML = `
            <span>${object.name}</span>
            <span>(${object.userData.type})</span>
        `;
        item.addEventListener('click', () => selectObject(object));
        objectsPanel.appendChild(item);
    });
}

// 更新属性面板
function updatePropertiesPanel() {
    if (!selectedObject) {
        propertiesPanel.innerHTML = '<p style="text-align: center; color: #999;">未选中任何对象</p>';
        return;
    }
    
    const props = selectedObject.userData.properties;
    
    propertiesPanel.innerHTML = `
        <div class="panel-section">
            <div class="section-title">基本属性</div>
            <div class="form-group">
                <label>名称</label>
                <input type="text" id="prop-name" value="${selectedObject.name}">
            </div>
        </div>
        
        <div class="panel-section">
            <div class="section-title">变换</div>
            
            <div class="form-group">
                <label>位置 X</label>
                <input type="number" id="prop-position-x" step="0.1" value="${selectedObject.position.x.toFixed(2)}">
            </div>
            <div class="form-group">
                <label>位置 Y</label>
                <input type="number" id="prop-position-y" step="0.1" value="${selectedObject.position.y.toFixed(2)}">
            </div>
            <div class="form-group">
                <label>位置 Z</label>
                <input type="number" id="prop-position-z" step="0.1" value="${selectedObject.position.z.toFixed(2)}">
            </div>
            
            <div class="form-group">
                <label>旋转 X</label>
                <input type="number" id="prop-rotation-x" step="0.1" value="${(selectedObject.rotation.x * 180 / Math.PI).toFixed(2)}">
            </div>
            <div class="form-group">
                <label>旋转 Y</label>
                <input type="number" id="prop-rotation-y" step="0.1" value="${(selectedObject.rotation.y * 180 / Math.PI).toFixed(2)}">
            </div>
            <div class="form-group">
                <label>旋转 Z</label>
                <input type="number" id="prop-rotation-z" step="0.1" value="${(selectedObject.rotation.z * 180 / Math.PI).toFixed(2)}">
            </div>
            
            <div class="form-group">
                <label>缩放 X</label>
                <input type="number" id="prop-scale-x" step="0.1" value="${selectedObject.scale.x.toFixed(2)}">
            </div>
            <div class="form-group">
                <label>缩放 Y</label>
                <input type="number" id="prop-scale-y" step="0.1" value="${selectedObject.scale.y.toFixed(2)}">
            </div>
            <div class="form-group">
                <label>缩放 Z</label>
                <input type="number" id="prop-scale-z" step="0.1" value="${selectedObject.scale.z.toFixed(2)}">
            </div>
        </div>
        
        <div class="panel-section">
            <div class="section-title">材质</div>
            <div class="form-group">
                <label>颜色</label>
                <input type="color" id="prop-color" value="#${props.color.toString(16).padStart(6, '0')}">
            </div>
            <div class="form-group">
                <label>粗糙度</label>
                <input type="range" id="prop-roughness" min="0" max="1" step="0.01" value="${props.roughness}">
            </div>
            <div class="form-group">
                <label>金属度</label>
                <input type="range" id="prop-metalness" min="0" max="1" step="0.01" value="${props.metalness}">
            </div>
        </div>
    `;
    
    // 添加事件监听
    document.getElementById('prop-name').addEventListener('change', function() {
        selectedObject.name = this.value;
        updateObjectsPanel();
        saveState();
    });
    
    // 位置
    document.getElementById('prop-position-x').addEventListener('change', function() {
        selectedObject.position.x = parseFloat(this.value);
        saveState();
    });
    document.getElementById('prop-position-y').addEventListener('change', function() {
        selectedObject.position.y = parseFloat(this.value);
        saveState();
    });
    document.getElementById('prop-position-z').addEventListener('change', function() {
        selectedObject.position.z = parseFloat(this.value);
        saveState();
    });
    
    // 旋转
    document.getElementById('prop-rotation-x').addEventListener('change', function() {
        selectedObject.rotation.x = parseFloat(this.value) * Math.PI / 180;
        saveState();
    });
    document.getElementById('prop-rotation-y').addEventListener('change', function() {
        selectedObject.rotation.y = parseFloat(this.value) * Math.PI / 180;
        saveState();
    });
    document.getElementById('prop-rotation-z').addEventListener('change', function() {
        selectedObject.rotation.z = parseFloat(this.value) * Math.PI / 180;
        saveState();
    });
    
    // 缩放
    document.getElementById('prop-scale-x').addEventListener('change', function() {
        selectedObject.scale.x = parseFloat(this.value);
        saveState();
    });
    document.getElementById('prop-scale-y').addEventListener('change', function() {
        selectedObject.scale.y = parseFloat(this.value);
        saveState();
    });
    document.getElementById('prop-scale-z').addEventListener('change', function() {
        selectedObject.scale.z = parseFloat(this.value);
        saveState();
    });
    
    // 材质
    document.getElementById('prop-color').addEventListener('change', function() {
        selectedObject.material.color.set(this.value);
        selectedObject.userData.properties.color = parseInt(this.value.substring(1), 16);
        saveState();
    });
    document.getElementById('prop-roughness').addEventListener('input', function() {
        selectedObject.material.roughness = parseFloat(this.value);
        selectedObject.userData.properties.roughness = parseFloat(this.value);
    });
    document.getElementById('prop-roughness').addEventListener('change', function() {
        saveState();
    });
    document.getElementById('prop-metalness').addEventListener('input', function() {
        selectedObject.material.metalness = parseFloat(this.value);
        selectedObject.userData.properties.metalness = parseFloat(this.value);
    });
    document.getElementById('prop-metalness').addEventListener('change', function() {
        saveState();
    });
}

// 打开材质编辑器
function openMaterialEditor() {
    if (!selectedObject) return;
    
    const props = selectedObject.userData.properties;
    materialNameInput.value = selectedObject.name + '_材质';
    materialColorInput.value = '#' + props.color.toString(16).padStart(6, '0');
    materialRoughnessInput.value = props.roughness;
    materialMetalnessInput.value = props.metalness;
    materialOpacityInput.value = selectedObject.material.opacity || 1;
    
    materialModal.style.display = 'flex';
}

// 关闭材质编辑器
function closeMaterialEditor() {
    materialModal.style.display = 'none';
}

// 应用材质
function applyMaterial() {
    if (!selectedObject) return;
    
    selectedObject.material.color.set(materialColorInput.value);
    selectedObject.material.roughness = parseFloat(materialRoughnessInput.value);
    selectedObject.material.metalness = parseFloat(materialMetalnessInput.value);
    selectedObject.material.opacity = parseFloat(materialOpacityInput.value);
    selectedObject.material.transparent = selectedObject.material.opacity < 1;
    
    // 更新属性
    selectedObject.userData.properties.color = parseInt(materialColorInput.value.substring(1), 16);
    selectedObject.userData.properties.roughness = parseFloat(materialRoughnessInput.value);
    selectedObject.userData.properties.metalness = parseFloat(materialMetalnessInput.value);
    
    closeMaterialEditor();
    updatePropertiesPanel();
    saveState();
}

// 窗口大小变化处理
function onWindowResize() {
    camera.aspect = mainViewport.clientWidth / mainViewport.clientHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(mainViewport.clientWidth, mainViewport.clientHeight);
}

// 视图点击处理
function onViewportClick(event) {
    event.preventDefault();
    
    // 计算鼠标在视口中的位置
    const rect = mainViewport.getBoundingClientRect();
    const mouse = new THREE.Vector2(
        ((event.clientX - rect.left) / rect.width) * 2 - 1,
        -((event.clientY - rect.top) / rect.height) * 2 + 1
    );
    
    // 创建射线投射器
    const raycaster = new THREE.Raycaster();
    raycaster.setFromCamera(mouse, camera);
    
    // 射线与场景中的物体相交
    const intersects = raycaster.intersectObjects(sceneObjects, true);
    
    if (intersects.length > 0) {
        // 找到最顶层的物体
        let selected = intersects[0].object;
        // 找到父级网格对象
        while (selected.parent && !(selected instanceof THREE.Mesh)) {
            selected = selected.parent;
        }
        selectObject(selected);
    } else {
        deselectObject();
    }
}

// 设置视图
function setView(view) {
    switch(view) {
        case 'top':
            camera.position.set(0, 20, 0);
            camera.lookAt(0, 0, 0);
            orbitControls.target.set(0, 0, 0);
            break;
        case 'front':
            camera.position.set(0, 10, 20);
            camera.lookAt(0, 10, 0);
            orbitControls.target.set(0, 10, 0);
            break;
        case 'side':
            camera.position.set(20, 10, 0);
            camera.lookAt(0, 10, 0);
            orbitControls.target.set(0, 10, 0);
            break;
        case 'perspective':
            camera.position.set(10, 10, 10);
            camera.lookAt(0, 0, 0);
            orbitControls.target.set(0, 0, 0);
            break;
    }
    
    orbitControls.update();
    render();
}

// 切换网格显示
function toggleGrid() {
    isGridVisible = !isGridVisible;
    gridHelper.visible = isGridVisible;
    document.querySelector('.status-item:nth-child(1)').textContent = `网格: ${isGridVisible ? '显示' : '隐藏'}`;
    render();
}

// 删除选中对象
function deleteSelected() {
    if (!selectedObject) return;
    
    // 从场景中移除
    scene.remove(selectedObject);
    
    // 从数组中移除
    const index = sceneObjects.indexOf(selectedObject);
    if (index > -1) {
        sceneObjects.splice(index, 1);
    }
    
    // 取消选中
    selectObject(null);
    
    // 更新面板
    updateObjectsPanel();
    updateStatusBar();
    
    saveState();
}

// 更新状态栏
function updateStatusBar() {
    const selectedCount = selectedObject ? 1 : 0;
    const vertexCount = selectedObject ? getVertexCount(selectedObject) : 0;
    const faceCount = selectedObject ? getFaceCount(selectedObject) : 0;
    
    document.querySelector('.status-item:nth-child(2)').textContent = `选中: ${selectedCount}`;
    document.querySelector('.status-item:nth-child(3)').textContent = `顶点: ${vertexCount}`;
    document.querySelector('.status-item:nth-child(4)').textContent = `面: ${faceCount}`;
}

// 获取顶点数量
function getVertexCount(mesh) {
    if (!mesh.geometry) return 0;
    return mesh.geometry.attributes.position.count;
}

// 获取面数量
function getFaceCount(mesh) {
    if (!mesh.geometry) return 0;
    if (mesh.geometry.index) {
        return mesh.geometry.index.count / 3;
    } else {
        return mesh.geometry.attributes.position.count / 3;
    }
}

// 保存状态（用于撤销/重做）
function saveState() {
    // 保存场景状态
    const state = {
        objects: sceneObjects.map(obj => ({
            id: obj.name,
            type: obj.userData.type,
            position: { x: obj.position.x, y: obj.position.y, z: obj.position.z },
            rotation: { x: obj.rotation.x, y: obj.rotation.y, z: obj.rotation.z },
            scale: { x: obj.scale.x, y: obj.scale.y, z: obj.scale.z },
            properties: { ...obj.userData.properties }
        })),
        selectedObjectId: selectedObject ? selectedObject.name : null
    };
    
    // 移除当前状态之后的历史
    if (historyIndex < history.length - 1) {
        history = history.slice(0, historyIndex + 1);
    }
    
    // 添加新状态
    history.push(state);
    historyIndex = history.length - 1;
    
    // 限制历史记录数量
    if (history.length > 50) {
        history.shift();
        historyIndex--;
    }
}

// 撤销
function undo() {
    if (historyIndex <= 0) return;
    
    historyIndex--;
    restoreState(history[historyIndex]);
}

// 重做
function redo() {
    if (historyIndex >= history.length - 1) return;
    
    historyIndex++;
    restoreState(history[historyIndex]);
}

// 恢复状态
function restoreState(state) {
    // 清空场景
    sceneObjects.forEach(obj => scene.remove(obj));
    sceneObjects = [];
    
    // 重建对象
    state.objects.forEach(objData => {
        let geometry;
        
        switch(objData.type) {
            case 'cube':
                geometry = new THREE.BoxGeometry(2, 2, 2);
                break;
            case 'sphere':
                geometry = new THREE.SphereGeometry(1, 32, 32);
                break;
            case 'cylinder':
                geometry = new THREE.CylinderGeometry(0.5, 0.5, 2, 32);
                break;
            case 'plane':
                geometry = new THREE.PlaneGeometry(4, 4);
                break;
        }
        
        const material = new THREE.MeshStandardMaterial({
            color: objData.properties.color,
            roughness: objData.properties.roughness,
            metalness: objData.properties.metalness,
            transparent: objData.properties.opacity < 1,
            opacity: objData.properties.opacity || 1
        });
        
        const mesh = new THREE.Mesh(geometry, material);
        mesh.name = objData.id;
        mesh.userData = {
            id: objData.id,
            type: objData.type,
            properties: { ...objData.properties }
        };
        
        mesh.position.set(objData.position.x, objData.position.y, objData.position.z);
        mesh.rotation.set(objData.rotation.x, objData.rotation.y, objData.rotation.z);
        mesh.scale.set(objData.scale.x, objData.scale.y, objData.scale.z);
        
        mesh.castShadow = true;
        mesh.receiveShadow = true;
        scene.add(mesh);
        sceneObjects.push(mesh);
    });
    
    // 恢复选中状态
    let newSelectedObject = null;
    if (state.selectedObjectId) {
        newSelectedObject = sceneObjects.find(obj => obj.name === state.selectedObjectId);
    }
    selectObject(newSelectedObject);
    
    // 更新面板
    updateObjectsPanel();
    updateStatusBar();
}

// 渲染
function render() {
    renderer.render(scene, camera);
}

// 动画循环
function animate() {
    requestAnimationFrame(animate);
    orbitControls.update();
    render();
}

// 初始化加载器和导出器
function initLoadersAndExporters() {
    // 加载器
    objLoader = new THREE.OBJLoader();
    gltfLoader = new THREE.GLTFLoader();
    textureLoader = new THREE.TextureLoader();
    
    // 导出器
    objExporter = new THREE.OBJExporter();
    gltfExporter = new THREE.GLTFExporter();
}

// 处理文件导入
function handleFileImport(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    const reader = new FileReader();
    const fileExtension = file.name.split('.').pop().toLowerCase();
    
    reader.onload = function(event) {
        const content = event.target.result;
        
        try {
            if (fileExtension === 'obj') {
                // 导入OBJ文件
                objLoader.parse(content, function(object) {
                    object.traverse(function(child) {
                        if (child.isMesh) {
                            child.material = new THREE.MeshStandardMaterial({
                                color: 0x777777,
                                metalness: 0.1,
                                roughness: 0.7
                            });
                        }
                    });
                    
                    // 设置对象名称
                    object.name = file.name.replace('.obj', '');
                    
                    // 添加到场景
                    scene.add(object);
                    sceneObjects.push(object);
                    
                    // 选中新添加的对象
                    selectObject(object);
                    
                    // 更新对象面板
                    updateObjectsPanel();
                    
                    // 显示导入成功消息
                    updateStatusBar(`已成功导入模型: ${file.name}`);
                });
            } else if (fileExtension === 'gltf' || fileExtension === 'glb') {
                // 导入GLTF/GLB文件
                const url = URL.createObjectURL(new Blob([content]));
                gltfLoader.load(url, function(gltf) {
                    const object = gltf.scene;
                    
                    // 设置对象名称
                    object.name = file.name.replace(/\.gltf$|\.glb$/, '');
                    
                    // 添加到场景
                    scene.add(object);
                    sceneObjects.push(object);
                    
                    // 选中新添加的对象
                    selectObject(object);
                    
                    // 更新对象面板
                    updateObjectsPanel();
                    
                    // 显示导入成功消息
                    updateStatusBar(`已成功导入模型: ${file.name}`);
                    
                    // 释放URL对象
                    URL.revokeObjectURL(url);
                }, undefined, function(error) {
                    console.error('GLTF加载错误:', error);
                    updateStatusBar(`导入失败: ${error.message}`);
                    URL.revokeObjectURL(url);
                });
            } else {
                updateStatusBar('不支持的文件格式。请导入.OBJ、.GLTF或.GLB文件。');
            }
        } catch (error) {
            console.error('文件导入错误:', error);
            updateStatusBar(`导入失败: ${error.message}`);
        }
    };
    
    if (fileExtension === 'obj') {
        reader.readAsText(file);
    } else if (fileExtension === 'gltf' || fileExtension === 'glb') {
        reader.readAsArrayBuffer(file);
    }
    
    // 重置文件输入
    event.target.value = '';
}

// 导出图片
function exportImage() {
    // 创建渲染目标
    const renderTarget = new THREE.WebGLRenderTarget(
        renderer.domElement.width * 2, 
        renderer.domElement.height * 2
    );
    
    // 渲染到目标
    renderer.setRenderTarget(renderTarget);
    renderer.render(scene, camera);
    renderer.setRenderTarget(null);
    
    // 将渲染结果转换为图片
    const canvas = document.createElement('canvas');
    const context = canvas.getContext('2d');
    canvas.width = renderTarget.width;
    canvas.height = renderTarget.height;
    
    // 获取图像数据
    const imageData = new ImageData(
        new Uint8ClampedArray(renderTarget.width * renderTarget.height * 4),
        renderTarget.width,
        renderTarget.height
    );
    
    // 读取像素数据
    renderer.readRenderTargetPixels(
        renderTarget, 
        0, 0, 
        renderTarget.width, renderTarget.height, 
        imageData.data
    );
    
    context.putImageData(imageData, 0, 0);
    
    // 下载图片
    const link = document.createElement('a');
    link.download = 'blender-model-' + new Date().toISOString().slice(0, 10) + '.png';
    link.href = canvas.toDataURL('image/png');
    link.click();
    
    // 清理
    renderTarget.dispose();
    updateStatusBar('已成功导出图片');
}

// 导出模型
function exportModel(format) {
    if (!selectedObject) {
        updateStatusBar('请先选择要导出的对象');
        return;
    }
    
    try {
        if (format === 'obj') {
            // 导出为OBJ
            const data = objExporter.parse(selectedObject);
            const blob = new Blob([data], { type: 'text/plain' });
            const url = URL.createObjectURL(blob);
            
            const link = document.createElement('a');
            link.href = url;
            link.download = selectedObject.name + '.obj';
            link.click();
            
            URL.revokeObjectURL(url);
        } else if (format === 'gltf') {
            // 导出为GLTF
            gltfExporter.parse(selectedObject, function(result) {
                let blob;
                if (typeof result === 'object') {
                    blob = new Blob([JSON.stringify(result)], { type: 'application/json' });
                } else {
                    blob = new Blob([result], { type: 'application/octet-stream' });
                }
                
                const url = URL.createObjectURL(blob);
                const link = document.createElement('a');
                link.href = url;
                link.download = selectedObject.name + '.gltf';
                link.click();
                
                URL.revokeObjectURL(url);
            }, { binary: false });
        }
        
        updateStatusBar(`已成功导出模型为${format.toUpperCase()}格式`);
    } catch (error) {
        console.error('导出错误:', error);
        updateStatusBar(`导出失败: ${error.message}`);
    }
}

// 切换雕刻模式
function toggleSculptMode() {
    isSculpting = !isSculpting;
    
    if (isSculpting) {
        if (!selectedObject || !selectedObject.isMesh) {
            updateStatusBar('请先选择一个网格对象进行雕刻');
            isSculpting = false;
            return;
        }
        
        // 确保几何体有顶点法线和UV
        if (!selectedObject.geometry.attributes.normal) {
            selectedObject.geometry.computeVertexNormals();
        }
        
        // 进入雕刻模式
        document.getElementById('viewport').style.cursor = 'crosshair';
        updateStatusBar('已进入雕刻模式 - 笔刷大小: ' + brushSize + ', 强度: ' + (brushStrength * 100) + '%');
    } else {
        // 退出雕刻模式
        document.getElementById('viewport').style.cursor = 'default';
        updateStatusBar('已退出雕刻模式');
    }
}

// 设置雕刻笔刷大小
function setBrushSize(size) {
    brushSize = Math.max(0.01, Math.min(10, size));
    if (isSculpting) {
        updateStatusBar('雕刻模式 - 笔刷大小: ' + brushSize + ', 强度: ' + (brushStrength * 100) + '%');
    }
}

// 设置雕刻笔刷强度
function setBrushStrength(strength) {
    brushStrength = Math.max(0, Math.min(1, strength));
    if (isSculpting) {
        updateStatusBar('雕刻模式 - 笔刷大小: ' + brushSize + ', 强度: ' + (brushStrength * 100) + '%');
    }
}

// 执行雕刻操作
function performSculpting(event) {
    if (!isSculpting || !selectedObject || !selectedObject.isMesh) return;
    
    const rect = renderer.domElement.getBoundingClientRect();
    const mouseX = ((event.clientX - rect.left) / rect.width) * 2 - 1;
    const mouseY = -((event.clientY - rect.top) / rect.height) * 2 + 1;
    
    const raycaster = new THREE.Raycaster();
    raycaster.setFromCamera({ x: mouseX, y: mouseY }, camera);
    
    const intersects = raycaster.intersectObject(selectedObject, true);
    
    if (intersects.length > 0) {
        const intersect = intersects[0];
        const point = intersect.point;
        const faceIndex = intersect.faceIndex;
        const object = intersect.object;
        
        // 获取几何体
        const geometry = object.geometry;
        const positionAttribute = geometry.attributes.position;
        const normalAttribute = geometry.attributes.normal;
        
        // 确保几何体是可写的
        if (positionAttribute.isInterleavedBufferAttribute) {
            updateStatusBar('无法在交错缓冲区上进行雕刻操作');
            isSculpting = false;
            return;
        }
        
        // 使几何体可写
        geometry.setFromPoints(Array.from({ length: positionAttribute.count }, (_, i) =>
            new THREE.Vector3(
                positionAttribute.getX(i),
                positionAttribute.getY(i),
                positionAttribute.getZ(i)
            )
        ));
        
        // 复制原始顶点数据用于撤销操作
        if (!originalVertices) {
            originalVertices = Array.from({ length: positionAttribute.count }, (_, i) =>
                new THREE.Vector3(
                    positionAttribute.getX(i),
                    positionAttribute.getY(i),
                    positionAttribute.getZ(i)
                )
            );
        }
        
        // 影响范围内的所有顶点
        const影响Radius = brushSize * 0.5;
        const strength = brushStrength * 0.1;
        
        for (let i = 0; i < positionAttribute.count; i++) {
            const vertex = new THREE.Vector3(
                positionAttribute.getX(i),
                positionAttribute.getY(i),
                positionAttribute.getZ(i)
            );
            
            const distance = vertex.distanceTo(point);
            
            if (distance < 影响Radius) {
                // 计算影响因子
                const falloff = 1 - distance / 影响Radius;
                const pushDistance = strength * falloff;
                
                // 获取法线方向
                const normal = new THREE.Vector3(
                    normalAttribute.getX(i),
                    normalAttribute.getY(i),
                    normalAttribute.getZ(i)
                );
                
                // 沿法线方向移动顶点
                vertex.add(normal.multiplyScalar(pushDistance));
                
                // 更新顶点位置
                positionAttribute.setXYZ(i, vertex.x, vertex.y, vertex.z);
            }
        }
        
        // 标记几何体为需要更新
        positionAttribute.needsUpdate = true;
        
        // 重新计算法线
        geometry.computeVertexNormals();
        normalAttribute.needsUpdate = true;
        
        // 触发渲染
        render();
    }
}

// 重置雕刻操作
function resetSculpting() {
    if (!selectedObject || !selectedObject.isMesh || !originalVertices) return;
    
    const geometry = selectedObject.geometry;
    const positionAttribute = geometry.attributes.position;
    
    // 恢复原始顶点位置
    for (let i = 0; i < Math.min(originalVertices.length, positionAttribute.count); i++) {
        const vertex = originalVertices[i];
        positionAttribute.setXYZ(i, vertex.x, vertex.y, vertex.z);
    }
    
    positionAttribute.needsUpdate = true;
    
    // 重新计算法线
    geometry.computeVertexNormals();
    geometry.attributes.normal.needsUpdate = true;
    
    // 清理原始顶点数据
    originalVertices = null;
    
    // 触发渲染
    render();
    updateStatusBar('已重置雕刻操作');
}

// 更新着色器材质
function updateShaderMaterial(materialType, params) {
    if (!selectedObject || !selectedObject.isMesh) return;
    
    let material;
    
    switch(materialType) {
        case 'standard':
            material = new THREE.MeshStandardMaterial({
                color: params.color || 0x777777,
                metalness: params.metalness || 0.1,
                roughness: params.roughness || 0.7,
                transparent: params.transparent || false,
                opacity: params.opacity || 1.0,
                side: params.side || THREE.FrontSide
            });
            break;
        case 'phong':
            material = new THREE.MeshPhongMaterial({
                color: params.color || 0x777777,
                shininess: params.shininess || 30,
                specular: params.specular || 0x111111,
                transparent: params.transparent || false,
                opacity: params.opacity || 1.0,
                side: params.side || THREE.FrontSide
            });
            break;
        case 'basic':
            material = new THREE.MeshBasicMaterial({
                color: params.color || 0x777777,
                wireframe: params.wireframe || false,
                transparent: params.transparent || false,
                opacity: params.opacity || 1.0,
                side: params.side || THREE.FrontSide
            });
            break;
        case 'lambert':
            material = new THREE.MeshLambertMaterial({
                color: params.color || 0x777777,
                transparent: params.transparent || false,
                opacity: params.opacity || 1.0,
                side: params.side || THREE.FrontSide
            });
            break;
        default:
            material = new THREE.MeshStandardMaterial({
                color: 0x777777,
                metalness: 0.1,
                roughness: 0.7
            });
    }
    
    // 应用材质到选中对象
    selectedObject.material = material;
    
    // 如果有纹理，应用纹理
    if (params.textureUrl) {
        textureLoader.load(params.textureUrl, function(texture) {
            selectedObject.material.map = texture;
            selectedObject.material.needsUpdate = true;
            render();
        });
    }
    
    render();
    updateStatusBar(`已应用${materialType}材质`);
}

// 加载纹理
function loadTexture(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = function(event) {
        const textureUrl = event.target.result;
        
        if (selectedObject && selectedObject.isMesh) {
            textureLoader.load(textureUrl, function(texture) {
                selectedObject.material.map = texture;
                selectedObject.material.needsUpdate = true;
                render();
                updateStatusBar(`已加载纹理: ${file.name}`);
            });
        }
    };
    
    reader.readAsDataURL(file);
    event.target.value = '';
}

// 设置环境光
function setAmbientLight(intensity, color) {
    ambientLight.intensity = intensity;
    ambientLight.color.setHex(color);
    render();
    updateStatusBar(`环境光设置: 强度 ${intensity}, 颜色 #${color.toString(16).padStart(6, '0')}`);
}

// 设置方向光
function setDirectionalLight(intensity, color, x, y, z) {
    directionalLight.intensity = intensity;
    directionalLight.color.setHex(color);
    directionalLight.position.set(x, y, z);
    render();
    updateStatusBar(`方向光设置: 强度 ${intensity}, 颜色 #${color.toString(16).padStart(6, '0')}`);
}

// 高级渲染设置
function setupAdvancedRendering() {
    // 启用阴影
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    
    // 为灯光启用阴影
    directionalLight.castShadow = true;
    directionalLight.shadow.mapSize.width = 2048;
    directionalLight.shadow.mapSize.height = 2048;
    directionalLight.shadow.camera.near = 0.5;
    directionalLight.shadow.camera.far = 50;
    
    // 为网格对象启用接收阴影
    sceneObjects.forEach(object => {
        if (object.isMesh) {
            object.castShadow = true;
            object.receiveShadow = true;
        }
    });
    
    // 为地面网格启用接收阴影
    if (gridHelper) {
        gridHelper.receiveShadow = true;
    }
    
    updateStatusBar('已启用高级渲染设置');
}

// 渲染为高分辨率图片
function renderHighResolution(width, height) {
    // 保存当前渲染器设置
    const originalWidth = renderer.domElement.width;
    const originalHeight = renderer.domElement.height;
    
    // 设置高分辨率
    renderer.setSize(width, height, false);
    
    // 渲染
    renderer.render(scene, camera);
    
    // 下载图片
    const link = document.createElement('a');
    link.download = 'blender-render-' + new Date().toISOString().slice(0, 10) + '.png';
    link.href = renderer.domElement.toDataURL('image/png');
    link.click();
    
    // 恢复原始设置
    renderer.setSize(originalWidth, originalHeight);
    
    updateStatusBar(`已渲染高分辨率图片: ${width}x${height}`);
}

// 创建预设模型
function createPresetModel(presetType) {
    const preset = modelPresets.find(p => p.type === presetType);
    if (!preset) {
        updateStatusBar('未找到该预设模型');
        return;
    }
    
    try {
        // 创建几何体
        const geometry = preset.create();
        
        // 创建材质
        const material = new THREE.MeshStandardMaterial({
            color: 0x777777,
            metalness: 0.1,
            roughness: 0.7
        });
        
        // 创建网格对象
        const mesh = new THREE.Mesh(geometry, material);
        mesh.name = preset.name + '_' + Date.now();
        mesh.castShadow = true;
        mesh.receiveShadow = true;
        
        // 添加到场景
        scene.add(mesh);
        sceneObjects.push(mesh);
        
        // 选中新创建的对象
        selectObject(mesh);
        
        // 更新对象面板
        updateObjectsPanel();
        
        // 显示成功消息
        updateStatusBar(`已创建预设模型: ${preset.name}`);
        
        return mesh;
    } catch (error) {
        console.error('创建预设模型错误:', error);
        updateStatusBar(`创建预设模型失败: ${error.message}`);
    }
}

// 初始化预设模型库UI
function initPresetModelsUI() {
    // 查找预设模型面板容器
    const presetsPanel = document.getElementById('preset-models-panel');
    if (!presetsPanel) {
        // 如果不存在，创建预设模型面板
        const panelContainer = document.createElement('div');
        panelContainer.id = 'preset-models-panel';
        panelContainer.className = 'panel';
        panelContainer.style.cssText = `
            position: absolute;
            top: 50px;
            right: 10px;
            width: 200px;
            background: #333;
            color: white;
            border: 1px solid #555;
            border-radius: 4px;
            padding: 10px;
            z-index: 1000;
            max-height: 400px;
            overflow-y: auto;
        `;
        
        const panelTitle = document.createElement('h3');
        panelTitle.textContent = '模型预设';
        panelTitle.style.cssText = `
            margin-top: 0;
            margin-bottom: 10px;
            font-size: 14px;
            border-bottom: 1px solid #555;
            padding-bottom: 5px;
        `;
        
        panelContainer.appendChild(panelTitle);
        
        // 添加到主内容区
        const mainContent = document.querySelector('.main-content');
        if (mainContent) {
            mainContent.appendChild(panelContainer);
        }
        
        // 重新获取面板引用
        presetsPanel = document.getElementById('preset-models-panel');
    }
    
    // 清空面板内容（除了标题）
    const children = Array.from(presetsPanel.children);
    children.forEach(child => {
        if (child.tagName !== 'H3') {
            presetsPanel.removeChild(child);
        }
    });
    
    // 添加预设模型按钮
    modelPresets.forEach(preset => {
        const presetButton = document.createElement('button');
        presetButton.className = 'preset-model-button';
        presetButton.style.cssText = `
            width: 100%;
            padding: 8px;
            margin-bottom: 5px;
            background: #444;
            color: white;
            border: 1px solid #555;
            border-radius: 4px;
            cursor: pointer;
            text-align: left;
            display: flex;
            align-items: center;
            gap: 8px;
        `;
        
        // 添加缩略图
        const thumbnailImg = document.createElement('img');
        thumbnailImg.src = preset.thumbnail;
        thumbnailImg.style.width = '20px';
        thumbnailImg.style.height = '20px';
        
        // 添加名称
        const nameSpan = document.createElement('span');
        nameSpan.textContent = preset.name;
        
        // 组装按钮
        presetButton.appendChild(thumbnailImg);
        presetButton.appendChild(nameSpan);
        
        // 添加点击事件
        presetButton.addEventListener('click', function() {
            createPresetModel(preset.type);
        });
        
        // 添加到面板
        presetsPanel.appendChild(presetButton);
    });
}

// 初始化模型预设库
function initModelPresets() {
    // 添加基础几何形状预设
    modelPresets.push({
        name: '人体基础',
        type: 'human_base',
        thumbnail: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiIHZpZXdCb3g9IjAgMCAyNCAyNCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cGF0aCBkPSJNMTEuNSAxOGMtLjU1MiAwLTEgLjQ0OC0xIDFzLjQ0OCAxIDEgMSAxLS40NDggMS0xLS40NDgtMS0xLTF6bTAgLThjLS41NTIgMC0xIC40NDgtMSAxcy40NDggMSAxIDEgMS0uNDQ4IDEtMS0uNDQ4LTEtMS0xem0tNC41IDE2Yy0uNTUyIDAtMS4xMjUgMC0xLjY1OCAtLjA1NC0uODA5LS4zMDktMS41MzktLjc3Ni0yLjE0MS0xLjQxYy0uODI2LS45MzMtMS4xMDUtMi4wMzQtLjk3OC0zLjEyMy4xMjUtMS4wMzIuNTYtMS45NDUuNjY2LTIuMjQzLjEwNi0yOTkuNjY1LTguNzk5LjY2NS04Ljc5OXMwLjU1OSA4LjUgLjY2NSA4LjguMTA2LjMwNCAuNTYgMS4yMTIuNjY1IDIuMjQzLS4xMjcgMS4wOS4xNTIgMi4xODcuOTc4IDMuMTI0LjY2Ny42NjkuMTQ3LjA1NC0uMTU0LjA1NHptMTMgMEgyNmw2LTEyLTYtMTItLTYgMTIgNiAxMnptLTkuNSAwYy0uNTUyIDAtMSAuNDQ4LTEgMXMuNDQ4IDEgMSAxIDEtLjQ0OCAxLTFBLjQ5NS40OTUgMCAwIDAgMTUgOHptMC04Yy0uNTUyIDAtMS4wMDAuNDQ4LTEuMDAwIDFzLjQ0OCAxIDEuMDAwIDFIMjRjLjU1MiAwIDEuMDAwLS40NDggMS4wMDAwLTEuMDAwUzI0LjU1MiAwIDI0IDB6bS00LjUgMTZjLS41NTIgMC0xLjAyNSAwLTEuNjU4LS4wNTQtLjgwOS0uMzA5LTEuNTM5LS43NzYtMi4xNDEtMS40MS0uODI2LS45MzMtMS4xMDUtMi4wMzQtLjk3OC0zLjEyMy4xMjUtMS4wMzIuNTYtMS45NDUuNjY2LTIuMjQzLjEwNi0yOTkuNjY1LTguNzk5LjY2NS04Ljc5OXMuNTU5IDguNS42NjUgOC44LjEwNi4zMDQuNTYgMS4yMTIuNjY1IDIuMjQzLS4xMjcgMS4wOS4xNTIgMi4xODcuOTc4IDMuMTI0LjY2Ny42NjkuMTQ3LjA1NC0uMTU0LjA1NHoiIGZpbGw9IiNGRkYiIHN0cm9rZT0iIzMzMyIgc3Ryb2tlLXdpZHRoPSIyIi8+PC9zdmc+',
        create: function() {
            const geometry = new THREE.CapsuleGeometry(0.5, 2, 16, 32);
            return geometry;
        }
    });
    
    modelPresets.push({
        name: '动物基础',
        type: 'animal_base',
        thumbnail: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiIHZpZXdCb3g9IjAgMCAyNCAyNCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cGF0aCBkPSJNMCAyMGgyNHYtMTRoLTR2LTRoLTJ2NGgtNHYtNGgtMnY0SDB2MTR6bTcgLTE2aDN2MmgtM3Y2aC0ydi00SDZ2NGgtMlYwaDJ2MTRoN3YtMTR6IiBmaWxsPSIjRkZGIiBzdHJva2U9IiMzMzMiIHN0cm9rZS13aWR0aD0iMiIvPjwvc3ZnPg==',
        create: function() {
            const geometry = new THREE.CapsuleGeometry(0.4, 1.5, 16, 32);
            return geometry;
        }
    });
    
    modelPresets.push({
        name: '圆环',
        type: 'torus',
        thumbnail: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiIHZpZXdCb3g9IjAgMCAyNCAyNCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cGF0aCBkPSJNMTIgMnYyaDR2MmgtNHYySDh2LTJoNnYtMmgtNHYtMmgydjJ6bTQgMTRoMnYtMmgtMnYtMmgtMnYyaDJ2MnptLTQgMGgydi0yaC0ydi0yaC0ydi0yaDJ2MmgtMnYyaDJ2MnptMy05YzEuNjU3IDAgMy0xLjM0MyAzLTMgMC0xLjY1Ny0xLjM0My0zLTMtMy0xLjY1NyAwLTMgMS4zNDMtMyAzIDAgMS42NTcgMS4zNDMgMyAzIDN6IiBmaWxsPSIjRkZGIiBzdHJva2U9IiMzMzMiIHN0cm9rZS13aWR0aD0iMiIvPjwvc3ZnPg==',
        create: function() {
            const geometry = new THREE.TorusGeometry(1, 0.3, 16, 32);
            return geometry;
        }
    });
    
    modelPresets.push({
        name: '平面',
        type: 'plane',
        thumbnail: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiIHZpZXdCb3g9IjAgMCAyNCAyNCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cGF0aCBkPSJNMCAwaDI0djI0SDBWMHptNiA0aDR2NGgtNHYtNHptMCAwaDJ2MmgtMnYtMnptLTIgMGgydjJoLTJ2LTJ6bTEyIDBoNHY0aC00di00em0wIDBoMnYyaC0ydi0yem0tMiAwSDJ2Mmgydi0yem0wIDZoMnYyaC0ydi0yem0wIDZoMnYyaC0ydi0yem0wIDZoMnYyaC0ydi0yem0wIDZoMnYyaC0ydi0yem0wIDZoMnYyaC0ydi0yem0wIDZoMnYyaC0ydi0yem0wIDZoMnYyaC0ydi0yek0yIDZoMnYyaC0ydi0yem0wIDZoMnYyaC0ydi0yek0xNCA2aDJ2MmgtMnYtMnptMCAwaDJ2MmgtMnYtMnptMCAwaDJ2MmgtMnYtMnptMCAwaDJ2MmgtMnYtMnptMCAwaDJ2MmgtMnYtMnptMCAwaDJ2MmgtMnYtMnoiIGZpbGw9IiNmNWY1ZjUiIHN0cm9rZT0iIzMzMyIgc3Ryb2tlLXdpZHRoPSIyIi8+PC9zdmc+',
        create: function() {
            const geometry = new THREE.PlaneGeometry(4, 4, 10, 10);
            return geometry;
        }
    });
    
    modelPresets.push({
        name: '圆柱',
        type: 'cylinder',
        thumbnail: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiIHZpZXdCb3g9IjAgMCAyNCAyNCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cGF0aCBkPSJNMTIgNmMzLjMxNCAwIDYgMi42ODYgNiA2cy0yLjY4NiA2LTYgNi02LTIuNjg2LTYtNiAyLjY4Ni02IDYtNnptMCAxMmMuNTUyIDAgMS0uNDQ4IDEtMXMtLjQ0OC0xLTEtMS0xLjAwMS40NDgtMS4wMDEgMS4wMDAuNDQ4IDEgMS4wMDAgMXptLTUgMGMuNTUyIDAgMS0uNDQ4IDEtMXMtLjQ0OC0xLTEtMS0xLjAwMS40NDgtMS4wMDEgMS4wMDAuNDQ4IDEgMS4wMDAgMXptMTAgMEMxNy41NTIgMCAxOSA2LjQ0OCAxOSA2cy0xLjQ0OCAxMi00IDEyLTQtLTYuNDQ4LTQtMTIuMDAwIDEuNDQ4LTEyIDQtMTJ6IiBmaWxsPSIjRkZGIiBzdHJva2U9IiMzMzMiIHN0cm9rZS13aWR0aD0iMiIvPjwvc3ZnPg==',
        create: function() {
            const geometry = new THREE.CylinderGeometry(0.5, 0.5, 2, 32);
            return geometry;
        }
    });
    
    modelPresets.push({
        name: '球体',
        type: 'sphere',
        thumbnail: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiIHZpZXdCb3g9IjAgMCAyNCAyNCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cGF0aCBkPSJNMTIgMmM1LjUyMyAwIDEwIDQuNDc3IDEwIDEwcy00LjQ3NyAxMC0xMCAxMC0xMC00LjQ3Ny0xMC0xMCA0LjQ3Ny0xMCAxMC0xMHptMCAyYzQuNDE4IDAgOCAzLjU4MiA4IDhzLTMuNTgyIDgtOCA4LTgtMy41ODItOC04IDMuNTgyLTggOC04eiIgZmlsbD0iI0ZGRiIgc3Ryb2tlPSIjMzMzIiBzdHJva2Utd2lkdGg9IjIiLz48L3N2Zz4=',
        create: function() {
            const geometry = new THREE.SphereGeometry(1, 32, 32);
            return geometry;
        }
    });
}

// 当页面加载完成时初始化
window.addEventListener('load', init);

// 在页面完全加载后初始化模型预设库UI
window.addEventListener('load', function() {
    // 延迟初始化，确保所有函数都已定义
    setTimeout(function() {
        if (typeof initModelPresetsUI === 'function') {
            initModelPresetsUI();
        }
    }, 100);
});