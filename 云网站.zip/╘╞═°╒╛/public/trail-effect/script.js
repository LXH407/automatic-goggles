// 烟雾鼠标拖尾效果实现

// 获取Canvas元素和上下文
const canvas = document.getElementById('canvas');
const ctx = canvas.getContext('2d');
const bgAnimation = document.getElementById('bgAnimation');

// 粒子数组，用于存储烟雾拖尾效果的粒子
const particles = [];

// 配置参数 - 修复拖尾效果
const config = {
  particleCount: 200, // 进一步增加粒子数量
  baseSize: 3,        // 增加基础大小，使拖尾更明显
  maxSize: 35,        // 增加最大大小
  speedFactor: 0.07,  // 略微增加速度因子
  // 增强彩虹背景下的拖尾效果
  colorBase: 'rgba(255, 255, 255, 0.95)',     // 更高的不透明度
  colorSecondary: 'rgba(255, 255, 255, 0.8)', // 更高的不透明度
  // 新增配置
  connectionThickness: 0.8, // 增加连接线粗细
  glowIntensity: 0.5,       // 降低发光强度，避免过度模糊
  trailLengthFactor: 1.5,   // 增加拖尾长度
  enableRainbowParticles: false // 暂时禁用彩虹粒子，确保基础效果可见
};

// 鼠标位置变量
let mouse = {
  x: window.innerWidth / 2,
  y: window.innerHeight / 2
};

// 上一帧鼠标位置
let lastMouse = {
  x: mouse.x,
  y: mouse.y
};

// 鼠标速度，用于特殊效果
let mouseSpeed = 0;

// 调整Canvas大小以适应窗口
function resizeCanvas() {
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
}

// 背景粒子存储数组
let backgroundParticles = [];

// 创建动态背景效果
function createBackgroundParticles() {
  // 清除旧的背景粒子
  while (bgAnimation.firstChild) {
    bgAnimation.removeChild(bgAnimation.firstChild);
  }
  backgroundParticles = [];
  
  // 粒子类型配置
  const particleTypes = [
    { className: 'circle', minSize: 30, maxSize: 150 },
    { className: 'ellipse', minSize: 50, maxSize: 200, aspectRatio: 0.6 },
    { className: 'star', minSize: 10, maxSize: 30 },
    { className: 'glow', minSize: 100, maxSize: 300 }
  ];
  
  // 创建更多的背景粒子
  const particleCount = Math.floor(window.innerWidth * window.innerHeight / 10000);
  
  for (let i = 0; i < particleCount; i++) {
    const particle = document.createElement('div');
    particle.classList.add('bg-particle');
    
    // 随机选择粒子类型
    const typeIndex = Math.floor(Math.random() * particleTypes.length);
    const type = particleTypes[typeIndex];
    particle.classList.add(type.className);
    
    // 随机大小和位置
    const size = Math.random() * (type.maxSize - type.minSize) + type.minSize;
    const x = Math.random() * 100;
    const y = Math.random() * 100;
    const delay = Math.random() * 15;
    let duration = Math.random() * 30 + 15;
    
    // 设置粒子样式
    if (type.aspectRatio) {
      // 非圆形粒子
      particle.style.width = `${size}px`;
      particle.style.height = `${size * type.aspectRatio}px`;
    } else {
      // 圆形粒子
      particle.style.width = `${size}px`;
      particle.style.height = `${size}px`;
    }
    
    particle.style.left = `${x}%`;
    particle.style.top = `${y}%`;
    particle.style.animationDelay = `${delay}s`;
    
    // 随机选择动画类型
    const animationType = Math.random();
    if (animationType < 0.3) {
      particle.style.animationName = 'floatSlow';
      duration *= 1.5;
    } else if (animationType < 0.7) {
      particle.style.animationName = 'float';
    } else {
      particle.style.animationName = 'floatFast';
      duration *= 0.8;
    }
    
    particle.style.animationDuration = `${duration}s`;
    
    // 随机透明度
    let opacity = Math.random() * 0.08 + 0.02;
    // 光晕粒子特殊处理
    if (type.className === 'glow') {
      particle.style.animationName = 'pulseGlow';
      particle.style.animationDuration = `${Math.random() * 5 + 3}s`;
      opacity = Math.random() * 0.05 + 0.01;
    }
    
    particle.style.opacity = opacity;
      
      // 随机透明度变化，使粒子在彩虹背景上更自然
      const opacityVariation = Math.random() * 0.05;
      particle.style.opacity = opacity + opacityVariation;
      
      // 存储粒子信息用于交互效果
    backgroundParticles.push({
      element: particle,
      x: x,
      y: y,
      size: size,
      originalOpacity: opacity,
      originalX: x,
      originalY: y,
      interactionRadius: size * 1.5
    });
    
    bgAnimation.appendChild(particle);
  }
}

// 背景粒子交互效果
function updateBackgroundParticleInteraction() {
  const mouseX = mouse.x / window.innerWidth * 100;
  const mouseY = mouse.y / window.innerHeight * 100;
  
  backgroundParticles.forEach(particle => {
    // 计算粒子与鼠标的距离
    const dx = particle.x - mouseX;
    const dy = particle.y - mouseY;
    const distance = Math.sqrt(dx * dx + dy * dy);
    
    // 如果粒子在鼠标交互范围内
    if (distance < particle.interactionRadius) {
      // 计算排斥力
      const force = (1 - distance / particle.interactionRadius) * 5;
      const angle = Math.atan2(dy, dx);
      
      // 应用排斥效果
      const targetX = particle.originalX + Math.cos(angle) * force;
      const targetY = particle.originalY + Math.sin(angle) * force;
      
      // 平滑过渡到目标位置
      particle.x += (targetX - particle.x) * 0.05;
      particle.y += (targetY - particle.y) * 0.05;
      
      // 增加透明度以突显效果
      const targetOpacity = particle.originalOpacity * (1 + force / 5);
      particle.element.style.opacity = targetOpacity;
    } else {
      // 恢复原始位置和透明度
      particle.x += (particle.originalX - particle.x) * 0.02;
      particle.y += (particle.originalY - particle.y) * 0.02;
      particle.element.style.opacity = particle.originalOpacity;
    }
    
    // 更新粒子位置
    particle.element.style.left = `${particle.x}%`;
    particle.element.style.top = `${particle.y}%`;
  });
}

// 初始化函数
function init() {
  resizeCanvas();
  createBackgroundParticles();
  
  // 初始化烟雾粒子
  for (let i = 0; i < config.particleCount; i++) {
    let color = i % 3 === 0 ? config.colorBase : config.colorSecondary;
    
    // 如果启用了彩虹粒子效果，为部分粒子添加彩虹色彩
    if (config.enableRainbowParticles && Math.random() > 0.7) {
      const hue = Math.random() * 360; // 0-360 色相
      const lightness = Math.random() * 20 + 80; // 80-100 亮度
      const alpha = Math.random() * 0.4 + 0.5; // 0.5-0.9 透明度
      color = `hsla(${hue}, 100%, ${lightness}%, ${alpha})`;
    }
    
    particles.push({
      x: mouse.x,
      y: mouse.y,
      size: Math.random() * config.baseSize + 1,
      alpha: Math.random() * 0.5 + 0.5, // 增加初始透明度，使拖尾更明显
      color: color,
      targetX: mouse.x,
      targetY: mouse.y,
      vx: 0,
      vy: 0,
      rotation: Math.random() * Math.PI * 2, // 旋转角度，使烟雾更自然
      rotationSpeed: (Math.random() - 0.5) * 0.03, // 旋转速度适中
      driftFactor: Math.random() * 0.3 + 0.1, // 增加漂移因子范围，使效果更多变
      decay: Math.random() * 0.0008 + 0.0002, // 减小衰减速度，使拖尾更持久
      shapeFactor: Math.random() * 0.4 + 0.8, // 形状因子，控制椭圆形状
      wobbleFactor: Math.random() * 0.05, // 摇摆因子，增加不规则运动
      wobblePhase: Math.random() * Math.PI * 2 // 摇摆相位
    });
  }
  
  // 开始动画循环
  animate();
}

// 绘制烟雾粒子 - 增强版
function drawParticles() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  
  // 首先绘制粒子之间的连线，增强拖尾连贯性
  if (particles.length > 1) {
    ctx.save();
    ctx.globalAlpha = 0.3;
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.5)';
    ctx.lineWidth = config.connectionThickness;
    
    // 绘制连接相邻粒子的线条
    for (let i = 1; i < particles.length; i++) {
      const prevParticle = particles[i - 1];
      const currParticle = particles[i];
      
      if (prevParticle.alpha <= 0 || currParticle.alpha <= 0) continue;
      
      // 根据粒子位置和透明度调整线条样式
      const alpha = Math.min(prevParticle.alpha, currParticle.alpha) * 0.8;
      const lineWidth = config.connectionThickness * alpha;
      
      ctx.globalAlpha = alpha;
      ctx.lineWidth = lineWidth;
      
      ctx.beginPath();
      ctx.moveTo(prevParticle.x, prevParticle.y);
      ctx.lineTo(currParticle.x, currParticle.y);
      ctx.stroke();
    }
    
    ctx.restore();
  }
  
  // 绘制每个粒子
  for (let i = 0; i < particles.length; i++) {
    const particle = particles[i];
    const size = particle.currentSize || particle.size; // 使用动态大小
    
    // 如果粒子透明度为0，跳过绘制
    if (particle.alpha <= 0) continue;
    
    // 保存当前上下文状态
    ctx.save();
    
    // 移动到粒子中心
    ctx.translate(particle.x, particle.y);
    
    // 应用旋转
    ctx.rotate(particle.rotation);
    
    // 创建径向渐变，增强发光效果
    const gradient = ctx.createRadialGradient(
      0, 0, 0,
      0, 0, size * (1 + config.glowIntensity)
    );
    
    // 设置渐变颜色
    gradient.addColorStop(0, particle.color);
    
    // 根据颜色格式正确处理透明度
    let midColor;
    if (particle.color.includes('hsla')) {
      // 处理hsla颜色格式
      const baseAlpha = particle.color.match(/hsla\([^,]+,[^,]+,[^,]+,([^)]+)\)/);
      if (baseAlpha && baseAlpha[1]) {
        const currentAlpha = parseFloat(baseAlpha[1]);
        midColor = particle.color.replace(/hsla\(([^,]+,[^,]+,[^,]+),[^)]+\)/, `hsla($1, ${Math.min(currentAlpha * 0.7, 1)})`);
      } else {
        midColor = particle.color.replace(/hsla\(([^,]+,[^,]+,[^,]+),[^)]+\)/, 'hsla($1, 0.5)');
      }
    } else if (particle.color.includes('rgba')) {
      // 处理rgba颜色格式
      midColor = particle.color.replace(/rgba\(([^,]+,[^,]+,[^,]+),[^)]+\)/, 'rgba($1, 0.5)');
    } else {
      // 处理rgb颜色格式
      midColor = particle.color.replace(/rgb\(([^)]+)\)/, 'rgba($1, 0.5)');
    }
    
    gradient.addColorStop(0.6, midColor);
    gradient.addColorStop(1, 'rgba(255, 255, 255, 0)');
    
    // 设置填充样式为渐变
    ctx.fillStyle = gradient;
    
    // 设置粒子的不透明度
    ctx.globalAlpha = particle.alpha;
    
    // 绘制椭圆粒子，使用shapeFactor控制椭圆形状
    const radiusX = size;
    const radiusY = size * particle.shapeFactor;
    
    ctx.beginPath();
    ctx.ellipse(0, 0, radiusX, radiusY, 0, 0, Math.PI * 2);
    ctx.fill();
    
    // 如果启用了彩虹粒子并且是HSLA格式颜色，添加额外的光晕效果
    if (config.enableRainbowParticles && particle.color.includes('hsla')) {
      try {
        // 保存当前状态以添加光晕
        ctx.save();
        ctx.globalAlpha = particle.alpha * 0.5;
        
        // 创建更大的光晕，使用新的发光强度计算方式
        const glowSize = size * (1 + config.glowIntensity * 2);
        const glowGradient = ctx.createRadialGradient(0, 0, 0, 0, 0, glowSize);
        
        // 简化颜色处理，使用粒子的原始颜色但降低透明度
        let glowColor = particle.color;
        if (particle.color.includes('hsla')) {
          glowColor = particle.color.replace(/hsla\(([^,]+,[^,]+,[^,]+),([^)]+)\)/, (match, colorPart, alphaPart) => {
            const newAlpha = Math.min(parseFloat(alphaPart) * 0.3, 0.5);
            return `hsla(${colorPart}, ${newAlpha})`;
          });
        }
        
        glowGradient.addColorStop(0, glowColor);
        glowGradient.addColorStop(1, 'rgba(255, 255, 255, 0)');
        
        ctx.fillStyle = glowGradient;
        ctx.beginPath();
        ctx.ellipse(0, 0, radiusX * 1.5, radiusY * 1.5, 0, 0, Math.PI * 2);
        ctx.fill();
        
        ctx.restore();
      } catch (e) {
        console.error('Error rendering rainbow particle glow:', e);
        ctx.restore();
      }
    }
    
    // 恢复上下文状态
    ctx.restore();
  }
  
  // 重置全局透明度
  ctx.globalAlpha = 1;
}

// 更新烟雾粒子位置 - 增强版
function updateParticles() {
  // 计算鼠标速度，用于动态调整粒子行为
  const mouseSpeedX = mouse.x - lastMouse.x;
  const mouseSpeedY = mouse.y - lastMouse.y;
  const mouseSpeed = Math.sqrt(mouseSpeedX * mouseSpeedX + mouseSpeedY * mouseSpeedY);
  
  // 更新最后鼠标位置
  lastMouse.x = mouse.x;
  lastMouse.y = mouse.y;
  
  // 增强版拖尾效果：根据鼠标速度调整粒子间距
  const speedFactor = Math.min(1 + mouseSpeed * 0.02, 3); // 速度越快，拖尾越长
  
  // 更新每个粒子的目标位置
  for (let i = particles.length - 1; i > 0; i--) {
    // 根据粒子位置和鼠标速度动态调整跟随距离
    const distanceFactor = 1 + (i / particles.length) * config.trailLengthFactor;
    particles[i].targetX = particles[i - 1].x - (particles[i - 1].vx * 0.1 * distanceFactor);
    particles[i].targetY = particles[i - 1].y - (particles[i - 1].vy * 0.1 * distanceFactor);
  }
  
  // 第一个粒子跟随鼠标，但添加一点延迟，使效果更自然
  particles[0].targetX = mouse.x - mouseSpeedX * 0.2;
  particles[0].targetY = mouse.y - mouseSpeedY * 0.2;
  
  // 更新每个粒子的实际位置
  for (let i = 0; i < particles.length; i++) {
    const particle = particles[i];
    
    // 基于粒子在拖尾中的位置调整速度因子
    const positionFactor = 1 - (i / particles.length) * 0.5;
    
    // 使用物理运动模型，让粒子平滑跟随目标
    particle.vx += (particle.targetX - particle.x) * config.speedFactor * positionFactor;
    particle.vy += (particle.targetY - particle.y) * config.speedFactor * positionFactor;
    
    // 添加随机漂移效果，模拟烟雾飘动
    particle.vx += (Math.random() - 0.5) * particle.driftFactor;
    particle.vy += (Math.random() - 0.5) * particle.driftFactor;
    
    // 添加摇摆效果，使粒子运动更不规则
    const wobble = Math.sin(Date.now() * 0.001 + particle.wobblePhase) * particle.wobbleFactor;
    particle.vx += Math.cos(particle.rotation) * wobble;
    particle.vy += Math.sin(particle.rotation) * wobble;
    
    // 添加一些阻力，使运动更自然
    const drag = 0.8 - (mouseSpeed * 0.001); // 鼠标速度越快，阻力越小
    particle.vx *= drag;
    particle.vy *= drag;
    
    // 更新位置
    particle.x += particle.vx;
    particle.y += particle.vy;
    
    // 更新旋转
    particle.rotation += particle.rotationSpeed;
    
    // 粒子衰减效果 - 根据鼠标速度动态调整
    const decayFactor = Math.max(0.5, 2 - mouseSpeed * 0.01); // 速度越快，衰减越慢
    particle.alpha -= particle.decay * decayFactor;
    if (particle.alpha < 0) particle.alpha = 0;
    
    // 根据鼠标速度调整粒子大小
    const sizeMultiplier = Math.min(1 + mouseSpeed * 0.01, 1.5);
    particle.currentSize = particle.size * sizeMultiplier * (1 - (i / particles.length));
  }
}

// 动画循环 - 优化版
let lastFrameTime = 0;
let frameCount = 0;
let lastFpsUpdate = 0;

function animate(timestamp) {
  // 计算帧率
  if (!lastFrameTime) lastFrameTime = timestamp;
  const deltaTime = timestamp - lastFrameTime;
  lastFrameTime = timestamp;
  
  // 帧率限制，确保性能稳定
  if (deltaTime < 16) { // 大约60fps
    requestAnimationFrame(animate);
    return;
  }
  
  // 计算鼠标速度
  const speedX = mouse.x - lastMouse.x;
  const speedY = mouse.y - lastMouse.y;
  mouseSpeed = Math.sqrt(speedX * speedX + speedY * speedY);
  
  // 保存当前鼠标位置作为下一帧的上一位置
  lastMouse.x = mouse.x;
  lastMouse.y = mouse.y;
  
  // 更新和绘制
  updateParticles();
  drawParticles();
  updateBackgroundParticleInteraction();
  
  // 继续动画循环
  requestAnimationFrame(animate);
}

// 鼠标移动事件 - 增强版
window.addEventListener('mousemove', function(e) {
  const prevX = mouse.x;
  const prevY = mouse.y;
  
  mouse.x = e.clientX;
  mouse.y = e.clientY;
  
  // 计算鼠标速度，用于特殊效果
  const speedX = mouse.x - prevX;
  const speedY = mouse.y - prevY;
  const speed = Math.sqrt(speedX * speedX + speedY * speedY);
  
  // 当鼠标快速移动时，添加额外的粒子效果
  if (speed > 15 && particles.length < config.particleCount * 1.2) {
    createBurstParticles(mouse.x, mouse.y, Math.min(Math.floor(speed / 10), 5));
  }
});

// 触摸移动事件
window.addEventListener('touchmove', function(e) {
  if (e.touches.length > 0) {
    const prevX = mouse.x;
    const prevY = mouse.y;
    
    mouse.x = e.touches[0].clientX;
    mouse.y = e.touches[0].clientY;
    
    // 计算触摸速度
    const speedX = mouse.x - prevX;
    const speedY = mouse.y - prevY;
    const speed = Math.sqrt(speedX * speedX + speedY * speedY);
    
    // 快速触摸时添加额外粒子
    if (speed > 20 && particles.length < config.particleCount * 1.2) {
      createBurstParticles(mouse.x, mouse.y, Math.min(Math.floor(speed / 15), 3));
    }
    
    e.preventDefault(); // 防止页面滚动
  }
}, { passive: false });

// 触摸结束事件
window.addEventListener('touchend', function() {
  // 触摸结束时添加一些收尾效果
  if (particles.length > 0) {
    createBurstParticles(lastMouse.x, lastMouse.y, 3);
  }
});

// 鼠标点击事件 - 添加点击效果
window.addEventListener('click', function(e) {
  createBurstParticles(e.clientX, e.clientY, 8);
});

// 窗口大小变化事件
window.addEventListener('resize', debounce(() => {
  resizeCanvas();
  createBackgroundParticles(); // 重新创建背景粒子
}, 100));

// 创建爆发粒子效果
function createBurstParticles(x, y, count) {
  for (let i = 0; i < count; i++) {
    let color = Math.random() > 0.5 ? config.colorBase : config.colorSecondary;
    
    // 随机添加彩虹粒子
    if (config.enableRainbowParticles && Math.random() > 0.6) {
      const hue = Math.random() * 360;
      const lightness = Math.random() * 20 + 80;
      const alpha = Math.random() * 0.4 + 0.5;
      color = `hsla(${hue}, 100%, ${lightness}%, ${alpha})`;
    }
    
    // 计算爆发方向
    const angle = Math.random() * Math.PI * 2;
    const speed = Math.random() * 2 + 1;
    
    particles.push({
      x: x,
      y: y,
      size: Math.random() * config.baseSize * 0.8 + 0.5,
      alpha: Math.random() * 0.4 + 0.6,
      color: color,
      targetX: x + Math.cos(angle) * 20,
      targetY: y + Math.sin(angle) * 20,
      vx: Math.cos(angle) * speed,
      vy: Math.sin(angle) * speed,
      rotation: Math.random() * Math.PI * 2,
      rotationSpeed: (Math.random() - 0.5) * 0.05,
      driftFactor: Math.random() * 0.4 + 0.1,
      decay: Math.random() * 0.001 + 0.0003,
      shapeFactor: Math.random() * 0.5 + 0.7,
      wobbleFactor: Math.random() * 0.07,
      wobblePhase: Math.random() * Math.PI * 2
    });
  }
  
  // 确保粒子总数不超过限制
  if (particles.length > config.particleCount * 1.5) {
    particles.splice(0, particles.length - config.particleCount * 1.5);
  }
}

// 防抖函数，优化窗口调整性能
function debounce(func, wait) {
  let timeout;
  return function() {
    const context = this;
    const args = arguments;
    clearTimeout(timeout);
    timeout = setTimeout(() => func.apply(context, args), wait);
  };
}

// 初始化
init();