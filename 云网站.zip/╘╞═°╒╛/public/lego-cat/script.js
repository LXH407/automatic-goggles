// 全局变量
let scene, camera, renderer;
let controls, deviceControls;
let wolfModel; // 红狼模型引用
let mixer; // 动画混合器
let animations = {}; // 存储动画剪辑
let currentAnimation = null; // 当前播放的动画
let isMobile = false;
let loadingManager;
let assetsLoaded = 0;
let totalAssets = 1; // FBX模型资源数量

// 动画相关变量
let mouseX = 0, mouseY = 0; // 鼠标位置
let interactionTimer = 0; // 交互计时器
let isInteracting = false; // 交互状态
let headBone, spineBone; // 关键骨骼引用

// 初始化函数
function init() {
  // 检测是否为移动设备
  isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
  
  // 创建场景
  scene = new THREE.Scene();
  scene.background = new THREE.Color(0xf5f5f5);
  
  // 为了避免浏览器错误，移除了base64编码的环境贴图
  // 我们已经通过增强的光照和材质设置获得了良好的视觉效果
  
  // 创建相机
  camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
  camera.position.z = 15;
  
  // 创建渲染器
  renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  
  // 添加到DOM
  const container = document.getElementById('container');
  container.appendChild(renderer.domElement);
  
  // 创建加载管理器
  loadingManager = new THREE.LoadingManager();
  loadingManager.onProgress = function (url, itemsLoaded, itemsTotal) {
    updateLoadingProgress(itemsLoaded / itemsTotal);
  };
  loadingManager.onLoad = function () {
    hideLoadingScreen();
  };
  
  // 开始加载FBX模型
  loadWolfModel();
  
  // 添加光照
  addLights();
  
  // 创建地面
  createGround();
  
  // 注释掉原来的乐高猫咪创建函数，改为加载FBX模型
  // createLegoCat();
  
  // 设置控制器
  setupControls();
  
  // 添加鼠标移动事件监听
  if (!isMobile) {
    window.addEventListener('mousemove', onMouseMove);
  } else {
    // 移动设备上使用触摸事件
    window.addEventListener('touchmove', onTouchMove);
  }
  
  // 开始动画循环
  animate();
  
  // 监听窗口大小变化
  window.addEventListener('resize', onWindowResize);
}

// 添加光照
function addLights() {
  // 环境光 - 使用稍微偏暖的色调
  const ambientLight = new THREE.AmbientLight(0xffffff, 0.7);
  scene.add(ambientLight);
  
  // 方向光（主光源）
  const directionalLight = new THREE.DirectionalLight(0xffffff, 1.0);
  directionalLight.position.set(10, 15, 10);
  directionalLight.castShadow = true;
  directionalLight.shadow.mapSize.width = 4096;
  directionalLight.shadow.mapSize.height = 4096;
  directionalLight.shadow.camera.near = 0.1;
  directionalLight.shadow.camera.far = 100;
  directionalLight.shadow.camera.left = -20;
  directionalLight.shadow.camera.right = 20;
  directionalLight.shadow.camera.top = 20;
  directionalLight.shadow.camera.bottom = -20;
  directionalLight.shadow.bias = -0.0001;
  scene.add(directionalLight);
  
  // 添加一个柔和的补光
  const fillLight = new THREE.DirectionalLight(0xffffff, 0.5);
  fillLight.position.set(-10, 10, -5);
  scene.add(fillLight);
  
  // 辅助点光源 - 增强边缘光照
  const edgeLight = new THREE.PointLight(0xffffff, 0.3);
  edgeLight.position.set(5, -5, 15);
  scene.add(edgeLight);
}

// 创建地面
function createGround() {
  const groundGeometry = new THREE.PlaneGeometry(100, 100, 100, 100);
  
  // 创建网格地面材质，增强视觉效果
  const groundMaterial = new THREE.MeshStandardMaterial({
    color: 0xf0f0f0,
    roughness: 0.7,
    metalness: 0.1,
    vertexColors: true
  });
  
  // 添加顶点颜色，创建微妙的地面纹理
  const colors = [];
  for (let i = 0; i < groundGeometry.attributes.position.count; i++) {
    const v = Math.random() * 0.05 + 0.95;
    colors.push(v, v, v);
  }
  groundGeometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
  
  const ground = new THREE.Mesh(groundGeometry, groundMaterial);
  ground.rotation.x = -Math.PI / 2;
  ground.position.y = -3;
  ground.receiveShadow = true;
  scene.add(ground);
}

// 加载红狼FBX模型
function loadWolfModel() {
  console.log('开始加载红狼FBX模型...');
  
  // 首先检查模型文件是否存在
  fetch('../三角洲人物红狼.fbx')
    .then(response => {
      if (!response.ok) {
        throw new Error('模型文件不存在或无法访问: ' + response.status);
      }
      console.log('模型文件存在，开始使用FBXLoader加载...');
      
      const loader = new THREE.FBXLoader();
      
      // 添加加载进度处理
      loader.setPath('../');
      
      // 添加详细的加载错误处理
      loader.load(
        '三角洲人物红狼.fbx',
        function(object) {
          console.log('模型加载成功！开始处理模型...');
          
          // 调整模型大小和位置
          object.scale.set(0.01, 0.01, 0.01); // 缩小模型
          object.position.set(0, 0, 0);
          object.rotation.y = Math.PI; // 旋转模型使其面向前方
          
          // 保存模型引用
          wolfModel = object;
          
          // 将模型添加到场景
          scene.add(object);
          
          // 尝试找到骨骼并设置动画
          setupModelAnimation(object);
          
          // 添加呼吸动画
          setupBreathingAnimation(object);
          
          console.log('模型处理完成，已添加到场景！');
        },
        function(xhr) {
          // 加载进度回调
          const percent = Math.round((xhr.loaded / xhr.total) * 100);
          console.log(`模型加载进度: ${percent}%`);
        },
        function(error) {
          console.error('模型加载失败！详细错误:', error);
          
          // 尝试提供更具体的错误信息
          if (error.message && error.message.includes('DataView')) {
            console.error('这很可能是FBX文件格式问题或简化版fflate库的兼容性问题。');
          } else if (error.message && error.message.includes('Unexpected token')) {
            console.error('这可能是文件被损坏或不是有效的FBX文件。');
          }
          
          // 如果加载失败，创建一个简单的几何体作为后备显示
          createFallbackWolfModel();
        }
      );
    })
    .catch(error => {
      console.error('无法访问模型文件:', error);
      // 文件不存在时创建后备模型
      createFallbackWolfModel();
    });
}

// 设置模型动画
function setupModelAnimation(object) {
  console.log('尝试设置模型动画...');
  
  try {
    // 创建动画混合器
    mixer = new THREE.AnimationMixer(object);
    
    // 查找动画
    if (object.animations && object.animations.length > 0) {
      console.log(`找到 ${object.animations.length} 个动画`);
      
      // 播放第一个动画
      const action = mixer.clipAction(object.animations[0]);
      action.play();
      
      // 保存动画引用
      currentAction = action;
    } else {
      console.log('未找到动画数据');
    }
    
    // 尝试查找骨骼
    findBones(object);
  } catch (e) {
    console.error('设置动画时出错:', e);
  }
}

// 查找骨骼
function findBones(object) {
  console.log('尝试查找骨骼...');
  
  try {
    // 遍历对象层次结构查找骨骼
    object.traverse(function(child) {
      if (child.isBone) {
        console.log('找到骨骼:', child.name);
        
        // 根据骨骼名称保存引用
        if (child.name.includes('Head') || child.name.includes('head')) {
          headBone = child;
        } else if (child.name.includes('Spine') || child.name.includes('spine')) {
          spineBone = child;
        } else if (child.name.includes('Leg') || child.name.includes('leg')) {
          legBones.push(child);
        }
      }
    });
    
    console.log('骨骼查找完成');
  } catch (e) {
    console.error('查找骨骼时出错:', e);
  }
}

// 设置呼吸动画
function setupBreathingAnimation(object) {
  console.log('尝试设置呼吸动画...');
  
  try {
    // 创建简单的呼吸动画效果
    breathingEnabled = true;
    
    // 如果找到了脊椎骨骼，使用骨骼动画
    if (spineBone) {
      console.log('使用骨骼进行呼吸动画');
    } else {
      console.log('未找到脊椎骨骼，将使用整体缩放进行呼吸动画');
    }
  } catch (e) {
    console.error('设置呼吸动画时出错:', e);
  }
}

// 创建后备狼模型（当FBX加载失败时）
function createFallbackWolfModel() {
  console.log('创建后备狼模型...');
  
  try {
    // 创建一个简单的狼形几何体组合
    const wolfGroup = new THREE.Group();
    wolfGroup.scale.set(0.01, 0.01, 0.01);
    
    // 身体
    const bodyGeometry = new THREE.CylinderGeometry(30, 40, 100, 8);
    const bodyMaterial = new THREE.MeshStandardMaterial({ color: 0x8B4513 });
    const body = new THREE.Mesh(bodyGeometry, bodyMaterial);
    body.position.set(0, 50, 0);
    wolfGroup.add(body);
    
    // 头部
    const headGeometry = new THREE.SphereGeometry(30, 8, 8);
    const head = new THREE.Mesh(headGeometry, bodyMaterial);
    head.position.set(0, 120, 0);
    wolfGroup.add(head);
    
    // 眼睛
    const eyeGeometry = new THREE.SphereGeometry(5, 4, 4);
    const eyeMaterial = new THREE.MeshBasicMaterial({ color: 0xFFFFFF });
    
    const leftEye = new THREE.Mesh(eyeGeometry, eyeMaterial);
    leftEye.position.set(-15, 130, 25);
    wolfGroup.add(leftEye);
    
    const rightEye = new THREE.Mesh(eyeGeometry, eyeMaterial);
    rightEye.position.set(15, 130, 25);
    wolfGroup.add(rightEye);
    
    // 鼻子
    const noseGeometry = new THREE.ConeGeometry(10, 15, 4);
    const noseMaterial = new THREE.MeshBasicMaterial({ color: 0x000000 });
    const nose = new THREE.Mesh(noseGeometry, noseMaterial);
    nose.position.set(0, 120, 35);
    nose.rotation.x = Math.PI / 2;
    wolfGroup.add(nose);
    
    // 耳朵
    const earGeometry = new THREE.ConeGeometry(5, 25, 4);
    const leftEar = new THREE.Mesh(earGeometry, bodyMaterial);
    leftEar.position.set(-20, 150, 0);
    leftEar.rotation.z = Math.PI / 4;
    wolfGroup.add(leftEar);
    
    const rightEar = new THREE.Mesh(earGeometry, bodyMaterial);
    rightEar.position.set(20, 150, 0);
    rightEar.rotation.z = -Math.PI / 4;
    wolfGroup.add(rightEar);
    
    // 腿
    const legGeometry = new THREE.CylinderGeometry(10, 10, 50, 4);
    
    const frontLeftLeg = new THREE.Mesh(legGeometry, bodyMaterial);
    frontLeftLeg.position.set(-25, 25, 25);
    wolfGroup.add(frontLeftLeg);
    
    const frontRightLeg = new THREE.Mesh(legGeometry, bodyMaterial);
    frontRightLeg.position.set(25, 25, 25);
    wolfGroup.add(frontRightLeg);
    
    const backLeftLeg = new THREE.Mesh(legGeometry, bodyMaterial);
    backLeftLeg.position.set(-25, 25, -25);
    wolfGroup.add(backLeftLeg);
    
    const backRightLeg = new THREE.Mesh(legGeometry, bodyMaterial);
    backRightLeg.position.set(25, 25, -25);
    wolfGroup.add(backRightLeg);
    
    // 尾巴
    const tailGeometry = new THREE.CylinderGeometry(5, 1, 60, 4);
    const tail = new THREE.Mesh(tailGeometry, bodyMaterial);
    tail.position.set(0, 70, -50);
    tail.rotation.x = -Math.PI / 4;
    wolfGroup.add(tail);
    
    // 添加到场景
    scene.add(wolfGroup);
    
    // 保存模型引用
    wolfModel = wolfGroup;
    
    // 启用简单的呼吸动画
    breathingEnabled = true;
    
    console.log('后备狼模型创建成功');
  } catch (e) {
    console.error('创建后备模型时出错:', e);
  }
}

// ... existing code ...