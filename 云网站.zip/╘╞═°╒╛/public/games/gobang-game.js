// 游戏配置
const config = {
  boardSize: 15, // 棋盘大小 (15x15)
  initialPlayer: 'black' // 初始玩家 ('black' 或 'white')
};

// 游戏状态
const gameState = {
  board: [], // 游戏棋盘
  currentPlayer: config.initialPlayer, // 当前玩家
  gameOver: false, // 游戏是否结束
  winner: null, // 胜利者
  moveHistory: [], // 移动历史记录
  playCount: 0, // 游戏次数
  blackWins: 0, // 黑方胜场
  whiteWins: 0, // 白方胜场
  lastMove: null // 上一步移动位置
};

// DOM元素
const elements = {
  boardGrid: document.getElementById('board-grid'),
  currentPlayer: document.getElementById('current-player'),
  playCount: document.getElementById('play-count'),
  blackWins: document.getElementById('black-wins'),
  whiteWins: document.getElementById('white-wins'),
  winRate: document.getElementById('win-rate'),
  restartButton: document.getElementById('restart-game'),
  undoButton: document.getElementById('undo-move'),
  changePlayerButton: document.getElementById('change-player'),
  gameOverOverlay: document.getElementById('game-over-overlay'),
  winnerText: document.getElementById('winner-text'),
  playAgainButton: document.getElementById('play-again')
};

// 初始化游戏
function initGame() {
  // 从本地存储加载游戏数据
  loadGameData();
  
  // 设置棋盘大小
  setupBoardSize();
  
  // 初始化游戏
  resetGame();
  
  // 设置事件监听器
  setupEventListeners();
  
  // 更新UI
  updateUI();
}

// 设置棋盘大小
function setupBoardSize() {
  // 计算单元格大小
  const containerWidth = elements.boardGrid.parentElement.clientWidth;
  const maxSize = Math.min(containerWidth, 600); // 最大600px
  const cellSize = maxSize / config.boardSize;
  
  // 设置棋盘网格
  elements.boardGrid.style.gridTemplateColumns = `repeat(${config.boardSize}, ${cellSize}px)`;
  elements.boardGrid.style.gridTemplateRows = `repeat(${config.boardSize}, ${cellSize}px)`;
}

// 重置游戏
function resetGame() {
  // 重置游戏状态
  gameState.board = [];
  for (let y = 0; y < config.boardSize; y++) {
    gameState.board[y] = [];
    for (let x = 0; x < config.boardSize; x++) {
      gameState.board[y][x] = null;
    }
  }
  
  gameState.currentPlayer = config.initialPlayer;
  gameState.gameOver = false;
  gameState.winner = null;
  gameState.moveHistory = [];
  gameState.lastMove = null;
  
  // 渲染棋盘
  renderBoard();
  
  // 更新UI
  updateUI();
  
  // 隐藏游戏结束遮罩
  elements.gameOverOverlay.style.display = 'none';
  
  // 更新按钮状态
  updateButtonStates();
}

// 渲染棋盘
function renderBoard() {
  elements.boardGrid.innerHTML = '';
  
  // 创建棋盘单元格
  for (let y = 0; y < config.boardSize; y++) {
    for (let x = 0; x < config.boardSize; x++) {
      const cell = document.createElement('div');
      cell.classList.add('board-cell');
      cell.dataset.x = x;
      cell.dataset.y = y;
      elements.boardGrid.appendChild(cell);
    }
  }
  
  // 绘制棋盘上的五个黑点
  const markPositions = [
    {x: 3, y: 3},
    {x: 3, y: 11},
    {x: 7, y: 7},
    {x: 11, y: 3},
    {x: 11, y: 11}
  ];
  
  markPositions.forEach(pos => {
    const mark = document.createElement('div');
    mark.classList.add('board-mark');
    mark.style.left = `${pos.x * (100 / (config.boardSize - 1))}%`;
    mark.style.top = `${pos.y * (100 / (config.boardSize - 1))}%`;
    elements.boardGrid.appendChild(mark);
  });
  
  // 渲染棋子
  for (let y = 0; y < config.boardSize; y++) {
    for (let x = 0; x < config.boardSize; x++) {
      if (gameState.board[y][x]) {
        renderPiece(x, y, gameState.board[y][x]);
      }
    }
  }
}

// 渲染单个棋子
function renderPiece(x, y, player) {
  const cell = elements.boardGrid.querySelector(`[data-x="${x}"][data-y="${y}"]`);
  if (!cell) return;
  
  // 计算棋子位置
  const cellRect = cell.getBoundingClientRect();
  const boardRect = elements.boardGrid.getBoundingClientRect();
  
  const left = cellRect.left - boardRect.left + cellRect.width / 2;
  const top = cellRect.top - boardRect.top + cellRect.height / 2;
  const size = Math.min(cellRect.width, cellRect.height) * 0.85;
  
  // 创建棋子元素
  const piece = document.createElement('div');
  piece.classList.add('piece');
  piece.classList.add(player === 'black' ? 'piece-black' : 'piece-white');
  
  // 如果是最后一步，添加特殊样式
  if (gameState.lastMove && gameState.lastMove.x === x && gameState.lastMove.y === y) {
    piece.classList.add('piece-last');
  }
  
  piece.style.left = `${left}px`;
  piece.style.top = `${top}px`;
  piece.style.width = `${size}px`;
  piece.style.height = `${size}px`;
  
  // 添加到棋盘
  elements.boardGrid.appendChild(piece);
}

// 落子
function placePiece(x, y) {
  // 检查是否可以落子
  if (gameState.gameOver || gameState.board[y][x] !== null) {
    return false;
  }
  
  // 记录移动历史
  gameState.moveHistory.push({
    x: x,
    y: y,
    player: gameState.currentPlayer
  });
  
  // 更新棋盘状态
  gameState.board[y][x] = gameState.currentPlayer;
  gameState.lastMove = {x, y};
  
  // 渲染棋子
  renderPiece(x, y, gameState.currentPlayer);
  
  // 检查胜负
  if (checkWin(x, y)) {
    gameOver(gameState.currentPlayer);
    return true;
  }
  
  // 检查平局
  if (checkDraw()) {
    gameOver(null); // 平局
    return true;
  }
  
  // 切换玩家
  gameState.currentPlayer = gameState.currentPlayer === 'black' ? 'white' : 'black';
  
  // 更新UI
  updateUI();
  updateButtonStates();
  
  return true;
}

// 检查胜负
function checkWin(x, y) {
  const player = gameState.board[y][x];
  if (!player) return false;
  
  // 检查四个方向：水平、垂直、对角线1、对角线2
  const directions = [
    {dx: 1, dy: 0},  // 水平
    {dx: 0, dy: 1},  // 垂直
    {dx: 1, dy: 1},  // 对角线1
    {dx: 1, dy: -1}  // 对角线2
  ];
  
  for (const dir of directions) {
    let count = 1; // 当前位置已经有一个棋子
    
    // 向正方向检查
    for (let i = 1; i <= 4; i++) {
      const nx = x + dir.dx * i;
      const ny = y + dir.dy * i;
      
      if (nx >= 0 && nx < config.boardSize && ny >= 0 && ny < config.boardSize && 
          gameState.board[ny][nx] === player) {
        count++;
      } else {
        break;
      }
    }
    
    // 向反方向检查
    for (let i = 1; i <= 4; i++) {
      const nx = x - dir.dx * i;
      const ny = y - dir.dy * i;
      
      if (nx >= 0 && nx < config.boardSize && ny >= 0 && ny < config.boardSize && 
          gameState.board[ny][nx] === player) {
        count++;
      } else {
        break;
      }
    }
    
    // 如果有五个连续的棋子，返回胜利
    if (count >= 5) {
      return true;
    }
  }
  
  return false;
}

// 检查平局
function checkDraw() {
  for (let y = 0; y < config.boardSize; y++) {
    for (let x = 0; x < config.boardSize; x++) {
      if (gameState.board[y][x] === null) {
        return false; // 还有空位，不是平局
      }
    }
  }
  return true; // 棋盘已满，平局
}

// 游戏结束
function gameOver(winner) {
  gameState.gameOver = true;
  gameState.winner = winner;
  
  // 更新胜场数
  gameState.playCount++;
  if (winner === 'black') {
    gameState.blackWins++;
  } else if (winner === 'white') {
    gameState.whiteWins++;
  }
  
  // 保存游戏数据
  saveGameData();
  
  // 更新UI
  updateUI();
  updateButtonStates();
  
  // 显示游戏结束遮罩
  if (winner) {
    elements.winnerText.textContent = winner === 'black' ? '黑方' : '白方';
    elements.winnerText.className = winner === 'black' ? 'font-bold text-black' : 'font-bold text-gray-400';
  } else {
    elements.winnerText.textContent = '平局';
    elements.winnerText.className = 'font-bold text-gray-500';
  }
  
  elements.gameOverOverlay.style.display = 'flex';
}

// 悔棋
function undoMove() {
  if (gameState.moveHistory.length === 0 || gameState.gameOver) {
    return false;
  }
  
  // 获取最后一步移动
  const lastMove = gameState.moveHistory.pop();
  
  // 重置最后一步的位置
  gameState.board[lastMove.y][lastMove.x] = null;
  
  // 更新最后一步位置
  gameState.lastMove = gameState.moveHistory.length > 0 ? 
    gameState.moveHistory[gameState.moveHistory.length - 1] : null;
  
  // 切换回上一个玩家
  gameState.currentPlayer = lastMove.player;
  
  // 重新渲染棋盘
  renderBoard();
  
  // 更新UI
  updateUI();
  updateButtonStates();
  
  return true;
}

// 切换先手玩家
function toggleInitialPlayer() {
  config.initialPlayer = config.initialPlayer === 'black' ? 'white' : 'black';
  
  // 重置游戏
  resetGame();
}

// 更新UI显示
function updateUI() {
  // 更新当前玩家显示
  elements.currentPlayer.textContent = gameState.currentPlayer === 'black' ? '黑方' : '白方';
  elements.currentPlayer.className = gameState.currentPlayer === 'black' ? 
    'text-xl font-bold text-black ml-2' : 'text-xl font-bold text-gray-400 ml-2';
  
  // 更新游戏统计
  elements.playCount.textContent = gameState.playCount;
  elements.blackWins.textContent = gameState.blackWins;
  elements.whiteWins.textContent = gameState.whiteWins;
  
  // 计算胜率（基于总胜场数）
  const totalWins = gameState.blackWins + gameState.whiteWins;
  const winRate = totalWins > 0 ? 
    Math.round((gameState.currentPlayer === 'black' ? gameState.blackWins : gameState.whiteWins) / totalWins * 100) : 0;
  elements.winRate.textContent = `${winRate}%`;
}

// 更新按钮状态
function updateButtonStates() {
  // 更新悔棋按钮状态
  elements.undoButton.disabled = gameState.moveHistory.length === 0 || gameState.gameOver;
  
  // 如果游戏结束，改变悔棋按钮样式
  if (gameState.gameOver) {
    elements.undoButton.classList.add('bg-gray-100');
    elements.undoButton.classList.remove('bg-gray-200', 'hover:bg-gray-300');
  } else {
    elements.undoButton.classList.remove('bg-gray-100');
    elements.undoButton.classList.add('bg-gray-200', 'hover:bg-gray-300');
  }
}

// 设置事件监听器
function setupEventListeners() {
  // 棋盘点击事件
  elements.boardGrid.addEventListener('click', handleBoardClick);
  
  // 按钮事件
  elements.restartButton.addEventListener('click', resetGame);
  elements.undoButton.addEventListener('click', undoMove);
  elements.changePlayerButton.addEventListener('click', toggleInitialPlayer);
  elements.playAgainButton.addEventListener('click', resetGame);
  
  // 响应式处理
  window.addEventListener('resize', () => {
    setupBoardSize();
    renderBoard();
  });
}

// 处理棋盘点击
function handleBoardClick(event) {
  // 如果点击的是单元格
  if (event.target.classList.contains('board-cell')) {
    const x = parseInt(event.target.dataset.x);
    const y = parseInt(event.target.dataset.y);
    
    // 尝试落子
    placePiece(x, y);
  }
}

// 保存游戏数据到本地存储
function saveGameData() {
  const data = {
    playCount: gameState.playCount,
    blackWins: gameState.blackWins,
    whiteWins: gameState.whiteWins,
    initialPlayer: config.initialPlayer
  };
  localStorage.setItem('gobangGameData', JSON.stringify(data));
}

// 从本地存储加载游戏数据
function loadGameData() {
  const data = localStorage.getItem('gobangGameData');
  if (data) {
    try {
      const parsedData = JSON.parse(data);
      gameState.playCount = parsedData.playCount || 0;
      gameState.blackWins = parsedData.blackWins || 0;
      gameState.whiteWins = parsedData.whiteWins || 0;
      config.initialPlayer = parsedData.initialPlayer || 'black';
    } catch (error) {
      console.error('加载游戏数据失败:', error);
    }
  }
}

// 当页面加载完成时初始化游戏
window.addEventListener('load', initGame);