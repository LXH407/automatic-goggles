// 游戏配置
const config = {
  gridSize: 20, // 网格大小
  initialSpeed: 150, // 初始速度（毫秒）
  speedIncrement: 5, // 每得分10分速度增加的毫秒数
  minSpeed: 60 // 最小速度（毫秒）
};

// 游戏状态
const gameState = {
  snake: [],
  food: null,
  direction: 'right',
  nextDirection: 'right',
  score: 0,
  highScore: 0,
  playCount: 0,
  isRunning: false,
  isPaused: false,
  gameInterval: null,
  timeInterval: null,
  currentSpeed: config.initialSpeed,
  startTime: null,
  elapsedTime: 0
};

// DOM元素
const elements = {
  grid: document.getElementById('snake-grid'),
  score: document.getElementById('score'),
  highScore: document.getElementById('high-score'),
  playCount: document.getElementById('play-count'),
  gameTime: document.getElementById('game-time'),
  startButton: document.getElementById('start-game'),
  pauseButton: document.getElementById('pause-game'),
  restartButton: document.getElementById('restart-game'),
  gameOverOverlay: document.getElementById('game-over-overlay'),
  finalScore: document.getElementById('final-score'),
  finalTime: document.getElementById('final-time'),
  playAgainButton: document.getElementById('play-again'),
  // 移动端控制按钮
  upButton: document.getElementById('up-btn'),
  downButton: document.getElementById('down-btn'),
  leftButton: document.getElementById('left-btn'),
  rightButton: document.getElementById('right-btn')
};

// 格式化时间为 MM:SS 格式
function formatTime(seconds) {
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = seconds % 60;
  return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
}

// 更新游戏时间显示
function updateGameTime() {
  if (gameState.startTime && gameState.isRunning && !gameState.isPaused) {
    gameState.elapsedTime = Math.floor((Date.now() - gameState.startTime) / 1000);
    elements.gameTime.textContent = formatTime(gameState.elapsedTime);
  }
}

// 初始化游戏
function initGame() {
  // 从本地存储加载游戏数据
  loadGameData();
  
  // 设置网格大小
  const containerWidth = elements.grid.parentElement.clientWidth;
  const cellSize = Math.min(containerWidth / config.gridSize, 30); // 最大30px
  elements.grid.style.gridTemplateColumns = `repeat(${config.gridSize}, ${cellSize}px)`;
  elements.grid.style.gridTemplateRows = `repeat(${config.gridSize}, ${cellSize}px)`;
  
  // 初始化网格
  renderGrid();
  
  // 设置事件监听器
  setupEventListeners();
  
  // 初始化蛇的位置
  resetGame();
  
  // 更新UI显示
  updateUI();
}

// 渲染游戏网格
function renderGrid() {
  // 彻底清除网格内容
  elements.grid.innerHTML = '';
  
  // 创建文档片段以提高性能
  const fragment = document.createDocumentFragment();
  
  for (let y = 0; y < config.gridSize; y++) {
    for (let x = 0; x < config.gridSize; x++) {
      const cell = document.createElement('div');
      cell.classList.add('grid-cell');
      cell.dataset.x = x;
      cell.dataset.y = y;
      fragment.appendChild(cell);
    }
  }
  
  // 一次性将所有单元格添加到DOM
  elements.grid.appendChild(fragment);
}

// 初始化蛇的位置
function resetGame() {
  // 重置游戏状态
  gameState.snake = [
    { x: 5, y: 10 },
    { x: 4, y: 10 },
    { x: 3, y: 10 },
    { x: 2, y: 10 }
  ];
  gameState.direction = 'right';
  gameState.nextDirection = 'right';
  gameState.score = 0;
  gameState.currentSpeed = config.initialSpeed;
  gameState.isPaused = false;
  
  // 生成食物
  generateFood();
  
  // 更新UI
  renderSnake();
  renderFood();
  updateUI();
  
  // 隐藏游戏结束遮罩
  elements.gameOverOverlay.style.display = 'none';
  
  // 更新按钮状态
  elements.startButton.disabled = false;
  elements.pauseButton.disabled = true;
  elements.restartButton.disabled = true;
}

// 生成食物
function generateFood() {
  let x, y, isOnSnake;
  
  do {
    x = Math.floor(Math.random() * config.gridSize);
    y = Math.floor(Math.random() * config.gridSize);
    
    // 检查食物是否生成在蛇身上
    isOnSnake = gameState.snake.some(segment => segment.x === x && segment.y === y);
  } while (isOnSnake);
  
  gameState.food = { x, y };
}

// 渲染蛇
function renderSnake() {
  // 清除之前的蛇
  document.querySelectorAll('.grid-cell.snake-head, .grid-cell.snake-body').forEach(el => {
    el.classList.remove('snake-head', 'snake-body');
  });
  
  // 渲染蛇的身体
  gameState.snake.forEach((segment, index) => {
    const cell = getCell(segment.x, segment.y);
    if (cell && cell.classList.contains('grid-cell')) {
      // 确保先移除任何可能的旧类
      cell.classList.remove('snake-head', 'snake-body', 'food-item');
      
      if (index === 0) {
        cell.classList.add('snake-head');
      } else {
        cell.classList.add('snake-body');
      }
    }
  });
}

// 渲染食物
function renderFood() {
  // 清除之前的食物
  document.querySelectorAll('.grid-cell.food-item').forEach(el => {
    el.classList.remove('food-item');
  });
  
  // 渲染新食物
  if (gameState.food) {
    const cell = getCell(gameState.food.x, gameState.food.y);
    if (cell && cell.classList.contains('grid-cell')) {
      // 确保先移除任何可能的旧类
      cell.classList.remove('snake-head', 'snake-body', 'food-item');
      cell.classList.add('food-item');
    }
  }
}

// 获取网格单元格
function getCell(x, y) {
  return elements.grid.querySelector(`[data-x="${x}"][data-y="${y}"]`);
}

// 移动蛇
function moveSnake() {
  if (!gameState.isRunning || gameState.isPaused) return;
  
  // 更新方向
  gameState.direction = gameState.nextDirection;
  
  // 获取蛇头位置
  const head = { ...gameState.snake[0] };
  
  // 根据方向移动蛇头
  switch (gameState.direction) {
    case 'up':
      head.y -= 1;
      break;
    case 'down':
      head.y += 1;
      break;
    case 'left':
      head.x -= 1;
      break;
    case 'right':
      head.x += 1;
      break;
  }
  
  // 检查碰撞
  if (checkCollision(head)) {
    endGame();
    return;
  }
  
  // 将新的头部添加到蛇的数组前面
  gameState.snake.unshift(head);
  
  // 检查是否吃到食物
  if (head.x === gameState.food.x && head.y === gameState.food.y) {
    // 增加分数
    gameState.score += 10;
    
    // 更新最高分
    if (gameState.score > gameState.highScore) {
      gameState.highScore = gameState.score;
      saveGameData();
    }
    
    // 生成新食物
    generateFood();
    
    // 增加游戏速度
    gameState.currentSpeed = Math.max(config.minSpeed, config.initialSpeed - (gameState.score / 10) * config.speedIncrement);
    
    // 更新游戏速度
    clearInterval(gameState.gameInterval);
    gameState.gameInterval = setInterval(moveSnake, gameState.currentSpeed);
  } else {
    // 如果没有吃到食物，移除尾部
    gameState.snake.pop();
  }
  
  // 渲染蛇和食物
  renderSnake();
  renderFood();
  
  // 更新UI
  updateUI();
}

// 检查碰撞
function checkCollision(head) {
  // 检查是否撞到墙壁
  if (head.x < 0 || head.x >= config.gridSize || head.y < 0 || head.y >= config.gridSize) {
    return true;
  }
  
  // 检查是否撞到自己的身体
  for (let i = 1; i < gameState.snake.length; i++) {
    if (head.x === gameState.snake[i].x && head.y === gameState.snake[i].y) {
      return true;
    }
  }
  
  return false;
}

// 开始游戏
function startGame() {
  if (gameState.isRunning && !gameState.isPaused) return;
  
  if (gameState.isPaused) {
    // 继续游戏
    gameState.isPaused = false;
    // 调整开始时间，减去暂停的时间
    gameState.startTime = Date.now() - (gameState.elapsedTime * 1000);
    // 启动游戏循环
    gameState.gameInterval = setInterval(moveSnake, gameState.currentSpeed);
    // 启动时间更新
    gameState.timeInterval = setInterval(updateGameTime, 1000);
  } else {
    // 新游戏开始
    gameState.isRunning = true;
    gameState.isPaused = false;
    gameState.startTime = Date.now();
    gameState.elapsedTime = 0;
    
    // 增加游戏次数
    gameState.playCount++;
    saveGameData();
    
    // 更新按钮状态
    elements.startButton.disabled = true;
    elements.pauseButton.disabled = false;
    elements.restartButton.disabled = false;
    
    // 启动游戏循环
    gameState.gameInterval = setInterval(moveSnake, gameState.currentSpeed);
    // 启动时间更新
    gameState.timeInterval = setInterval(updateGameTime, 1000);
  }
  
  // 更新UI
  updateUI();
}

// 暂停游戏
function pauseGame() {
  if (!gameState.isRunning) return;
  
  if (!gameState.isPaused) {
    // 暂停游戏
    gameState.isPaused = true;
    clearInterval(gameState.gameInterval);
    clearInterval(gameState.timeInterval);
    
    // 更新按钮状态
    elements.startButton.disabled = false;
    elements.startButton.innerHTML = '<i class="fa fa-play mr-2"></i>继续游戏';
    elements.pauseButton.innerHTML = '<i class="fa fa-play mr-2"></i>继续游戏';
  } else {
    // 继续游戏
    gameState.isPaused = false;
    // 调整开始时间，减去暂停的时间
    gameState.startTime = Date.now() - (gameState.elapsedTime * 1000);
    // 重新启动游戏循环
    gameState.gameInterval = setInterval(moveSnake, gameState.currentSpeed);
    // 启动时间更新
    gameState.timeInterval = setInterval(updateGameTime, 1000);
    
    // 更新按钮状态
    elements.startButton.disabled = true;
    elements.pauseButton.innerHTML = '<i class="fa fa-pause mr-2"></i>暂停游戏';
  }
}

// 重新开始游戏
function restartGame() {
  // 清除游戏循环
  clearInterval(gameState.gameInterval);
  clearInterval(gameState.timeInterval);
  
  // 重置游戏
  resetGame();
}

// 结束游戏
function endGame() {
  // 清除游戏循环
  clearInterval(gameState.gameInterval);
  clearInterval(gameState.timeInterval);
  
  // 更新游戏状态
  gameState.isRunning = false;
  
  // 显示游戏结束遮罩
  elements.finalScore.textContent = gameState.score;
  elements.finalTime.textContent = formatTime(gameState.elapsedTime);
  elements.gameOverOverlay.style.display = 'flex';
  
  // 更新按钮状态
  elements.startButton.disabled = false;
  elements.pauseButton.disabled = true;
  elements.restartButton.disabled = true;
  
  // 保存游戏数据
  saveGameData();
}

// 更新UI显示
function updateUI() {
  elements.score.textContent = gameState.score;
  elements.highScore.textContent = gameState.highScore;
  elements.playCount.textContent = gameState.playCount;
  elements.gameTime.textContent = formatTime(gameState.elapsedTime);
}

// 设置事件监听器
function setupEventListeners() {
  // 键盘控制
  document.addEventListener('keydown', handleKeyDown);
  
  // 按钮控制
  elements.startButton.addEventListener('click', startGame);
  elements.pauseButton.addEventListener('click', pauseGame);
  elements.restartButton.addEventListener('click', restartGame);
  elements.playAgainButton.addEventListener('click', restartGame);
  
  // 移动端触摸控制
  elements.upButton.addEventListener('click', () => setDirection('up'));
  elements.downButton.addEventListener('click', () => setDirection('down'));
  elements.leftButton.addEventListener('click', () => setDirection('left'));
  elements.rightButton.addEventListener('click', () => setDirection('right'));
  
  // 响应式处理
  window.addEventListener('resize', () => {
    const containerWidth = elements.grid.parentElement.clientWidth;
    const cellSize = Math.min(containerWidth / config.gridSize, 30); // 最大30px
    elements.grid.style.gridTemplateColumns = `repeat(${config.gridSize}, ${cellSize}px)`;
    elements.grid.style.gridTemplateRows = `repeat(${config.gridSize}, ${cellSize}px)`;
    
    // 重新渲染蛇和食物
    renderSnake();
    renderFood();
  });
}

// 处理键盘按键
function handleKeyDown(event) {
  // 检查是否是组合键（如Alt+左箭头用于浏览器后退），如果是，则不阻止默认行为
  if (event.altKey || event.ctrlKey || event.metaKey) {
    return;
  }
  
  // 防止页面滚动，但只在游戏运行时阻止
  if (gameState.isRunning && ['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'w', 's', 'a', 'd'].includes(event.key.toLowerCase())) {
    event.preventDefault();
  }
  
  // 根据按键设置方向
  switch (event.key.toLowerCase()) {
    case 'arrowup':
    case 'w':
      setDirection('up');
      break;
    case 'arrowdown':
    case 's':
      setDirection('down');
      break;
    case 'arrowleft':
    case 'a':
      setDirection('left');
      break;
    case 'arrowright':
    case 'd':
      setDirection('right');
      break;
    case ' ': // 空格暂停/继续
      if (gameState.isRunning) {
        pauseGame();
      } else {
        startGame();
      }
      break;
    case 'r': // R键重新开始
      if (event.ctrlKey || event.metaKey) return; // 忽略Ctrl+R或Command+R
      restartGame();
      break;
  }
}

// 设置蛇的移动方向
function setDirection(newDirection) {
  // 防止蛇直接反向移动
  const oppositeDirections = {
    up: 'down',
    down: 'up',
    left: 'right',
    right: 'left'
  };
  
  // 只有当新方向不是当前方向的反向时才更新
  if (newDirection !== oppositeDirections[gameState.direction]) {
    gameState.nextDirection = newDirection;
  }
}

// 保存游戏数据到本地存储
function saveGameData() {
  const data = {
    highScore: gameState.highScore,
    playCount: gameState.playCount
  };
  localStorage.setItem('snakeGameData', JSON.stringify(data));
}

// 从本地存储加载游戏数据
function loadGameData() {
  const data = localStorage.getItem('snakeGameData');
  if (data) {
    try {
      const parsedData = JSON.parse(data);
      gameState.highScore = parsedData.highScore || 0;
      gameState.playCount = parsedData.playCount || 0;
    } catch (error) {
      console.error('加载游戏数据失败:', error);
    }
  }
}

// 当页面加载完成时初始化游戏
window.addEventListener('load', initGame);