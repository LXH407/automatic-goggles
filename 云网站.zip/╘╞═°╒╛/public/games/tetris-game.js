// 游戏配置
const config = {
  gridWidth: 10, // 游戏网格宽度
  gridHeight: 20, // 游戏网格高度
  initialSpeed: 1000, // 初始下落速度（毫秒）
  speedIncrement: 50, // 每消除10行速度增加的毫秒数
  minSpeed: 100, // 最小速度（毫秒）
  nextPieceGridSize: 4 // 下一个方块预览网格大小
};

// 方块形状定义
const TETROMINOS = {
  I: {
    shape: [
      [0, 0, 0, 0],
      [1, 1, 1, 1],
      [0, 0, 0, 0],
      [0, 0, 0, 0]
    ],
    color: 'I'
  },
  J: {
    shape: [
      [1, 0, 0],
      [1, 1, 1],
      [0, 0, 0]
    ],
    color: 'J'
  },
  L: {
    shape: [
      [0, 0, 1],
      [1, 1, 1],
      [0, 0, 0]
    ],
    color: 'L'
  },
  O: {
    shape: [
      [1, 1],
      [1, 1]
    ],
    color: 'O'
  },
  S: {
    shape: [
      [0, 1, 1],
      [1, 1, 0],
      [0, 0, 0]
    ],
    color: 'S'
  },
  T: {
    shape: [
      [0, 1, 0],
      [1, 1, 1],
      [0, 0, 0]
    ],
    color: 'T'
  },
  Z: {
    shape: [
      [1, 1, 0],
      [0, 1, 1],
      [0, 0, 0]
    ],
    color: 'Z'
  }
};

// 分数配置
const SCORE_VALUES = {
  single: 100, // 消除1行得分
  double: 300, // 消除2行得分
  triple: 500, // 消除3行得分
  tetris: 800, // 消除4行得分
  softDrop: 1, // 软降每格得分
  hardDrop: 2 // 硬降每格得分
};

// 游戏状态
const gameState = {
  grid: [], // 游戏网格
  currentPiece: null, // 当前方块
  nextPiece: null, // 下一个方块
  currentX: 0, // 当前方块X位置
  currentY: 0, // 当前方块Y位置
  score: 0, // 当前得分
  lines: 0, // 消除行数
  highScore: 0, // 最高分
  playCount: 0, // 游戏次数
  isRunning: false, // 游戏是否运行
  isPaused: false, // 游戏是否暂停
  gameInterval: null, // 游戏循环
  currentSpeed: config.initialSpeed // 当前速度
};

// DOM元素
const elements = {
  grid: document.getElementById('tetris-grid'),
  nextPieceGrid: document.getElementById('next-piece-grid'),
  score: document.getElementById('score'),
  lines: document.getElementById('lines'),
  highScore: document.getElementById('high-score'),
  playCount: document.getElementById('play-count'),
  startButton: document.getElementById('start-game'),
  pauseButton: document.getElementById('pause-game'),
  restartButton: document.getElementById('restart-game'),
  gameOverOverlay: document.getElementById('game-over-overlay'),
  finalScore: document.getElementById('final-score'),
  playAgainButton: document.getElementById('play-again'),
  // 移动端控制按钮
  rotateButton: document.getElementById('rotate-btn'),
  leftButton: document.getElementById('left-btn'),
  rightButton: document.getElementById('right-btn'),
  downButton: document.getElementById('down-btn'),
  dropButton: document.getElementById('drop-btn')
};

// 初始化游戏
function initGame() {
  // 从本地存储加载游戏数据
  loadGameData();
  
  // 设置网格大小
  setupGridSize();
  
  // 初始化游戏网格
  resetGrid();
  
  // 渲染网格
  renderGrid();
  renderNextPieceGrid();
  
  // 设置事件监听器
  setupEventListeners();
  
  // 初始化游戏状态
  resetGame();
  
  // 更新UI显示
  updateUI();
}

// 设置网格大小
function setupGridSize() {
  // 计算单元格大小
  const containerWidth = elements.grid.parentElement.clientWidth;
  const maxCellSize = Math.min(containerWidth / config.gridWidth, 30); // 最大30px
  
  // 设置主游戏网格
  elements.grid.style.gridTemplateColumns = `repeat(${config.gridWidth}, ${maxCellSize}px)`;
  elements.grid.style.gridTemplateRows = `repeat(${config.gridHeight}, ${maxCellSize}px)`;
  
  // 设置下一个方块预览网格
  const nextPieceCellSize = maxCellSize * 0.8; // 下一个方块预览单元格稍小
  elements.nextPieceGrid.style.gridTemplateColumns = `repeat(${config.nextPieceGridSize}, ${nextPieceCellSize}px)`;
  elements.nextPieceGrid.style.gridTemplateRows = `repeat(${config.nextPieceGridSize}, ${nextPieceCellSize}px)`;
}

// 重置游戏网格
function resetGrid() {
  gameState.grid = [];
  for (let y = 0; y < config.gridHeight; y++) {
    gameState.grid[y] = [];
    for (let x = 0; x < config.gridWidth; x++) {
      gameState.grid[y][x] = 0; // 0表示空
    }
  }
}

// 渲染游戏网格
function renderGrid() {
  elements.grid.innerHTML = '';
  
  for (let y = 0; y < config.gridHeight; y++) {
    for (let x = 0; x < config.gridWidth; x++) {
      const cell = document.createElement('div');
      cell.classList.add('grid-cell');
      if (gameState.grid[y][x]) {
        cell.classList.add(`cell-${gameState.grid[y][x]}`);
      }
      elements.grid.appendChild(cell);
    }
  }
}

// 渲染下一个方块预览网格
function renderNextPieceGrid() {
  elements.nextPieceGrid.innerHTML = '';
  
  for (let y = 0; y < config.nextPieceGridSize; y++) {
    for (let x = 0; x < config.nextPieceGridSize; x++) {
      const cell = document.createElement('div');
      cell.classList.add('grid-cell');
      elements.nextPieceGrid.appendChild(cell);
    }
  }
}

// 重置游戏
function resetGame() {
  // 重置游戏状态
  resetGrid();
  gameState.score = 0;
  gameState.lines = 0;
  gameState.currentSpeed = config.initialSpeed;
  gameState.isPaused = false;
  
  // 生成第一个方块和下一个方块
  gameState.nextPiece = generateRandomPiece();
  spawnNextPiece();
  
  // 隐藏游戏结束遮罩
  elements.gameOverOverlay.style.display = 'none';
  
  // 更新按钮状态
  elements.startButton.disabled = false;
  elements.pauseButton.disabled = true;
  elements.restartButton.disabled = true;
  
  // 更新UI
  updateUI();
  renderBoard();
}

// 生成随机方块
function generateRandomPiece() {
  const tetrominoKeys = Object.keys(TETROMINOS);
  const randomKey = tetrominoKeys[Math.floor(Math.random() * tetrominoKeys.length)];
  return TETROMINOS[randomKey];
}

// 生成下一个方块
function spawnNextPiece() {
  gameState.currentPiece = gameState.nextPiece;
  gameState.nextPiece = generateRandomPiece();
  
  // 设置初始位置（居中）
  gameState.currentX = Math.floor((config.gridWidth - gameState.currentPiece.shape[0].length) / 2);
  gameState.currentY = 0;
  
  // 检查游戏是否结束（新方块生成时就碰撞）
  if (checkCollision(gameState.currentPiece, gameState.currentX, gameState.currentY)) {
    endGame();
    return;
  }
  
  // 渲染游戏和下一个方块预览
  renderBoard();
  renderNextPiece();
}

// 渲染游戏画面
function renderBoard() {
  // 清除网格
  resetGrid();
  
  // 在网格上绘制当前方块
  if (gameState.currentPiece) {
    for (let y = 0; y < gameState.currentPiece.shape.length; y++) {
      for (let x = 0; x < gameState.currentPiece.shape[y].length; x++) {
        if (gameState.currentPiece.shape[y][x]) {
          const gridX = gameState.currentX + x;
          const gridY = gameState.currentY + y;
          
          // 确保在网格范围内
          if (gridY >= 0 && gridY < config.gridHeight && gridX >= 0 && gridX < config.gridWidth) {
            gameState.grid[gridY][gridX] = gameState.currentPiece.color;
          }
        }
      }
    }
  }
  
  // 渲染网格
  renderGrid();
}

// 渲染下一个方块预览
function renderNextPiece() {
  // 清除下一个方块预览网格
  const cells = elements.nextPieceGrid.querySelectorAll('.grid-cell');
  cells.forEach(cell => {
    cell.className = 'grid-cell';
  });
  
  // 渲染下一个方块
  if (gameState.nextPiece) {
    // 计算偏移量使方块居中显示
    const offsetX = Math.floor((config.nextPieceGridSize - gameState.nextPiece.shape[0].length) / 2);
    const offsetY = Math.floor((config.nextPieceGridSize - gameState.nextPiece.shape.length) / 2);
    
    for (let y = 0; y < gameState.nextPiece.shape.length; y++) {
      for (let x = 0; x < gameState.nextPiece.shape[y].length; x++) {
        if (gameState.nextPiece.shape[y][x]) {
          const gridX = offsetX + x;
          const gridY = offsetY + y;
          const index = gridY * config.nextPieceGridSize + gridX;
          
          if (index >= 0 && index < cells.length) {
            cells[index].classList.add(`cell-${gameState.nextPiece.color}`);
          }
        }
      }
    }
  }
}

// 检查碰撞
function checkCollision(piece, x, y) {
  for (let pieceY = 0; pieceY < piece.shape.length; pieceY++) {
    for (let pieceX = 0; pieceX < piece.shape[pieceY].length; pieceX++) {
      // 只有当方块有内容时才检查碰撞
      if (piece.shape[pieceY][pieceX]) {
        const gridX = x + pieceX;
        const gridY = y + pieceY;
        
        // 检查是否超出网格边界或与已有方块碰撞
        if (gridX < 0 || gridX >= config.gridWidth || 
            gridY >= config.gridHeight || 
            (gridY >= 0 && gameState.grid[gridY][gridX])) {
          return true;
        }
      }
    }
  }
  return false;
}

// 旋转方块
function rotatePiece() {
  if (!gameState.currentPiece || gameState.isPaused || !gameState.isRunning) return;
  
  // 创建旋转后的形状
  const rotatedShape = [];
  const rows = gameState.currentPiece.shape.length;
  const cols = gameState.currentPiece.shape[0].length;
  
  for (let i = 0; i < cols; i++) {
    rotatedShape[i] = [];
    for (let j = 0; j < rows; j++) {
      rotatedShape[i][j] = gameState.currentPiece.shape[rows - 1 - j][i];
    }
  }
  
  // 保存当前形状
  const originalShape = gameState.currentPiece.shape;
  
  // 应用旋转后的形状
  gameState.currentPiece.shape = rotatedShape;
  
  // 墙踢（wall kick）尝试 - 简单版本
  const wallKickOffsets = [0, -1, 1, -2, 2]; // 尝试不同的水平偏移量
  
  for (const offset of wallKickOffsets) {
    if (!checkCollision(gameState.currentPiece, gameState.currentX + offset, gameState.currentY)) {
      gameState.currentX += offset;
      renderBoard();
      return true;
    }
  }
  
  // 如果所有偏移都失败，恢复原始形状
  gameState.currentPiece.shape = originalShape;
  return false;
}

// 移动方块
function movePiece(dx, dy) {
  if (!gameState.currentPiece || gameState.isPaused || !gameState.isRunning) return false;
  
  const newX = gameState.currentX + dx;
  const newY = gameState.currentY + dy;
  
  if (!checkCollision(gameState.currentPiece, newX, newY)) {
    gameState.currentX = newX;
    gameState.currentY = newY;
    
    // 如果是向下移动，增加软降得分
    if (dy > 0 && gameState.isRunning) {
      gameState.score += SCORE_VALUES.softDrop * dy;
      updateUI();
    }
    
    renderBoard();
    return true;
  }
  return false;
}

// 硬降（直接落到底部）
function hardDrop() {
  if (!gameState.currentPiece || gameState.isPaused || !gameState.isRunning) return;
  
  // 计算可以下落的最大距离
  let dropDistance = 0;
  while (!checkCollision(gameState.currentPiece, gameState.currentX, gameState.currentY + dropDistance + 1)) {
    dropDistance++;
  }
  
  // 下落到底部
  if (dropDistance > 0) {
    gameState.currentY += dropDistance;
    
    // 增加硬降得分
    gameState.score += SCORE_VALUES.hardDrop * dropDistance;
    updateUI();
    
    renderBoard();
    
    // 固定方块并检查消除
    lockPiece();
  }
}

// 固定方块并检查消除
function lockPiece() {
  // 将当前方块固定到网格上
  for (let y = 0; y < gameState.currentPiece.shape.length; y++) {
    for (let x = 0; x < gameState.currentPiece.shape[y].length; x++) {
      if (gameState.currentPiece.shape[y][x]) {
        const gridX = gameState.currentX + x;
        const gridY = gameState.currentY + y;
        
        if (gridY >= 0 && gridY < config.gridHeight && gridX >= 0 && gridX < config.gridWidth) {
          gameState.grid[gridY][gridX] = gameState.currentPiece.color;
        }
      }
    }
  }
  
  // 检查并消除完整的行
  checkLines();
  
  // 生成下一个方块
  spawnNextPiece();
}

// 检查并消除完整的行
function checkLines() {
  let linesCleared = 0;
  
  // 从底部向上检查每一行
  for (let y = config.gridHeight - 1; y >= 0; y--) {
    let isLineComplete = true;
    
    // 检查当前行是否完整
    for (let x = 0; x < config.gridWidth; x++) {
      if (!gameState.grid[y][x]) {
        isLineComplete = false;
        break;
      }
    }
    
    // 如果行完整，消除该行
    if (isLineComplete) {
      linesCleared++;
      
      // 消除当前行
      gameState.grid.splice(y, 1);
      
      // 在顶部添加一行空行
      gameState.grid.unshift(new Array(config.gridWidth).fill(0));
      
      // 重新检查当前位置（因为上面的行掉下来了）
      y++;
    }
  }
  
  // 根据消除的行数增加分数
  if (linesCleared > 0) {
    gameState.lines += linesCleared;
    
    // 根据消除的行数计算得分
    switch (linesCleared) {
      case 1:
        gameState.score += SCORE_VALUES.single;
        break;
      case 2:
        gameState.score += SCORE_VALUES.double;
        break;
      case 3:
        gameState.score += SCORE_VALUES.triple;
        break;
      case 4:
        gameState.score += SCORE_VALUES.tetris;
        break;
    }
    
    // 更新最高分
    if (gameState.score > gameState.highScore) {
      gameState.highScore = gameState.score;
      saveGameData();
    }
    
    // 根据消除的行数调整游戏速度
    updateGameSpeed();
    
    // 更新UI
    updateUI();
  }
}

// 更新游戏速度
function updateGameSpeed() {
  const level = Math.floor(gameState.lines / 10);
  gameState.currentSpeed = Math.max(config.minSpeed, config.initialSpeed - level * config.speedIncrement);
  
  // 如果游戏正在运行，更新游戏循环
  if (gameState.isRunning && !gameState.isPaused) {
    clearInterval(gameState.gameInterval);
    gameState.gameInterval = setInterval(gameLoop, gameState.currentSpeed);
  }
}

// 游戏主循环
function gameLoop() {
  if (gameState.isPaused || !gameState.isRunning) return;
  
  // 尝试向下移动方块
  if (!movePiece(0, 1)) {
    // 如果不能移动，固定方块并检查消除
    lockPiece();
  }
}

// 开始游戏
function startGame() {
  if (gameState.isRunning) return;
  
  // 更新游戏状态
  gameState.isRunning = true;
  gameState.isPaused = false;
  
  // 增加游戏次数
  gameState.playCount++;
  saveGameData();
  
  // 开始游戏循环
  gameState.gameInterval = setInterval(gameLoop, gameState.currentSpeed);
  
  // 更新按钮状态
  elements.startButton.disabled = true;
  elements.pauseButton.disabled = false;
  elements.restartButton.disabled = false;
  
  // 更新UI
  updateUI();
}

// 暂停游戏
function pauseGame() {
  if (!gameState.isRunning) return;
  
  // 切换暂停状态
  gameState.isPaused = !gameState.isPaused;
  
  // 更新按钮文本
  if (gameState.isPaused) {
    elements.pauseButton.innerHTML = '<i class="fa fa-play mr-2"></i>继续游戏';
  } else {
    elements.pauseButton.innerHTML = '<i class="fa fa-pause mr-2"></i>暂停游戏';
  }
}

// 重新开始游戏
function restartGame() {
  // 清除游戏循环
  clearInterval(gameState.gameInterval);
  
  // 重置游戏
  resetGame();
}

// 结束游戏
function endGame() {
  // 清除游戏循环
  clearInterval(gameState.gameInterval);
  
  // 更新游戏状态
  gameState.isRunning = false;
  
  // 显示游戏结束遮罩
  elements.finalScore.textContent = gameState.score;
  elements.gameOverOverlay.style.display = 'flex';
  
  // 更新按钮状态
  elements.startButton.disabled = false;
  elements.pauseButton.disabled = true;
  elements.restartButton.disabled = true;
  
  // 保存游戏数据
  saveGameData();
}

// 更新UI显示
function updateUI() {
  elements.score.textContent = gameState.score;
  elements.lines.textContent = gameState.lines;
  elements.highScore.textContent = gameState.highScore;
  elements.playCount.textContent = gameState.playCount;
}

// 设置事件监听器
function setupEventListeners() {
  // 键盘控制
  document.addEventListener('keydown', handleKeyDown);
  
  // 按钮控制
  elements.startButton.addEventListener('click', startGame);
  elements.pauseButton.addEventListener('click', pauseGame);
  elements.restartButton.addEventListener('click', restartGame);
  elements.playAgainButton.addEventListener('click', restartGame);
  
  // 移动端触摸控制
  elements.rotateButton.addEventListener('click', rotatePiece);
  elements.leftButton.addEventListener('click', () => movePiece(-1, 0));
  elements.rightButton.addEventListener('click', () => movePiece(1, 0));
  elements.downButton.addEventListener('click', () => movePiece(0, 1));
  elements.dropButton.addEventListener('click', hardDrop);
  
  // 响应式处理
  window.addEventListener('resize', () => {
    setupGridSize();
    renderBoard();
    renderNextPiece();
  });
}

// 处理键盘按键
function handleKeyDown(event) {
  // 检查是否是组合键（如Alt+左箭头用于浏览器后退），如果是，则不阻止默认行为
  if (event.altKey || event.ctrlKey || event.metaKey) {
    return;
  }
  
  // 防止页面滚动，但只在游戏运行时阻止
  if (gameState.isRunning && ['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', ' '].includes(event.key)) {
    event.preventDefault();
  }
  
  if (gameState.isPaused || !gameState.isRunning) {
    if (event.key === ' ' || event.key === 'Enter') {
      if (gameState.isPaused) {
        pauseGame();
      } else {
        startGame();
      }
    }
    return;
  }
  
  // 根据按键执行相应操作
  switch (event.key) {
    case 'ArrowUp': // 旋转方块
      rotatePiece();
      break;
    case 'ArrowLeft': // 向左移动
      movePiece(-1, 0);
      break;
    case 'ArrowRight': // 向右移动
      movePiece(1, 0);
      break;
    case 'ArrowDown': // 向下移动
      movePiece(0, 1);
      break;
    case ' ':
      // 空格键硬降
      hardDrop();
      break;
    case 'p':
    case 'P':
      // P键暂停/继续游戏
      pauseGame();
      break;
    case 'r':
    case 'R':
      // R键重新开始游戏
      if (event.ctrlKey || event.metaKey) return; // 忽略Ctrl+R或Command+R
      restartGame();
      break;
  }
}

// 保存游戏数据到本地存储
function saveGameData() {
  const data = {
    highScore: gameState.highScore,
    playCount: gameState.playCount
  };
  localStorage.setItem('tetrisGameData', JSON.stringify(data));
}

// 从本地存储加载游戏数据
function loadGameData() {
  const data = localStorage.getItem('tetrisGameData');
  if (data) {
    try {
      const parsedData = JSON.parse(data);
      gameState.highScore = parsedData.highScore || 0;
      gameState.playCount = parsedData.playCount || 0;
    } catch (error) {
      console.error('加载游戏数据失败:', error);
    }
  }
}

// 当页面加载完成时初始化游戏
window.addEventListener('load', initGame);