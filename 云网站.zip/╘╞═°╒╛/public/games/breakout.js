// 游戏配置
const config = {
  width: 600, // 游戏区域宽度
  height: 400, // 游戏区域高度
  paddleWidth: 80, // 挡板宽度
  paddleHeight: 12, // 挡板高度
  paddleSpeed: 8, // 挡板移动速度
  ballRadius: 8, // 球半径
  ballSpeed: 5, // 初始球速度
  brickRows: 5, // 砖块行数
  brickCols: 10, // 砖块列数
  brickPadding: 5, // 砖块间距
  brickOffsetTop: 40, // 砖块顶部偏移
  brickOffsetLeft: 35, // 砖块左侧偏移
  brickWidth: 50, // 砖块宽度
  brickHeight: 20, // 砖块高度
  lives: 3, // 初始生命值
  maxLevels: 10, // 最大等级
  initialBricks: 50, // 初始砖块数量
  // 砖块颜色和强度
  brickTypes: [
    { color: 'brick1', strength: 1, points: 10 },
    { color: 'brick2', strength: 1, points: 20 },
    { color: 'brick3', strength: 2, points: 30 },
    { color: 'brick4', strength: 2, points: 40 },
    { color: 'brick5', strength: 3, points: 50 }
  ],
  // 道具配置
  powerUpTypes: [
    { type: 'extraLife', color: '#FF6B6B', icon: '\u2764', chance: 0.05 },
    { type: 'paddleExpand', color: '#165DFF', icon: '\u25A0', chance: 0.1 },
    { type: 'paddleShrink', color: '#6E56CF', icon: '\u25A1', chance: 0.05 },
    { type: 'multiBall', color: '#FFD166', icon: '\u25CF', chance: 0.05 },
    { type: 'slowBall', color: '#06D6A0', icon: '\u23F8', chance: 0.1 }
  ],
  powerUpSize: 15, // 道具大小
  powerUpSpeed: 3, // 道具下落速度
  // 音效配置
  soundEffects: {
    ballHit: true,
    brickBreak: true,
    powerUpCollect: true,
    gameOver: true,
    levelComplete: true
  },
  // 粒子效果配置
  particleEffects: {
    enabled: true,
    particlesPerBrick: 10
  }
};

// 游戏状态
const gameState = {
  board: [],
  paddleX: 0,
  balls: [],
  score: 0,
  highScore: 0,
  lives: config.lives,
  level: 1,
  remainingBricks: 0,
  isRunning: false,
  isPaused: false,
  gameInterval: null,
  keys: {
    left: false,
    right: false
  },
  mouseX: 0,
  powerUps: [],
  particleEffects: []
};

// DOM元素
const elements = {
  gameGrid: document.getElementById('game-grid'),
  paddle: document.getElementById('paddle') || createPaddle(),
  currentScore: document.getElementById('current-score'),
  highScore: document.getElementById('high-score'),
  lives: document.getElementById('lives'),
  currentLevel: document.getElementById('current-level'),
  remainingBricks: document.getElementById('remaining-bricks'),
  startButton: document.getElementById('start-button'),
  pauseButton: document.getElementById('pause-button'),
  restartButton: document.getElementById('restart-button'),
  gameOverOverlay: document.getElementById('game-over-overlay'),
  gameOverTitle: document.getElementById('game-over-title'),
  gameOverScore: document.getElementById('game-over-score'),
  gameOverLevel: document.getElementById('game-over-level'),
  playAgainButton: document.getElementById('play-again-button'),
  menuToggle: document.getElementById('menu-toggle'),
  mobileMenu: document.getElementById('mobile-menu'),
  // 移动端控制按钮
  mobileLeft: document.getElementById('mobile-left'),
  mobileRight: document.getElementById('mobile-right'),
  mobileFire: document.getElementById('mobile-fire')
};

// 创建挡板元素
function createPaddle() {
  const paddle = document.createElement('div');
  paddle.id = 'paddle';
  paddle.className = 'breakout-paddle';
  paddle.style.width = `${config.paddleWidth}px`;
  paddle.style.height = `${config.paddleHeight}px`;
  elements.gameGrid.appendChild(paddle);
  return paddle;
}

// 初始化游戏
function initGame() {
  // 设置游戏网格尺寸
  elements.gameGrid.style.width = `${config.width}px`;
  elements.gameGrid.style.height = `${config.height}px`;
  
  // 加载游戏数据
  loadGameData();
  
  // 初始化游戏状态
  initializeGameState();
  
  // 生成砖块
  generateBricks();
  
  // 渲染游戏
  renderGame();
  
  // 设置事件监听器
  setupEventListeners();
  
  // 更新UI
  updateUI();
}

// 初始化游戏状态
function initializeGameState() {
  // 清空游戏状态
  gameState.board = [];
  gameState.balls = [];
  gameState.powerUps = [];
  gameState.particleEffects = [];
  
  // 设置挡板初始位置
  gameState.paddleX = (config.width - config.paddleWidth) / 2;
  
  // 创建一个新球
  gameState.balls.push({
    x: config.width / 2,
    y: config.height - config.paddleHeight - config.ballRadius - 10,
    dx: 0,
    dy: 0
  });
  
  // 重置游戏状态
  gameState.score = 0;
  gameState.lives = config.lives;
  gameState.level = 1;
  gameState.remainingBricks = 0;
  gameState.isRunning = false;
  gameState.isPaused = false;
  
  // 重置按键状态
  gameState.keys.left = false;
  gameState.keys.right = false;
}

// 生成砖块
function generateBricks() {
  gameState.board = [];
  gameState.remainingBricks = 0;
  
  // 清空游戏网格中的砖块
  const existingBricks = elements.gameGrid.querySelectorAll('.breakout-brick');
  existingBricks.forEach(brick => brick.remove());
  
  // 根据等级生成砖块
  for (let row = 0; row < config.brickRows; row++) {
    gameState.board[row] = [];
    for (let col = 0; col < config.brickCols; col++) {
      // 确定砖块类型（根据行）
      const brickTypeIndex = Math.min(row, config.brickTypes.length - 1);
      const brickType = config.brickTypes[brickTypeIndex];
      
      // 根据等级调整砖块强度
      const strength = Math.min(brickType.strength + Math.floor(gameState.level / 3), 5);
      
      // 记录砖块信息
      gameState.board[row][col] = {
        type: brickTypeIndex,
        strength: strength,
        points: brickType.points * gameState.level,
        visible: true
      };
      
      // 创建砖块元素
      const brick = document.createElement('div');
      brick.className = `breakout-brick ${brickType.color}`;
      brick.id = `brick-${row}-${col}`;
      
      // 设置砖块位置和尺寸
      brick.style.width = `${config.brickWidth}px`;
      brick.style.height = `${config.brickHeight}px`;
      brick.style.left = `${col * (config.brickWidth + config.brickPadding) + config.brickOffsetLeft}px`;
      brick.style.top = `${row * (config.brickHeight + config.brickPadding) + config.brickOffsetTop}px`;
      
      // 添加到游戏网格
      elements.gameGrid.appendChild(brick);
      
      // 增加剩余砖块计数
      gameState.remainingBricks++;
    }
  }
}

// 渲染游戏
function renderGame() {
  // 渲染挡板
  renderPaddle();
  
  // 渲染球
  renderBalls();
  
  // 渲染道具
  renderPowerUps();
  
  // 渲染粒子效果
  renderParticleEffects();
  
  // 更新砖块显示状态
  updateBricksVisibility();
}

// 渲染挡板
function renderPaddle() {
  // 限制挡板在游戏区域内
  gameState.paddleX = Math.max(0, Math.min(config.width - config.paddleWidth, gameState.paddleX));
  
  // 更新挡板位置
  elements.paddle.style.transform = `translateX(${gameState.paddleX}px)`;
}

// 渲染球
function renderBalls() {
  // 移除所有现有球
  const existingBalls = elements.gameGrid.querySelectorAll('.breakout-ball');
  existingBalls.forEach(ball => ball.remove());
  
  // 创建新球
  gameState.balls.forEach((ball, index) => {
    const ballElement = document.createElement('div');
    ballElement.className = 'breakout-ball';
    ballElement.id = `ball-${index}`;
    ballElement.style.width = `${config.ballRadius * 2}px`;
    ballElement.style.height = `${config.ballRadius * 2}px`;
    ballElement.style.transform = `translate(${ball.x - config.ballRadius}px, ${ball.y - config.ballRadius}px)`;
    elements.gameGrid.appendChild(ballElement);
  });
}

// 渲染道具
function renderPowerUps() {
  // 移除所有现有道具
  const existingPowerUps = elements.gameGrid.querySelectorAll('.power-up');
  existingPowerUps.forEach(powerUp => powerUp.remove());
  
  // 创建新道具
  gameState.powerUps.forEach((powerUp, index) => {
    const powerUpElement = document.createElement('div');
    powerUpElement.className = 'power-up';
    powerUpElement.id = `power-up-${index}`;
    powerUpElement.style.width = `${config.powerUpSize}px`;
    powerUpElement.style.height = `${config.powerUpSize}px`;
    powerUpElement.style.backgroundColor = powerUp.color;
    powerUpElement.style.transform = `translate(${powerUp.x - config.powerUpSize / 2}px, ${powerUp.y - config.powerUpSize / 2}px)`;
    powerUpElement.textContent = powerUp.icon;
    elements.gameGrid.appendChild(powerUpElement);
  });
}

// 渲染粒子效果
function renderParticleEffects() {
  // 移除所有现有粒子
  const existingParticles = elements.gameGrid.querySelectorAll('.particle');
  existingParticles.forEach(particle => particle.remove());
  
  // 更新粒子位置
  for (let i = gameState.particleEffects.length - 1; i >= 0; i--) {
    const effect = gameState.particleEffects[i];
    
    // 更新粒子
    for (let j = effect.particles.length - 1; j >= 0; j--) {
      const particle = effect.particles[j];
      particle.x += particle.vx;
      particle.y += particle.vy;
      particle.life--;
      
      // 移除生命结束的粒子
      if (particle.life <= 0) {
        effect.particles.splice(j, 1);
      }
    }
    
    // 如果效果中没有粒子了，移除效果
    if (effect.particles.length === 0) {
      gameState.particleEffects.splice(i, 1);
    } else {
      // 创建粒子元素
      effect.particles.forEach((particle, index) => {
        const particleElement = document.createElement('div');
        particleElement.className = 'particle';
        particleElement.style.position = 'absolute';
        particleElement.style.width = `${particle.size}px`;
        particleElement.style.height = `${particle.size}px`;
        particleElement.style.backgroundColor = particle.color;
        particleElement.style.borderRadius = '50%';
        particleElement.style.opacity = particle.life / particle.maxLife;
        particleElement.style.transform = `translate(${particle.x}px, ${particle.y}px)`;
        elements.gameGrid.appendChild(particleElement);
      });
    }
  }
}

// 更新砖块显示状态
function updateBricksVisibility() {
  for (let row = 0; row < config.brickRows; row++) {
    for (let col = 0; col < config.brickCols; col++) {
      const brick = gameState.board[row][col];
      const brickElement = document.getElementById(`brick-${row}-${col}`);
      
      if (brick && brickElement) {
        if (brick.visible) {
          brickElement.style.display = 'block';
          // 根据砖块强度调整样式
          brickElement.style.opacity = Math.min(1, brick.strength / 5);
          brickElement.style.transform = `scale(${Math.min(1, brick.strength / 5 + 0.5)})`;
        } else {
          brickElement.style.display = 'none';
        }
      }
    }
  }
}

// 更新游戏状态
function updateGame() {
  if (!gameState.isRunning || gameState.isPaused) {
    return;
  }
  
  // 更新挡板位置
  updatePaddlePosition();
  
  // 更新球的位置
  updateBallPositions();
  
  // 更新道具位置
  updatePowerUpPositions();
  
  // 检查砖块是否全部消除
  checkLevelComplete();
  
  // 渲染游戏
  renderGame();
  
  // 更新UI
  updateUI();
}

// 更新挡板位置
function updatePaddlePosition() {
  // 根据按键状态移动挡板
  if (gameState.keys.left) {
    gameState.paddleX -= config.paddleSpeed;
  }
  if (gameState.keys.right) {
    gameState.paddleX += config.paddleSpeed;
  }
  
  // 根据鼠标位置移动挡板
  if (gameState.mouseX !== null) {
    gameState.paddleX = gameState.mouseX - config.paddleWidth / 2;
  }
  
  // 限制挡板在游戏区域内
  gameState.paddleX = Math.max(0, Math.min(config.width - config.paddleWidth, gameState.paddleX));
}

// 更新球的位置
function updateBallPositions() {
  for (let i = gameState.balls.length - 1; i >= 0; i--) {
    const ball = gameState.balls[i];
    
    // 更新球位置
    ball.x += ball.dx;
    ball.y += ball.dy;
    
    // 检查墙壁碰撞
    // 左右墙壁
    if (ball.x - config.ballRadius <= 0 || ball.x + config.ballRadius >= config.width) {
      ball.dx = -ball.dx;
      playSound('ballHit');
    }
    
    // 上墙壁
    if (ball.y - config.ballRadius <= 0) {
      ball.dy = -ball.dy;
      playSound('ballHit');
    }
    
    // 下墙壁（失去生命）
    if (ball.y + config.ballRadius >= config.height) {
      gameState.balls.splice(i, 1);
      
      // 如果没有球了，减少生命值
      if (gameState.balls.length === 0) {
        loseLife();
      }
    }
    
    // 检查挡板碰撞
    if (checkPaddleCollision(ball)) {
      // 根据球击中挡板的位置调整反弹角度
      const hitPosition = (ball.x - (gameState.paddleX + config.paddleWidth / 2)) / (config.paddleWidth / 2);
      const angle = hitPosition * Math.PI / 3; // 最大60度角
      
      // 计算新的速度向量
      const speed = Math.sqrt(ball.dx * ball.dx + ball.dy * ball.dy);
      ball.dx = speed * Math.sin(angle);
      ball.dy = -Math.abs(speed * Math.cos(angle)); // 确保向上反弹
      
      playSound('ballHit');
    }
    
    // 检查砖块碰撞
    checkBrickCollision(ball);
  }
}

// 更新道具位置
function updatePowerUpPositions() {
  for (let i = gameState.powerUps.length - 1; i >= 0; i--) {
    const powerUp = gameState.powerUps[i];
    
    // 更新道具位置
    powerUp.y += config.powerUpSpeed;
    
    // 检查道具是否超出游戏区域
    if (powerUp.y > config.height) {
      gameState.powerUps.splice(i, 1);
      continue;
    }
    
    // 检查道具与挡板碰撞
    if (checkPowerUpCollision(powerUp)) {
      // 应用道具效果
      applyPowerUp(powerUp.type);
      
      // 移除道具
      gameState.powerUps.splice(i, 1);
      
      playSound('powerUpCollect');
    }
  }
}

// 检查挡板碰撞
function checkPaddleCollision(ball) {
  return (
    ball.y + config.ballRadius >= config.height - config.paddleHeight &&
    ball.y - config.ballRadius <= config.height &&
    ball.x + config.ballRadius >= gameState.paddleX &&
    ball.x - config.ballRadius <= gameState.paddleX + config.paddleWidth
  );
}

// 检查砖块碰撞
function checkBrickCollision(ball) {
  for (let row = 0; row < config.brickRows; row++) {
    for (let col = 0; col < config.brickCols; col++) {
      const brick = gameState.board[row][col];
      
      if (brick && brick.visible) {
        const brickX = col * (config.brickWidth + config.brickPadding) + config.brickOffsetLeft;
        const brickY = row * (config.brickHeight + config.brickPadding) + config.brickOffsetTop;
        
        // 检查球与砖块的碰撞
        if (
          ball.x + config.ballRadius >= brickX &&
          ball.x - config.ballRadius <= brickX + config.brickWidth &&
          ball.y + config.ballRadius >= brickY &&
          ball.y - config.ballRadius <= brickY + config.brickHeight
        ) {
          // 计算碰撞方向
          const ballCenterX = ball.x;
          const ballCenterY = ball.y;
          const brickCenterX = brickX + config.brickWidth / 2;
          const brickCenterY = brickY + config.brickHeight / 2;
          
          const dx = ballCenterX - brickCenterX;
          const dy = ballCenterY - brickCenterY;
          
          // 判断碰撞方向（水平或垂直）
          if (Math.abs(dx) > Math.abs(dy)) {
            // 水平碰撞
            ball.dx = -ball.dx;
          } else {
            // 垂直碰撞
            ball.dy = -ball.dy;
          }
          
          // 减少砖块强度
          brick.strength--;
          
          // 如果砖块强度为0，标记为不可见
          if (brick.strength <= 0) {
            brick.visible = false;
            gameState.remainingBricks--;
            
            // 增加分数
            gameState.score += brick.points;
            
            // 更新最高分
            if (gameState.score > gameState.highScore) {
              gameState.highScore = gameState.score;
              saveGameData();
            }
            
            // 随机生成道具
            generatePowerUp(brickX + config.brickWidth / 2, brickY + config.brickHeight / 2);
            
            // 创建砖块爆炸粒子效果
            createBrickExplosion(brickX + config.brickWidth / 2, brickY + config.brickHeight / 2, config.brickTypes[brick.type].color);
            
            playSound('brickBreak');
          }
          
          return;
        }
      }
    }
  }
}

// 检查道具碰撞
function checkPowerUpCollision(powerUp) {
  return (
    powerUp.y + config.powerUpSize / 2 >= config.height - config.paddleHeight &&
    powerUp.y - config.powerUpSize / 2 <= config.height &&
    powerUp.x + config.powerUpSize / 2 >= gameState.paddleX &&
    powerUp.x - config.powerUpSize / 2 <= gameState.paddleX + config.paddleWidth
  );
}

// 生成道具
function generatePowerUp(x, y) {
  // 随机选择是否生成道具
  if (Math.random() > 0.3) { // 30%的概率生成道具
    return;
  }
  
  // 随机选择道具类型
  const availablePowerUps = config.powerUpTypes.filter(p => Math.random() < p.chance);
  
  if (availablePowerUps.length > 0) {
    const powerUpType = availablePowerUps[Math.floor(Math.random() * availablePowerUps.length)];
    
    gameState.powerUps.push({
      x: x,
      y: y,
      type: powerUpType.type,
      color: powerUpType.color,
      icon: powerUpType.icon
    });
  }
}

// 应用道具效果
function applyPowerUp(type) {
  switch (type) {
    case 'extraLife':
      if (gameState.lives < 5) { // 最多5条命
        gameState.lives++;
      }
      break;
    case 'paddleExpand':
      if (config.paddleWidth < 120) { // 最大宽度120
        config.paddleWidth += 20;
        elements.paddle.style.width = `${config.paddleWidth}px`;
      }
      break;
    case 'paddleShrink':
      if (config.paddleWidth > 40) { // 最小宽度40
        config.paddleWidth -= 20;
        elements.paddle.style.width = `${config.paddleWidth}px`;
      }
      break;
    case 'multiBall':
      // 添加2个额外的球
      for (let i = 0; i < 2; i++) {
        gameState.balls.push({
          x: gameState.balls[0].x,
          y: gameState.balls[0].y,
          dx: Math.random() * 6 - 3, // 随机水平速度
          dy: -Math.abs(Math.random() * 4 + 3) // 向上的随机速度
        });
      }
      break;
    case 'slowBall':
      // 降低所有球的速度
      gameState.balls.forEach(ball => {
        const speed = Math.sqrt(ball.dx * ball.dx + ball.dy * ball.dy);
        const targetSpeed = Math.max(3, speed * 0.7); // 最低速度3
        const ratio = targetSpeed / speed;
        ball.dx *= ratio;
        ball.dy *= ratio;
      });
      
      // 5秒后恢复正常速度
      setTimeout(() => {
        if (gameState.isRunning && !gameState.isPaused) {
          gameState.balls.forEach(ball => {
            const speed = Math.sqrt(ball.dx * ball.dx + ball.dy * ball.dy);
            const ratio = config.ballSpeed / speed;
            ball.dx *= ratio;
            ball.dy *= ratio;
          });
        }
      }, 5000);
      break;
  }
}

// 创建砖块爆炸粒子效果
function createBrickExplosion(x, y, color) {
  if (!config.particleEffects.enabled) return;
  
  const particles = [];
  
  for (let i = 0; i < config.particleEffects.particlesPerBrick; i++) {
    const angle = Math.random() * Math.PI * 2;
    const speed = Math.random() * 3 + 1;
    const size = Math.random() * 3 + 2;
    const life = Math.floor(Math.random() * 20) + 20;
    
    particles.push({
      x: x,
      y: y,
      vx: Math.cos(angle) * speed,
      vy: Math.sin(angle) * speed,
      size: size,
      color: document.querySelector(`.${color}`).style.backgroundColor,
      life: life,
      maxLife: life
    });
  }
  
  gameState.particleEffects.push({ particles: particles });
}

// 检查等级是否完成
function checkLevelComplete() {
  if (gameState.remainingBricks <= 0) {
    if (gameState.level >= config.maxLevels) {
      // 游戏胜利
      gameState.isRunning = false;
      clearInterval(gameState.gameInterval);
      
      // 更新游戏结束信息
      elements.gameOverTitle.textContent = '游戏胜利！';
      elements.gameOverScore.textContent = gameState.score;
      elements.gameOverLevel.textContent = gameState.level;
      
      // 显示游戏结束遮罩
      elements.gameOverOverlay.classList.remove('hidden');
      
      playSound('levelComplete');
      
      // 更新按钮状态
      elements.startButton.disabled = false;
      elements.pauseButton.disabled = true;
      elements.restartButton.disabled = true;
    } else {
      // 进入下一关
      levelUp();
    }
  }
}

// 升级
function levelUp() {
  gameState.level++;
  
  // 清空游戏循环
  clearInterval(gameState.gameInterval);
  
  // 重置球和挡板
  gameState.balls = [{
    x: config.width / 2,
    y: config.height - config.paddleHeight - config.ballRadius - 10,
    dx: 0,
    dy: 0
  }];
  
  gameState.paddleX = (config.width - config.paddleWidth) / 2;
  
  // 生成新的砖块
  generateBricks();
  
  // 渲染游戏
  renderGame();
  
  // 更新UI
  updateUI();
  
  // 暂停一会儿
  gameState.isPaused = true;
  
  // 2秒后继续游戏
  setTimeout(() => {
    if (gameState.isRunning) {
      gameState.isPaused = false;
      
      // 启动游戏循环
      gameState.gameInterval = setInterval(gameLoop, 16); // 约60fps
      
      // 发射球
      launchBall();
    }
  }, 2000);
  
  playSound('levelComplete');
}

// 失去生命
function loseLife() {
  gameState.lives--;
  
  if (gameState.lives <= 0) {
    endGame();
  } else {
    // 重置球的位置
    gameState.balls = [{
      x: config.width / 2,
      y: config.height - config.paddleHeight - config.ballRadius - 10,
      dx: 0,
      dy: 0
    }];
    
    // 重置挡板位置
    gameState.paddleX = (config.width - config.paddleWidth) / 2;
    
    // 暂停一会儿
    gameState.isPaused = true;
    
    // 1秒后继续游戏
    setTimeout(() => {
      if (gameState.isRunning) {
        gameState.isPaused = false;
      }
    }, 1000);
  }
  
  // 更新UI
  updateUI();
}

// 发射球
function launchBall() {
  if (!gameState.isRunning || gameState.isPaused) return;
  
  // 检查球是否静止
  if (gameState.balls[0].dx === 0 && gameState.balls[0].dy === 0) {
    // 随机生成初始速度方向
    const angle = (Math.random() * 0.5 + 0.25) * Math.PI; // 45度到135度之间
    const speed = config.ballSpeed;
    
    gameState.balls[0].dx = Math.cos(angle) * speed;
    gameState.balls[0].dy = -Math.sin(angle) * speed; // 向上发射
  }
}

// 播放音效
function playSound(type) {
  // 简化版音效处理，实际项目中可以添加真实的音效文件
  if (config.soundEffects[type]) {
    console.log(`播放音效: ${type}`);
    // 这里可以添加真实的音效播放代码
  }
}

// 游戏主循环
function gameLoop() {
  updateGame();
}

// 开始游戏
function startGame() {
  if (gameState.isRunning && !gameState.isPaused) return;
  
  if (gameState.isPaused) {
    // 继续游戏
    gameState.isPaused = false;
    
    // 重新启动游戏循环
    gameState.gameInterval = setInterval(gameLoop, 16); // 约60fps
    
    // 更新按钮状态
    elements.startButton.disabled = true;
    elements.pauseButton.disabled = false;
    elements.pauseButton.innerHTML = '<i class="fa fa-pause mr-2"></i>暂停游戏';
    
    // 隐藏游戏结束遮罩
    elements.gameOverOverlay.classList.add('hidden');
  } else {
    // 新游戏开始
    // 重置游戏状态
    initializeGameState();
    
    // 生成砖块
    generateBricks();
    
    // 渲染游戏
    renderGame();
    
    // 更新按钮状态
    elements.startButton.disabled = true;
    elements.pauseButton.disabled = false;
    elements.restartButton.disabled = false;
    elements.pauseButton.innerHTML = '<i class="fa fa-pause mr-2"></i>暂停游戏';
    
    // 更新游戏状态
    gameState.isRunning = true;
    gameState.isPaused = false;
    
    // 启动游戏循环
    gameState.gameInterval = setInterval(gameLoop, 16); // 约60fps
  }
  
  // 更新UI
  updateUI();
}

// 暂停游戏
function pauseGame() {
  if (!gameState.isRunning) return;
  
  if (!gameState.isPaused) {
    // 暂停游戏
    gameState.isPaused = true;
    clearInterval(gameState.gameInterval);
    
    // 更新按钮状态
    elements.startButton.disabled = false;
    elements.startButton.innerHTML = '<i class="fa fa-play mr-2"></i>继续游戏';
    elements.pauseButton.disabled = true;
  } else {
    // 继续游戏
    gameState.isPaused = false;
    gameState.gameInterval = setInterval(gameLoop, 16); // 约60fps
    
    // 更新按钮状态
    elements.startButton.disabled = true;
    elements.startButton.innerHTML = '<i class="fa fa-play mr-2"></i>开始游戏';
    elements.pauseButton.disabled = false;
  }
}

// 重新开始游戏
function restartGame() {
  // 清除游戏循环
  clearInterval(gameState.gameInterval);
  
  // 隐藏游戏结束遮罩
  elements.gameOverOverlay.classList.add('hidden');
  
  // 重置游戏状态
  initializeGameState();
  
  // 生成砖块
  generateBricks();
  
  // 渲染游戏
  renderGame();
  
  // 更新按钮状态
  elements.startButton.disabled = false;
  elements.pauseButton.disabled = true;
  elements.restartButton.disabled = true;
  elements.startButton.innerHTML = '<i class="fa fa-play mr-2"></i>开始游戏';
  
  // 更新UI
  updateUI();
}

// 结束游戏
function endGame() {
  // 清除游戏循环
  clearInterval(gameState.gameInterval);
  
  // 更新游戏状态
  gameState.isRunning = false;
  
  // 更新游戏结束信息
  elements.gameOverTitle.textContent = '游戏结束';
  elements.gameOverScore.textContent = gameState.score;
  elements.gameOverLevel.textContent = gameState.level;
  
  // 显示游戏结束遮罩
  elements.gameOverOverlay.classList.remove('hidden');
  
  // 更新按钮状态
  elements.startButton.disabled = false;
  elements.pauseButton.disabled = true;
  elements.restartButton.disabled = true;
  
  // 保存游戏数据
  saveGameData();
  
  playSound('gameOver');
}

// 保存游戏数据到本地存储
function saveGameData() {
  const data = {
    highScore: gameState.highScore
  };
  localStorage.setItem('breakoutGameData', JSON.stringify(data));
}

// 从本地存储加载游戏数据
function loadGameData() {
  const data = localStorage.getItem('breakoutGameData');
  if (data) {
    try {
      const parsedData = JSON.parse(data);
      gameState.highScore = parsedData.highScore || 0;
    } catch (error) {
      console.error('加载游戏数据失败:', error);
    }
  }
}

// 更新UI显示
function updateUI() {
  elements.currentScore.textContent = gameState.score;
  elements.highScore.textContent = gameState.highScore;
  elements.currentLevel.textContent = gameState.level;
  elements.remainingBricks.textContent = gameState.remainingBricks;
  
  // 更新生命值显示
  elements.lives.innerHTML = '';
  for (let i = 0; i < gameState.lives; i++) {
    const heart = document.createElement('i');
    heart.className = 'fa fa-heart text-accent text-xl';
    elements.lives.appendChild(heart);
  }
}

// 设置事件监听器
function setupEventListeners() {
  // 游戏控制按钮
  elements.startButton.addEventListener('click', startGame);
  elements.pauseButton.addEventListener('click', pauseGame);
  elements.restartButton.addEventListener('click', restartGame);
  elements.playAgainButton.addEventListener('click', restartGame);
  
  // 移动端菜单
  elements.menuToggle.addEventListener('click', () => {
    elements.mobileMenu.classList.toggle('hidden');
  });
  
  // 移动端控制按钮
  elements.mobileLeft.addEventListener('touchstart', () => {
    gameState.keys.left = true;
  });
  elements.mobileLeft.addEventListener('touchend', () => {
    gameState.keys.left = false;
  });
  
  elements.mobileRight.addEventListener('touchstart', () => {
    gameState.keys.right = true;
  });
  elements.mobileRight.addEventListener('touchend', () => {
    gameState.keys.right = false;
  });
  
  elements.mobileFire.addEventListener('click', launchBall);
  
  // 键盘控制
  document.addEventListener('keydown', handleKeyDown);
  document.addEventListener('keyup', handleKeyUp);
  
  // 鼠标控制
  elements.gameGrid.addEventListener('mousemove', handleMouseMove);
  elements.gameGrid.addEventListener('click', launchBall);
  
  // 防止鼠标离开游戏区域后失去控制
  document.addEventListener('mousemove', (event) => {
    if (event.target === elements.gameGrid || elements.gameGrid.contains(event.target)) {
      gameState.mouseX = event.clientX - elements.gameGrid.getBoundingClientRect().left;
    }
  });
  
  // 窗口失去焦点时暂停游戏
  window.addEventListener('blur', () => {
    if (gameState.isRunning && !gameState.isPaused) {
      pauseGame();
    }
  });
  
  // 响应式处理
  window.addEventListener('resize', () => {
    // 重新渲染游戏
    renderGame();
  });
}

// 处理键盘按键按下
function handleKeyDown(event) {
  // 检查是否是组合键（如Alt+左箭头用于浏览器后退），如果是，则不阻止默认行为
  if (event.altKey || event.ctrlKey || event.metaKey) {
    return;
  }
  
  // 防止页面滚动，但只在游戏运行时阻止
  if (gameState.isRunning && ['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'w', 's', 'a', 'd', ' '].includes(event.key.toLowerCase())) {
    event.preventDefault();
  }
  
  // 根据按键更新状态
  switch (event.key.toLowerCase()) {
    case 'arrowleft':
    case 'a':
      gameState.keys.left = true;
      break;
    case 'arrowright':
    case 'd':
      gameState.keys.right = true;
      break;
    case ' ': // 空格键
      launchBall();
      break;
    case 'p':
      pauseGame();
      break;
    case 'r':
      if (event.ctrlKey || event.metaKey) return; // 忽略Ctrl+R或Command+R
      restartGame();
      break;
  }
}

// 处理键盘按键释放
function handleKeyUp(event) {
  // 根据按键更新状态
  switch (event.key.toLowerCase()) {
    case 'arrowleft':
    case 'a':
      gameState.keys.left = false;
      break;
    case 'arrowright':
    case 'd':
      gameState.keys.right = false;
      break;
  }
}

// 处理鼠标移动
function handleMouseMove(event) {
  gameState.mouseX = event.clientX - elements.gameGrid.getBoundingClientRect().left;
}

// 当页面加载完成时初始化游戏
window.addEventListener('load', initGame);