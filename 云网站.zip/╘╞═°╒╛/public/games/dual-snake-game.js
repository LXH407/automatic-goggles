// 游戏配置
const config = {
  gridSize: 20,
  initialSpeed: 150,
  minSpeed: 50,
  speedIncrement: 5,
  foodValue: 10
};

// 游戏状态
const gameState = {
  isRunning: false,
  isPaused: false,
  // 玩家1
  snake1: {
    body: [
      { x: 5, y: 10 },
      { x: 4, y: 10 },
      { x: 3, y: 10 }
    ],
    direction: 'right',
    nextDirection: 'right',
    score: 0,
    color: 'snake1',
    isAlive: true
  },
  // 玩家2
  snake2: {
    body: [
      { x: 15, y: 10 },
      { x: 16, y: 10 },
      { x: 17, y: 10 }
    ],
    direction: 'left',
    nextDirection: 'left',
    score: 0,
    color: 'snake2',
    isAlive: true
  },
  food: [],
  gameInterval: null,
  currentSpeed: config.initialSpeed,
  highScore1: 0,
  highScore2: 0,
  playCount: 0,
  startTime: 0,
  elapsedTime: 0,
  winner: null
};

// DOM元素
const elements = {
  gameGrid: document.getElementById('game-grid'),
  gameContainer: document.getElementById('game-container'),
  score1: document.getElementById('score1'),
  score2: document.getElementById('score2'),
  length1: document.getElementById('length1'),
  length2: document.getElementById('length2'),
  startButton: document.getElementById('start-button'),
  pauseButton: document.getElementById('pause-button'),
  restartButton: document.getElementById('restart-button'),
  gameOverOverlay: document.getElementById('game-over-overlay'),
  finalScore1: document.getElementById('final-score1'),
  finalScore2: document.getElementById('final-score2'),
  winnerText: document.getElementById('winner-text'),
  winnerMessage: document.getElementById('winner-message'),
  playAgainButton: document.getElementById('play-again-button'),
  menuToggle: document.getElementById('menu-toggle'),
  mobileMenu: document.getElementById('mobile-menu'),
  // 移动端控制按钮
  up1Button: document.getElementById('up1-button'),
  down1Button: document.getElementById('down1-button'),
  left1Button: document.getElementById('left1-button'),
  right1Button: document.getElementById('right1-button'),
  up2Button: document.getElementById('up2-button'),
  down2Button: document.getElementById('down2-button'),
  left2Button: document.getElementById('left2-button'),
  right2Button: document.getElementById('right2-button')
};

// 初始化游戏
function initGame() {
  // 加载游戏数据
  loadGameData();
  
  // 渲染网格
  renderGrid();
  
  // 生成初始食物
  generateFood(3); // 生成3个食物
  
  // 渲染初始状态
  renderSnake(gameState.snake1);
  renderSnake(gameState.snake2);
  
  // 设置事件监听器
  setupEventListeners();
  
  // 更新UI
  updateUI();
}

// 渲染游戏网格
function renderGrid() {
  elements.gameGrid.innerHTML = '';
  
  for (let y = 0; y < config.gridSize; y++) {
    for (let x = 0; x < config.gridSize; x++) {
      const cell = document.createElement('div');
      cell.className = 'game-cell bg-white';
      cell.dataset.x = x;
      cell.dataset.y = y;
      cell.id = `cell-${x}-${y}`;
      
      elements.gameGrid.appendChild(cell);
    }
  }
}

// 获取单元格
function getCell(x, y) {
  return document.getElementById(`cell-${x}-${y}`);
}

// 渲染贪吃蛇
function renderSnake(snake) {
  if (!snake.isAlive) return;
  
  // 清除之前的蛇身
  const snakeCells = document.querySelectorAll(`.${snake.color}`);
  snakeCells.forEach(cell => {
    cell.className = 'game-cell bg-white';
  });
  
  // 渲染新的蛇身
  snake.body.forEach((segment, index) => {
    const cell = getCell(segment.x, segment.y);
    if (cell) {
      if (index === 0) {
        // 蛇头
        cell.className = `game-cell bg-${snake.color} snake-head relative`;
        
        // 添加方向指示器
        cell.innerHTML = getDirectionIndicator(snake.direction);
      } else {
        // 蛇身
        cell.className = `game-cell bg-${snake.color}`;
      }
    }
  });
}

// 获取方向指示器
function getDirectionIndicator(direction) {
  switch (direction) {
    case 'up':
      return '<div class="direction-indicator top-1 left-1/2 transform -translate-x-1/2 -translate-y-1/2"></div>';
    case 'down':
      return '<div class="direction-indicator bottom-1 left-1/2 transform -translate-x-1/2 translate-y-1/2"></div>';
    case 'left':
      return '<div class="direction-indicator left-1 top-1/2 transform -translate-x-1/2 -translate-y-1/2"></div>';
    case 'right':
      return '<div class="direction-indicator right-1 top-1/2 transform translate-x-1/2 -translate-y-1/2"></div>';
    default:
      return '';
  }
}

// 生成食物
function generateFood(count) {
  // 清除之前的食物
  gameState.food.forEach(food => {
    const cell = getCell(food.x, food.y);
    if (cell) {
      cell.className = 'game-cell bg-white';
    }
  });
  
  gameState.food = [];
  
  // 生成新食物
  let generated = 0;
  while (generated < count) {
    const x = Math.floor(Math.random() * config.gridSize);
    const y = Math.floor(Math.random() * config.gridSize);
    
    // 检查是否与蛇身重叠
    const isSnake1Body = gameState.snake1.body.some(segment => segment.x === x && segment.y === y);
    const isSnake2Body = gameState.snake2.body.some(segment => segment.x === x && segment.y === y);
    const isFood = gameState.food.some(food => food.x === x && food.y === y);
    
    if (!isSnake1Body && !isSnake2Body && !isFood) {
      gameState.food.push({ x, y });
      generated++;
    }
  }
  
  // 渲染食物
  gameState.food.forEach(food => {
    const cell = getCell(food.x, food.y);
    if (cell) {
      cell.className = 'game-cell bg-food';
    }
  });
}

// 移动贪吃蛇
function moveSnakes() {
  if (!gameState.isRunning || gameState.isPaused) return;
  
  // 更新方向
  gameState.snake1.direction = gameState.snake1.nextDirection;
  gameState.snake2.direction = gameState.snake2.nextDirection;
  
  // 移动玩家1的蛇
  if (gameState.snake1.isAlive) {
    moveSnake(gameState.snake1);
  }
  
  // 移动玩家2的蛇
  if (gameState.snake2.isAlive) {
    moveSnake(gameState.snake2);
  }
  
  // 检查游戏是否结束
  checkGameOver();
  
  // 更新UI
  updateUI();
}

// 移动单条贪吃蛇
function moveSnake(snake) {
  // 获取蛇头位置
  const head = { ...snake.body[0] };
  
  // 根据方向移动蛇头
  switch (snake.direction) {
    case 'up':
      head.y -= 1;
      break;
    case 'down':
      head.y += 1;
      break;
    case 'left':
      head.x -= 1;
      break;
    case 'right':
      head.x += 1;
      break;
  }
  
  // 检查碰撞
  if (checkCollision(head, snake)) {
    snake.isAlive = false;
    return;
  }
  
  // 将新的头部添加到蛇的数组前面
  snake.body.unshift(head);
  
  // 检查是否吃到食物
  const foodIndex = gameState.food.findIndex(food => food.x === head.x && food.y === head.y);
  
  if (foodIndex !== -1) {
    // 增加分数
    snake.score += config.foodValue;
    
    // 更新最高分
    if (snake === gameState.snake1 && snake.score > gameState.highScore1) {
      gameState.highScore1 = snake.score;
    } else if (snake === gameState.snake2 && snake.score > gameState.highScore2) {
      gameState.highScore2 = snake.score;
    }
    
    // 保存游戏数据
    saveGameData();
    
    // 移除吃到的食物并生成新食物
    gameState.food.splice(foodIndex, 1);
    generateFood(1);
    
    // 增加游戏速度（基于两条蛇的总分数）
    const totalScore = gameState.snake1.score + gameState.snake2.score;
    gameState.currentSpeed = Math.max(config.minSpeed, config.initialSpeed - (totalScore / 10) * config.speedIncrement);
    
    // 更新游戏速度
    clearInterval(gameState.gameInterval);
    gameState.gameInterval = setInterval(moveSnakes, gameState.currentSpeed);
  } else {
    // 如果没有吃到食物，移除尾部
    snake.body.pop();
  }
  
  // 渲染蛇
  renderSnake(snake);
}

// 检查碰撞
function checkCollision(head, currentSnake) {
  // 检查是否撞到墙壁
  if (head.x < 0 || head.x >= config.gridSize || head.y < 0 || head.y >= config.gridSize) {
    return true;
  }
  
  // 检查是否撞到自己的身体
  for (let i = 1; i < currentSnake.body.length; i++) {
    if (head.x === currentSnake.body[i].x && head.y === currentSnake.body[i].y) {
      return true;
    }
  }
  
  // 检查是否撞到另一条蛇的身体
  const otherSnake = currentSnake === gameState.snake1 ? gameState.snake2 : gameState.snake1;
  if (otherSnake.isAlive) {
    for (let i = 0; i < otherSnake.body.length; i++) {
      if (head.x === otherSnake.body[i].x && head.y === otherSnake.body[i].y) {
        return true;
      }
    }
  }
  
  return false;
}

// 检查游戏是否结束
function checkGameOver() {
  // 游戏结束条件：两条蛇都死亡
  if (!gameState.snake1.isAlive && !gameState.snake2.isAlive) {
    // 确定胜者（分数高的获胜）
    if (gameState.snake1.score > gameState.snake2.score) {
      gameState.winner = 'player1';
    } else if (gameState.snake2.score > gameState.snake1.score) {
      gameState.winner = 'player2';
    } else {
      gameState.winner = 'tie';
    }
    
    endGame();
  }
}

// 开始游戏
function startGame() {
  if (gameState.isRunning && !gameState.isPaused) return;
  
  if (gameState.isPaused) {
    // 继续游戏
    gameState.isPaused = false;
    // 调整开始时间，减去暂停的时间
    gameState.startTime = Date.now() - (gameState.elapsedTime * 1000);
    // 启动游戏循环
    gameState.gameInterval = setInterval(moveSnakes, gameState.currentSpeed);
  } else {
    // 新游戏开始
    gameState.isRunning = true;
    gameState.isPaused = false;
    gameState.startTime = Date.now();
    gameState.elapsedTime = 0;
    
    // 增加游戏次数
    gameState.playCount++;
    saveGameData();
    
    // 更新按钮状态
    elements.startButton.disabled = true;
    elements.pauseButton.disabled = false;
    elements.restartButton.disabled = false;
    
    // 启动游戏循环
    gameState.gameInterval = setInterval(moveSnakes, gameState.currentSpeed);
  }
  
  // 更新UI
  updateUI();
}

// 暂停游戏
function pauseGame() {
  if (!gameState.isRunning) return;
  
  if (!gameState.isPaused) {
    // 暂停游戏
    gameState.isPaused = true;
    clearInterval(gameState.gameInterval);
    
    // 更新按钮状态
    elements.startButton.disabled = false;
    elements.startButton.innerHTML = '<i class="fa fa-play mr-2"></i>继续游戏';
  } else {
    // 继续游戏
    gameState.isPaused = false;
    // 调整开始时间，减去暂停的时间
    gameState.startTime = Date.now() - (gameState.elapsedTime * 1000);
    // 重新启动游戏循环
    gameState.gameInterval = setInterval(moveSnakes, gameState.currentSpeed);
    
    // 更新按钮状态
    elements.startButton.disabled = true;
    elements.startButton.innerHTML = '<i class="fa fa-play mr-2"></i>开始游戏';
  }
}

// 重新开始游戏
function restartGame() {
  // 清除游戏循环
  clearInterval(gameState.gameInterval);
  
  // 隐藏游戏结束遮罩
  elements.gameOverOverlay.classList.add('hidden');
  
  // 重置游戏
  resetGame();
}

// 重置游戏
function resetGame() {
  // 重置游戏状态
  gameState.isRunning = false;
  gameState.isPaused = false;
  
  // 重置玩家1的蛇
  gameState.snake1 = {
    body: [
      { x: 5, y: 10 },
      { x: 4, y: 10 },
      { x: 3, y: 10 }
    ],
    direction: 'right',
    nextDirection: 'right',
    score: 0,
    color: 'snake1',
    isAlive: true
  };
  
  // 重置玩家2的蛇
  gameState.snake2 = {
    body: [
      { x: 15, y: 10 },
      { x: 16, y: 10 },
      { x: 17, y: 10 }
    ],
    direction: 'left',
    nextDirection: 'left',
    score: 0,
    color: 'snake2',
    isAlive: true
  };
  
  // 重置其他状态
  gameState.currentSpeed = config.initialSpeed;
  gameState.elapsedTime = 0;
  gameState.winner = null;
  
  // 生成新食物
  generateFood(3);
  
  // 渲染游戏
  renderGrid();
  renderSnake(gameState.snake1);
  renderSnake(gameState.snake2);
  
  // 重置按钮状态
  elements.startButton.disabled = false;
  elements.pauseButton.disabled = true;
  elements.restartButton.disabled = true;
  elements.startButton.innerHTML = '<i class="fa fa-play mr-2"></i>开始游戏';
  
  // 更新UI
  updateUI();
}

// 结束游戏
function endGame() {
  // 清除游戏循环
  clearInterval(gameState.gameInterval);
  
  // 更新游戏状态
  gameState.isRunning = false;
  
  // 更新游戏结束信息
  elements.finalScore1.textContent = gameState.snake1.score;
  elements.finalScore2.textContent = gameState.snake2.score;
  
  if (gameState.winner === 'player1') {
    elements.winnerText.textContent = '游戏结束';
    elements.winnerMessage.textContent = '玩家1获胜！';
  } else if (gameState.winner === 'player2') {
    elements.winnerText.textContent = '游戏结束';
    elements.winnerMessage.textContent = '玩家2获胜！';
  } else {
    elements.winnerText.textContent = '游戏结束';
    elements.winnerMessage.textContent = '平局！';
  }
  
  // 显示游戏结束遮罩
  elements.gameOverOverlay.classList.remove('hidden');
  
  // 更新按钮状态
  elements.startButton.disabled = false;
  elements.pauseButton.disabled = true;
  elements.restartButton.disabled = true;
  
  // 保存游戏数据
  saveGameData();
}

// 更新UI显示
function updateUI() {
  elements.score1.textContent = gameState.snake1.score;
  elements.score2.textContent = gameState.snake2.score;
  elements.length1.textContent = gameState.snake1.body.length;
  elements.length2.textContent = gameState.snake2.body.length;
}

// 设置玩家1的方向
function setSnake1Direction(newDirection) {
  // 防止蛇直接反向移动
  const oppositeDirections = {
    up: 'down',
    down: 'up',
    left: 'right',
    right: 'left'
  };
  
  // 只有当新方向不是当前方向的反向时才更新
  if (newDirection !== oppositeDirections[gameState.snake1.direction]) {
    gameState.snake1.nextDirection = newDirection;
  }
}

// 设置玩家2的方向
function setSnake2Direction(newDirection) {
  // 防止蛇直接反向移动
  const oppositeDirections = {
    up: 'down',
    down: 'up',
    left: 'right',
    right: 'left'
  };
  
  // 只有当新方向不是当前方向的反向时才更新
  if (newDirection !== oppositeDirections[gameState.snake2.direction]) {
    gameState.snake2.nextDirection = newDirection;
  }
}

// 保存游戏数据到本地存储
function saveGameData() {
  const data = {
    highScore1: gameState.highScore1,
    highScore2: gameState.highScore2,
    playCount: gameState.playCount
  };
  localStorage.setItem('dualSnakeGameData', JSON.stringify(data));
}

// 从本地存储加载游戏数据
function loadGameData() {
  const data = localStorage.getItem('dualSnakeGameData');
  if (data) {
    try {
      const parsedData = JSON.parse(data);
      gameState.highScore1 = parsedData.highScore1 || 0;
      gameState.highScore2 = parsedData.highScore2 || 0;
      gameState.playCount = parsedData.playCount || 0;
    } catch (error) {
      console.error('加载游戏数据失败:', error);
    }
  }
}

// 设置事件监听器
function setupEventListeners() {
  // 游戏控制按钮
  elements.startButton.addEventListener('click', startGame);
  elements.pauseButton.addEventListener('click', pauseGame);
  elements.restartButton.addEventListener('click', restartGame);
  elements.playAgainButton.addEventListener('click', restartGame);
  
  // 移动端菜单
  elements.menuToggle.addEventListener('click', () => {
    elements.mobileMenu.classList.toggle('hidden');
  });
  
  // 移动端控制按钮 - 玩家1
  elements.up1Button.addEventListener('click', () => setSnake1Direction('up'));
  elements.down1Button.addEventListener('click', () => setSnake1Direction('down'));
  elements.left1Button.addEventListener('click', () => setSnake1Direction('left'));
  elements.right1Button.addEventListener('click', () => setSnake1Direction('right'));
  
  // 移动端控制按钮 - 玩家2
  elements.up2Button.addEventListener('click', () => setSnake2Direction('up'));
  elements.down2Button.addEventListener('click', () => setSnake2Direction('down'));
  elements.left2Button.addEventListener('click', () => setSnake2Direction('left'));
  elements.right2Button.addEventListener('click', () => setSnake2Direction('right'));
  
  // 键盘控制
  document.addEventListener('keydown', handleKeyDown);
  
  // 响应式处理
  window.addEventListener('resize', () => {
    const containerWidth = elements.grid.parentElement.clientWidth;
    const cellSize = Math.min(containerWidth / config.gridSize, 30); // 最大30px
    elements.grid.style.gridTemplateColumns = `repeat(${config.gridSize}, ${cellSize}px)`;
    elements.grid.style.gridTemplateRows = `repeat(${config.gridSize}, ${cellSize}px)`;
    
    // 重新渲染蛇和食物
    renderSnake(gameState.snake1);
    renderSnake(gameState.snake2);
    gameState.food.forEach(food => {
      const cell = getCell(food.x, food.y);
      if (cell) {
        cell.className = 'game-cell bg-food';
      }
    });
  });
}

// 处理键盘按键
function handleKeyDown(event) {
  // 检查是否是组合键（如Alt+左箭头用于浏览器后退），如果是，则不阻止默认行为
  if (event.altKey || event.ctrlKey || event.metaKey) {
    return;
  }
  
  // 防止页面滚动，但只在游戏运行时阻止
  if (gameState.isRunning && ['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'w', 's', 'a', 'd'].includes(event.key.toLowerCase())) {
    event.preventDefault();
  }
  
  // 根据按键设置方向
  switch (event.key.toLowerCase()) {
    // 玩家1控制 (WASD)
    case 'w':
      setSnake1Direction('up');
      break;
    case 's':
      setSnake1Direction('down');
      break;
    case 'a':
      setSnake1Direction('left');
      break;
    case 'd':
      setSnake1Direction('right');
      break;
    
    // 玩家2控制 (方向键)
    case 'arrowup':
      setSnake2Direction('up');
      break;
    case 'arrowdown':
      setSnake2Direction('down');
      break;
    case 'arrowleft':
      setSnake2Direction('left');
      break;
    case 'arrowright':
      setSnake2Direction('right');
      break;
    
    // 游戏控制
    case ' ': // 空格暂停/继续
      if (gameState.isRunning) {
        pauseGame();
      } else {
        startGame();
      }
      break;
    case 'r': // R键重新开始
      if (event.ctrlKey || event.metaKey) return; // 忽略Ctrl+R或Command+R
      restartGame();
      break;
  }
}

// 当页面加载完成时初始化游戏
window.addEventListener('load', initGame);