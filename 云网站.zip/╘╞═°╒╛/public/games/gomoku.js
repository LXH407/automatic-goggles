// 游戏配置
const config = {
  defaultSize: 15,
  minSize: 9,
  maxSize: 19,
  cellSize: 30, // 默认单元格大小
  borderSize: 20, // 边框大小
  stoneSize: 26 // 棋子大小
};

// 游戏状态
const gameState = {
  board: [],
  size: config.defaultSize,
  currentPlayer: 'black', // 'black' 或 'white'
  isRunning: false,
  gameMode: 'human-vs-human', // 'human-vs-human' 或 'human-vs-ai'
  aiDifficulty: 'medium', // 'easy', 'medium', 'hard'
  gameHistory: [],
  // 游戏统计
  stats: {
    playCount: 0,
    blackWins: 0,
    whiteWins: 0,
    draws: 0
  }
};

// DOM元素
const elements = {
  // 游戏控制
  startButton: document.getElementById('start-button'),
  restartButton: document.getElementById('restart-button'),
  undoButton: document.getElementById('undo-button'),
  saveButton: document.getElementById('save-button'),
  // 游戏信息
  currentPlayerIcon: document.getElementById('current-player-icon'),
  currentPlayerText: document.getElementById('current-player-text'),
  gameModeSelect: document.getElementById('game-mode'),
  aiDifficultyContainer: document.getElementById('ai-difficulty-container'),
  aiDifficultySelect: document.getElementById('ai-difficulty'),
  boardSizeSelect: document.getElementById('board-size'),
  // 游戏统计
  playCount: document.getElementById('play-count'),
  blackWins: document.getElementById('black-wins'),
  whiteWins: document.getElementById('white-wins'),
  draws: document.getElementById('draws'),
  // 棋盘相关
  boardContainer: document.getElementById('board-container'),
  boardGrid: document.getElementById('board-grid'),
  stonesContainer: document.getElementById('stones-container'),
  boardOverlay: document.getElementById('board-overlay'),
  overlayTitle: document.getElementById('overlay-title'),
  overlayMessage: document.getElementById('overlay-message'),
  overlayButton: document.getElementById('overlay-button'),
  // 移动端菜单
  menuToggle: document.getElementById('menu-toggle'),
  mobileMenu: document.getElementById('mobile-menu')
};

// 初始化游戏
function initGame() {
  // 加载游戏数据
  loadGameData();
  
  // 初始化棋盘
  resetBoard();
  
  // 设置事件监听器
  setupEventListeners();
  
  // 更新UI
  updateUI();
}

// 重置棋盘
function resetBoard() {
  // 获取选定的棋盘大小
  gameState.size = parseInt(elements.boardSizeSelect.value);
  
  // 计算棋盘尺寸
  const boardDimension = gameState.size * config.cellSize + config.borderSize * 2;
  
  // 设置棋盘容器尺寸
  elements.boardContainer.style.width = `${boardDimension}px`;
  elements.boardContainer.style.height = `${boardDimension}px`;
  
  // 设置SVG尺寸
  elements.boardGrid.setAttribute('width', boardDimension);
  elements.boardGrid.setAttribute('height', boardDimension);
  
  // 清除棋盘
  elements.boardGrid.innerHTML = '';
  elements.stonesContainer.innerHTML = '';
  
  // 初始化棋盘数据
  gameState.board = Array(gameState.size).fill().map(() => Array(gameState.size).fill(null));
  gameState.gameHistory = [];
  gameState.currentPlayer = 'black';
  
  // 绘制棋盘
  drawBoard();
  
  // 更新UI
  updateUI();
}

// 绘制棋盘
function drawBoard() {
  const svg = elements.boardGrid;
  const size = gameState.size;
  const cellSize = config.cellSize;
  const border = config.borderSize;
  
  // 清除现有内容
  svg.innerHTML = '';
  
  // 创建SVG组
  const g = document.createElementNS('http://www.w3.org/2000/svg', 'g');
  g.setAttribute('class', 'gomoku-board');
  
  // 绘制横线
  for (let y = 0; y < size; y++) {
    const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
    line.setAttribute('x1', border);
    line.setAttribute('y1', border + y * cellSize);
    line.setAttribute('x2', border + (size - 1) * cellSize);
    line.setAttribute('y2', border + y * cellSize);
    line.setAttribute('class', 'gomoku-line');
    g.appendChild(line);
  }
  
  // 绘制竖线
  for (let x = 0; x < size; x++) {
    const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
    line.setAttribute('x1', border + x * cellSize);
    line.setAttribute('y1', border);
    line.setAttribute('x2', border + x * cellSize);
    line.setAttribute('y2', border + (size - 1) * cellSize);
    line.setAttribute('class', 'gomoku-line');
    g.appendChild(line);
  }
  
  // 绘制天元和星位
  const starPositions = [
    {x: 3, y: 3}, {x: 3, y: size - 4}, 
    {x: size - 4, y: 3}, {x: size - 4, y: size - 4}
  ];
  
  // 只在13×13和15×15的棋盘上绘制天元和星位
  if (size >= 13) {
    // 绘制天元
    const center = {x: Math.floor((size - 1) / 2), y: Math.floor((size - 1) / 2)};
    const centerDot = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
    centerDot.setAttribute('cx', border + center.x * cellSize);
    centerDot.setAttribute('cy', border + center.y * cellSize);
    centerDot.setAttribute('r', 3);
    centerDot.setAttribute('class', 'gomoku-intersection');
    g.appendChild(centerDot);
    
    // 绘制星位
    starPositions.forEach(pos => {
      const dot = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
      dot.setAttribute('cx', border + pos.x * cellSize);
      dot.setAttribute('cy', border + pos.y * cellSize);
      dot.setAttribute('r', 3);
      dot.setAttribute('class', 'gomoku-intersection');
      g.appendChild(dot);
    });
  }
  
  svg.appendChild(g);
}

// 开始游戏
function startGame() {
  // 设置游戏状态
  gameState.isRunning = true;
  
  // 更新按钮状态
  elements.startButton.disabled = true;
  elements.restartButton.disabled = false;
  elements.undoButton.disabled = false;
  elements.saveButton.disabled = false;
  elements.gameModeSelect.disabled = true;
  elements.boardSizeSelect.disabled = true;
  
  // 更新游戏统计
  gameState.stats.playCount++;
  saveGameData();
  
  // 如果是人机对战且AI是黑方，AI先落子
  if (gameState.gameMode === 'human-vs-ai' && gameState.currentPlayer === 'black') {
    setTimeout(() => {
      makeAIMove();
    }, 500);
  }
}

// 重新开始游戏
function restartGame() {
  // 隐藏游戏结束遮罩
  elements.boardOverlay.classList.add('hidden');
  
  // 重置棋盘
  resetBoard();
  
  // 更新按钮状态
  elements.startButton.disabled = false;
  elements.restartButton.disabled = true;
  elements.undoButton.disabled = true;
  elements.saveButton.disabled = true;
  elements.gameModeSelect.disabled = false;
  elements.boardSizeSelect.disabled = false;
  
  // 重置游戏状态
  gameState.isRunning = false;
}

// 放置棋子
function placeStone(x, y) {
  // 检查位置是否有效
  if (!gameState.isRunning || x < 0 || x >= gameState.size || y < 0 || y >= gameState.size || gameState.board[x][y] !== null) {
    return false;
  }
  
  // 保存当前状态到历史记录
  gameState.gameHistory.push({
    board: JSON.parse(JSON.stringify(gameState.board)),
    currentPlayer: gameState.currentPlayer
  });
  
  // 在棋盘上放置棋子
  gameState.board[x][y] = gameState.currentPlayer;
  
  // 渲染棋子
  renderStone(x, y, gameState.currentPlayer);
  
  // 检查游戏是否结束
  const winner = checkWinner(x, y);
  if (winner) {
    endGame(winner);
    return true;
  }
  
  // 检查是否平局
  if (isBoardFull()) {
    endGame('draw');
    return true;
  }
  
  // 切换玩家
  gameState.currentPlayer = gameState.currentPlayer === 'black' ? 'white' : 'black';
  
  // 更新UI
  updateUI();
  
  // 如果是人机对战且轮到AI落子，AI落子
  if (gameState.gameMode === 'human-vs-ai' && gameState.currentPlayer === 'white') {
    setTimeout(() => {
      makeAIMove();
    }, 500);
  }
  
  return true;
}

// 渲染棋子
function renderStone(x, y, player) {
  const stone = document.createElement('div');
  stone.className = `absolute rounded-full animate-scale-in`;
  stone.style.width = `${config.stoneSize}px`;
  stone.style.height = `${config.stoneSize}px`;
  stone.style.left = `${config.borderSize + x * config.cellSize - config.stoneSize / 2}px`;
  stone.style.top = `${config.borderSize + y * config.cellSize - config.stoneSize / 2}px`;
  stone.style.boxShadow = '0 2px 8px rgba(0, 0, 0, 0.2)';
  
  if (player === 'black') {
    stone.classList.add('bg-blackStone', 'border', 'border-gray-700');
  } else {
    stone.classList.add('bg-whiteStone', 'border', 'border-gray-300');
  }
  
  stone.dataset.x = x;
  stone.dataset.y = y;
  
  elements.stonesContainer.appendChild(stone);
}

// 检查是否有获胜者
function checkWinner(x, y) {
  const player = gameState.board[x][y];
  if (!player) return null;
  
  // 检查四个方向：水平、垂直、两个对角线
  const directions = [
    [1, 0],  // 水平
    [0, 1],  // 垂直
    [1, 1],  // 对角线1
    [1, -1]  // 对角线2
  ];
  
  for (const [dx, dy] of directions) {
    let count = 1;
    
    // 向一个方向检查
    for (let i = 1; i <= 4; i++) {
      const nx = x + dx * i;
      const ny = y + dy * i;
      if (nx >= 0 && nx < gameState.size && ny >= 0 && ny < gameState.size && gameState.board[nx][ny] === player) {
        count++;
      } else {
        break;
      }
    }
    
    // 向相反方向检查
    for (let i = 1; i <= 4; i++) {
      const nx = x - dx * i;
      const ny = y - dy * i;
      if (nx >= 0 && nx < gameState.size && ny >= 0 && ny < gameState.size && gameState.board[nx][ny] === player) {
        count++;
      } else {
        break;
      }
    }
    
    // 如果有5个连续的棋子，返回获胜者
    if (count >= 5) {
      return player;
    }
  }
  
  return null;
}

// 检查棋盘是否已满
function isBoardFull() {
  for (let x = 0; x < gameState.size; x++) {
    for (let y = 0; y < gameState.size; y++) {
      if (gameState.board[x][y] === null) {
        return false;
      }
    }
  }
  return true;
}

// 结束游戏
function endGame(result) {
  // 更新游戏状态
  gameState.isRunning = false;
  
  // 更新游戏统计
  if (result === 'black') {
    gameState.stats.blackWins++;
  } else if (result === 'white') {
    gameState.stats.whiteWins++;
  } else if (result === 'draw') {
    gameState.stats.draws++;
  }
  
  // 保存游戏数据
  saveGameData();
  
  // 更新UI
  updateUI();
  
  // 显示游戏结束遮罩
  if (result === 'draw') {
    elements.overlayTitle.textContent = '游戏结束';
    elements.overlayMessage.textContent = '平局！';
  } else {
    elements.overlayTitle.textContent = '游戏结束';
    elements.overlayMessage.textContent = `${result === 'black' ? '黑方' : '白方'}获胜！`;
  }
  
  elements.boardOverlay.classList.remove('hidden');
  elements.boardOverlay.classList.add('flex');
  
  // 更新按钮状态
  elements.startButton.disabled = false;
  elements.restartButton.disabled = false;
  elements.undoButton.disabled = true;
  elements.saveButton.disabled = true;
}

// 悔棋
function undoMove() {
  if (!gameState.isRunning || gameState.gameHistory.length === 0) {
    return;
  }
  
  // 恢复上一个状态
  const lastState = gameState.gameHistory.pop();
  gameState.board = lastState.board;
  gameState.currentPlayer = lastState.currentPlayer;
  
  // 重新渲染棋盘
  elements.stonesContainer.innerHTML = '';
  for (let x = 0; x < gameState.size; x++) {
    for (let y = 0; y < gameState.size; y++) {
      if (gameState.board[x][y]) {
        renderStone(x, y, gameState.board[x][y]);
      }
    }
  }
  
  // 更新UI
  updateUI();
}

// 保存游戏
function saveGame() {
  if (!gameState.isRunning) {
    alert('请先开始游戏再保存！');
    return;
  }
  
  const gameData = {
    board: gameState.board,
    size: gameState.size,
    currentPlayer: gameState.currentPlayer,
    gameMode: gameState.gameMode,
    aiDifficulty: gameState.aiDifficulty,
    gameHistory: gameState.gameHistory
  };
  
  localStorage.setItem('gomokuGame', JSON.stringify(gameData));
  alert('游戏已保存！');
}

// 加载游戏
function loadGame() {
  const savedGame = localStorage.getItem('gomokuGame');
  if (!savedGame) {
    alert('没有找到保存的游戏！');
    return;
  }
  
  try {
    const gameData = JSON.parse(savedGame);
    
    // 设置游戏状态
    gameState.board = gameData.board;
    gameState.size = gameData.size;
    gameState.currentPlayer = gameData.currentPlayer;
    gameState.gameMode = gameData.gameMode;
    gameState.aiDifficulty = gameData.aiDifficulty;
    gameState.gameHistory = gameData.gameHistory;
    
    // 更新选择器
    elements.gameModeSelect.value = gameData.gameMode;
    elements.aiDifficultySelect.value = gameData.aiDifficulty;
    elements.boardSizeSelect.value = gameData.size;
    
    // 更新UI
    resetBoard();
    
    // 重新渲染棋子
    for (let x = 0; x < gameState.size; x++) {
      for (let y = 0; y < gameState.size; y++) {
        if (gameState.board[x][y]) {
          renderStone(x, y, gameState.board[x][y]);
        }
      }
    }
    
    // 更新游戏状态
    gameState.isRunning = true;
    
    // 更新按钮状态
    elements.startButton.disabled = true;
    elements.restartButton.disabled = false;
    elements.undoButton.disabled = gameState.gameHistory.length === 0;
    elements.saveButton.disabled = false;
    elements.gameModeSelect.disabled = true;
    elements.boardSizeSelect.disabled = true;
    
    // 更新AI难度容器显示
    if (gameState.gameMode === 'human-vs-ai') {
      elements.aiDifficultyContainer.classList.remove('hidden');
    } else {
      elements.aiDifficultyContainer.classList.add('hidden');
    }
    
    alert('游戏已加载！');
  } catch (error) {
    console.error('加载游戏失败:', error);
    alert('加载游戏失败，请重试！');
  }
}

// AI落子
function makeAIMove() {
  if (!gameState.isRunning || gameState.gameMode !== 'human-vs-ai' || gameState.currentPlayer !== 'white') {
    return;
  }
  
  let bestMove;
  
  // 根据难度选择不同的AI策略
  switch (gameState.aiDifficulty) {
    case 'easy':
      bestMove = getEasyAIMove();
      break;
    case 'medium':
      bestMove = getMediumAIMove();
      break;
    case 'hard':
      bestMove = getHardAIMove();
      break;
  }
  
  // 如果找到了最佳位置，放置棋子
  if (bestMove) {
    placeStone(bestMove.x, bestMove.y);
  }
}

// 简单AI - 随机落子
function getEasyAIMove() {
  const availableMoves = [];
  
  // 找到所有可用的位置
  for (let x = 0; x < gameState.size; x++) {
    for (let y = 0; y < gameState.size; y++) {
      if (gameState.board[x][y] === null) {
        availableMoves.push({x, y});
      }
    }
  }
  
  // 随机选择一个位置
  if (availableMoves.length > 0) {
    const randomIndex = Math.floor(Math.random() * availableMoves.length);
    return availableMoves[randomIndex];
  }
  
  return null;
}

// 中等AI - 简单的防守策略
function getMediumAIMove() {
  const availableMoves = [];
  
  // 检查是否有威胁或机会
  for (let x = 0; x < gameState.size; x++) {
    for (let y = 0; y < gameState.size; y++) {
      if (gameState.board[x][y] === null) {
        // 检查AI在这个位置落子是否能赢
        gameState.board[x][y] = 'white';
        const aiCanWin = checkWinner(x, y) === 'white';
        gameState.board[x][y] = null;
        
        if (aiCanWin) {
          return {x, y};
        }
        
        // 检查玩家在这个位置落子是否能赢
        gameState.board[x][y] = 'black';
        const playerCanWin = checkWinner(x, y) === 'black';
        gameState.board[x][y] = null;
        
        if (playerCanWin) {
          return {x, y};
        }
        
        // 检查中心区域的位置
        const centerWeight = getPositionWeight(x, y);
        if (centerWeight > 0) {
          availableMoves.push({x, y, weight: centerWeight});
        }
      }
    }
  }
  
  // 根据权重排序并选择
  if (availableMoves.length > 0) {
    availableMoves.sort((a, b) => b.weight - a.weight);
    return availableMoves[0];
  }
  
  // 如果没有找到合适的位置，随机选择
  return getEasyAIMove();
}

// 获取位置权重（中心区域权重更高）
function getPositionWeight(x, y) {
  const center = Math.floor(gameState.size / 2);
  const distanceFromCenter = Math.max(Math.abs(x - center), Math.abs(y - center));
  
  // 距离中心越近，权重越高
  return Math.max(0, center - distanceFromCenter + 1);
}

// 困难AI - 基于评分系统
function getHardAIMove() {
  let bestScore = -Infinity;
  let bestMove = null;
  
  // 评估所有可用位置
  for (let x = 0; x < gameState.size; x++) {
    for (let y = 0; y < gameState.size; y++) {
      if (gameState.board[x][y] === null) {
        // 模拟AI落子
        gameState.board[x][y] = 'white';
        const score = minimax(gameState.board, 3, -Infinity, Infinity, false);
        gameState.board[x][y] = null;
        
        if (score > bestScore) {
          bestScore = score;
          bestMove = {x, y};
        }
      }
    }
  }
  
  return bestMove;
}

// 极小极大算法（带Alpha-Beta剪枝）
function minimax(board, depth, alpha, beta, isMaximizingPlayer) {
  // 检查是否有获胜者
  let winner = null;
  for (let x = 0; x < board.length && !winner; x++) {
    for (let y = 0; y < board[x].length && !winner; y++) {
      if (board[x][y]) {
        winner = checkWinner(x, y);
      }
    }
  }
  
  // 检查是否平局
  const isFull = isBoardFull();
  
  // 基本情况
  if (depth === 0 || winner || isFull) {
    if (winner === 'white') return 1000 + depth; // AI获胜
    if (winner === 'black') return -1000 - depth; // 玩家获胜
    if (isFull) return 0; // 平局
    return evaluateBoard(board); // 评估当前棋盘
  }
  
  if (isMaximizingPlayer) {
    // AI回合（最大化分数）
    let maxScore = -Infinity;
    
    for (let x = 0; x < board.length; x++) {
      for (let y = 0; y < board[x].length; y++) {
        if (board[x][y] === null) {
          board[x][y] = 'white';
          const score = minimax(board, depth - 1, alpha, beta, false);
          board[x][y] = null;
          
          maxScore = Math.max(maxScore, score);
          alpha = Math.max(alpha, score);
          
          if (beta <= alpha) {
            break; // Alpha-Beta剪枝
          }
        }
      }
    }
    
    return maxScore;
  } else {
    // 玩家回合（最小化分数）
    let minScore = Infinity;
    
    for (let x = 0; x < board.length; x++) {
      for (let y = 0; y < board[x].length; y++) {
        if (board[x][y] === null) {
          board[x][y] = 'black';
          const score = minimax(board, depth - 1, alpha, beta, true);
          board[x][y] = null;
          
          minScore = Math.min(minScore, score);
          beta = Math.min(beta, score);
          
          if (beta <= alpha) {
            break; // Alpha-Beta剪枝
          }
        }
      }
    }
    
    return minScore;
  }
}

// 评估棋盘分数
function evaluateBoard(board) {
  let score = 0;
  
  // 简单的评分系统：计算连续的棋子数量
  for (let x = 0; x < board.length; x++) {
    for (let y = 0; y < board[x].length; y++) {
      if (board[x][y] === 'white') {
        score += evaluatePosition(board, x, y, 'white');
      } else if (board[x][y] === 'black') {
        score -= evaluatePosition(board, x, y, 'black');
      }
    }
  }
  
  return score;
}

// 评估特定位置的分数
function evaluatePosition(board, x, y, player) {
  let score = 0;
  const directions = [[1, 0], [0, 1], [1, 1], [1, -1]];
  
  for (const [dx, dy] of directions) {
    let count = 1;
    let hasSpace = false;
    
    // 向一个方向检查
    for (let i = 1; i <= 4; i++) {
      const nx = x + dx * i;
      const ny = y + dy * i;
      if (nx >= 0 && nx < board.length && ny >= 0 && ny < board[nx].length) {
        if (board[nx][ny] === player) {
          count++;
        } else if (board[nx][ny] === null) {
          hasSpace = true;
          break;
        } else {
          break;
        }
      } else {
        break;
      }
    }
    
    // 向相反方向检查
    for (let i = 1; i <= 4; i++) {
      const nx = x - dx * i;
      const ny = y - dy * i;
      if (nx >= 0 && nx < board.length && ny >= 0 && ny < board[nx].length) {
        if (board[nx][ny] === player) {
          count++;
        } else if (board[nx][ny] === null) {
          hasSpace = true;
          break;
        } else {
          break;
        }
      } else {
        break;
      }
    }
    
    // 根据连续棋子数量给予分数
    if (count === 1) score += 1;
    else if (count === 2) score += 10;
    else if (count === 3) score += 100;
    else if (count === 4) score += 1000;
    else if (count >= 5) score += 10000;
    
    // 如果两端有空间，增加分数
    if (hasSpace && count > 1) {
      score += count * 5;
    }
  }
  
  return score;
}

// 保存游戏数据到本地存储
function saveGameData() {
  localStorage.setItem('gomokuGameData', JSON.stringify(gameState.stats));
}

// 从本地存储加载游戏数据
function loadGameData() {
  const data = localStorage.getItem('gomokuGameData');
  if (data) {
    try {
      gameState.stats = JSON.parse(data);
    } catch (error) {
      console.error('加载游戏数据失败:', error);
    }
  }
}

// 更新UI显示
function updateUI() {
  // 更新当前玩家显示
  if (gameState.currentPlayer === 'black') {
    elements.currentPlayerIcon.className = 'w-5 h-5 rounded-full bg-blackStone';
    elements.currentPlayerText.textContent = '黑方';
  } else {
    elements.currentPlayerIcon.className = 'w-5 h-5 rounded-full bg-whiteStone border border-gray-300';
    elements.currentPlayerText.textContent = '白方';
  }
  
  // 更新游戏统计
  elements.playCount.textContent = gameState.stats.playCount;
  elements.blackWins.textContent = gameState.stats.blackWins;
  elements.whiteWins.textContent = gameState.stats.whiteWins;
  elements.draws.textContent = gameState.stats.draws;
  
  // 更新按钮状态
  elements.undoButton.disabled = gameState.gameHistory.length === 0 || !gameState.isRunning;
}

// 设置事件监听器
function setupEventListeners() {
  // 游戏控制按钮
  elements.startButton.addEventListener('click', startGame);
  elements.restartButton.addEventListener('click', restartGame);
  elements.undoButton.addEventListener('click', undoMove);
  elements.saveButton.addEventListener('click', saveGame);
  elements.overlayButton.addEventListener('click', restartGame);
  
  // 游戏设置选择器
  elements.gameModeSelect.addEventListener('change', (e) => {
    gameState.gameMode = e.target.value;
    
    // 显示或隐藏AI难度选择器
    if (gameState.gameMode === 'human-vs-ai') {
      elements.aiDifficultyContainer.classList.remove('hidden');
    } else {
      elements.aiDifficultyContainer.classList.add('hidden');
    }
  });
  
  elements.aiDifficultySelect.addEventListener('change', (e) => {
    gameState.aiDifficulty = e.target.value;
  });
  
  elements.boardSizeSelect.addEventListener('change', () => {
    if (!gameState.isRunning) {
      resetBoard();
    }
  });
  
  // 棋盘点击事件
  elements.boardGrid.addEventListener('click', (e) => {
    // 计算点击位置对应的棋盘坐标
    const rect = elements.boardGrid.getBoundingClientRect();
    const x = Math.floor((e.clientX - rect.left - config.borderSize) / config.cellSize);
    const y = Math.floor((e.clientY - rect.top - config.borderSize) / config.cellSize);
    
    // 检查坐标是否有效
    if (x >= 0 && x < gameState.size && y >= 0 && y < gameState.size) {
      // 如果是玩家回合，放置棋子
      const isPlayerTurn = (gameState.gameMode === 'human-vs-human') || 
                           (gameState.gameMode === 'human-vs-ai' && gameState.currentPlayer === 'black');
      
      if (gameState.isRunning && isPlayerTurn) {
        placeStone(x, y);
      }
    }
  });
  
  // 移动端菜单
  elements.menuToggle.addEventListener('click', () => {
    elements.mobileMenu.classList.toggle('hidden');
  });
  
  // 键盘控制
  document.addEventListener('keydown', (e) => {
    // 检查是否是组合键（如Alt+左箭头用于浏览器后退），如果是，则不阻止默认行为
    if (e.altKey || e.ctrlKey || e.metaKey) {
      return;
    }
    
    // 防止页面滚动
    if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'w', 's', 'a', 'd'].includes(e.key.toLowerCase())) {
      e.preventDefault();
    }
    
    // 快捷键控制
    switch (e.key.toLowerCase()) {
      case 'r': // R键重新开始
        if (e.ctrlKey || e.metaKey) return; // 忽略Ctrl+R或Command+R
        restartGame();
        break;
      case 'u': // U键悔棋
        undoMove();
        break;
      case 's': // S键保存游戏
        saveGame();
        break;
      case 'l': // L键加载游戏
        loadGame();
        break;
      case ' ': // 空格键开始/暂停
        if (!gameState.isRunning) {
          startGame();
        }
        break;
    }
  });
}

// 当页面加载完成时初始化游戏
window.addEventListener('load', initGame);