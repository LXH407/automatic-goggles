// 2048游戏脚本

// 游戏配置
const config = {
  gridSize: 4,
  startTiles: 2
};

// 游戏状态
const gameState = {
  board: [],
  score: 0,
  bestScore: 0,
  playCount: 0,
  isGameOver: false,
  isGameWon: false,
  isRunning: false,
  tileSize: 0
};

// DOM元素
const elements = {
  gameGrid: document.getElementById('game-grid'),
  tilesContainer: document.getElementById('tiles-container'),
  startButton: document.getElementById('start-button'),
  restartButton: document.getElementById('restart-button'),
  currentScore: document.getElementById('current-score'),
  highScore: document.getElementById('high-score'),
  playCount: document.getElementById('play-count'),
  gameOver: document.getElementById('game-over'),
  gameOverMessage: document.getElementById('game-over-message'),
  finalScore: document.getElementById('final-score'),
  bestScore: document.getElementById('best-score'),
  playAgainButton: document.getElementById('play-again-button'),
  mobileUp: document.getElementById('mobile-up'),
  mobileDown: document.getElementById('mobile-down'),
  mobileLeft: document.getElementById('mobile-left'),
  mobileRight: document.getElementById('mobile-right'),
  mobileMenuToggle: document.getElementById('menu-toggle'),
  mobileMenu: document.getElementById('mobile-menu')
};

// 初始化游戏板
function initializeBoard() {
  gameState.board = Array(config.gridSize).fill().map(() => Array(config.gridSize).fill(0));
}

// 随机生成新方块
function generateRandomTile() {
  // 找出所有空位置
  const emptyCells = [];
  for (let y = 0; y < config.gridSize; y++) {
    for (let x = 0; x < config.gridSize; x++) {
      if (gameState.board[y][x] === 0) {
        emptyCells.push({x, y});
      }
    }
  }
  
  // 如果没有空位置，返回false
  if (emptyCells.length === 0) {
    return false;
  }
  
  // 随机选择一个空位置
  const randomCell = emptyCells[Math.floor(Math.random() * emptyCells.length)];
  
  // 90%的概率生成2，10%的概率生成4
  const value = Math.random() < 0.9 ? 2 : 4;
  
  // 在选中的位置生成新方块
  gameState.board[randomCell.y][randomCell.x] = value;
  
  // 渲染新方块
  renderTile(randomCell.x, randomCell.y, value);
  
  return true;
}

// 渲染游戏板
function renderBoard() {
  // 清空现有方块
  elements.tilesContainer.innerHTML = '';
  
  // 计算方块大小
  updateTileSize();
  
  // 渲染每个非零方块
  for (let y = 0; y < config.gridSize; y++) {
    for (let x = 0; x < config.gridSize; x++) {
      const value = gameState.board[y][x];
      if (value !== 0) {
        renderTile(x, y, value);
      }
    }
  }
}

// 渲染单个方块
function renderTile(x, y, value) {
  const tile = document.createElement('div');
  
  // 设置方块样式
  tile.classList.add('tile');
  tile.classList.add(`tile-${value}`);
  
  // 设置方块大小和位置
  const gap = 12; // 方块间距（px）
  const tileSize = gameState.tileSize;
  const left = x * (tileSize + gap) + gap;
  const top = y * (tileSize + gap) + gap;
  
  tile.style.width = `${tileSize}px`;
  tile.style.height = `${tileSize}px`;
  tile.style.left = `${left}px`;
  tile.style.top = `${top}px`;
  
  // 设置方块文本
  tile.textContent = value;
  
  // 根据方块值设置文本样式
  if (value >= 1000) {
    tile.style.fontSize = '20px';
  } else if (value >= 100) {
    tile.style.fontSize = '24px';
  } else if (value >= 10) {
    tile.style.fontSize = '28px';
  } else {
    tile.style.fontSize = '32px';
  }
  
  // 添加到容器
  elements.tilesContainer.appendChild(tile);
}

// 更新方块大小
function updateTileSize() {
  const containerWidth = elements.gameGrid.clientWidth;
  const gap = 12; // 方块间距（px）
  gameState.tileSize = (containerWidth - gap * (config.gridSize + 1)) / config.gridSize;
}

// 向左移动
function moveLeft() {
  let moved = false;
  
  for (let y = 0; y < config.gridSize; y++) {
    // 先合并相同的方块
    for (let x = 1; x < config.gridSize; x++) {
      if (gameState.board[y][x] !== 0) {
        let newX = x;
        
        // 找到可以移动到的最左位置
        while (newX > 0 && gameState.board[y][newX - 1] === 0) {
          newX--;
          moved = true;
        }
        
        // 检查是否可以合并
        if (newX > 0 && gameState.board[y][newX - 1] === gameState.board[y][x]) {
          // 合并方块
          gameState.board[y][newX - 1] *= 2;
          gameState.score += gameState.board[y][newX - 1];
          gameState.board[y][x] = 0;
          moved = true;
          
          // 检查是否达到2048
          if (gameState.board[y][newX - 1] === 2048 && !gameState.isGameWon) {
            gameState.isGameWon = true;
          }
        } else if (newX !== x) {
          // 只是移动方块
          gameState.board[y][newX] = gameState.board[y][x];
          gameState.board[y][x] = 0;
          moved = true;
        }
      }
    }
  }
  
  return moved;
}

// 向右移动
function moveRight() {
  let moved = false;
  
  for (let y = 0; y < config.gridSize; y++) {
    // 先合并相同的方块
    for (let x = config.gridSize - 2; x >= 0; x--) {
      if (gameState.board[y][x] !== 0) {
        let newX = x;
        
        // 找到可以移动到的最右位置
        while (newX < config.gridSize - 1 && gameState.board[y][newX + 1] === 0) {
          newX++;
          moved = true;
        }
        
        // 检查是否可以合并
        if (newX < config.gridSize - 1 && gameState.board[y][newX + 1] === gameState.board[y][x]) {
          // 合并方块
          gameState.board[y][newX + 1] *= 2;
          gameState.score += gameState.board[y][newX + 1];
          gameState.board[y][x] = 0;
          moved = true;
          
          // 检查是否达到2048
          if (gameState.board[y][newX + 1] === 2048 && !gameState.isGameWon) {
            gameState.isGameWon = true;
          }
        } else if (newX !== x) {
          // 只是移动方块
          gameState.board[y][newX] = gameState.board[y][x];
          gameState.board[y][x] = 0;
          moved = true;
        }
      }
    }
  }
  
  return moved;
}

// 向上移动
function moveUp() {
  let moved = false;
  
  for (let x = 0; x < config.gridSize; x++) {
    // 先合并相同的方块
    for (let y = 1; y < config.gridSize; y++) {
      if (gameState.board[y][x] !== 0) {
        let newY = y;
        
        // 找到可以移动到的最上位置
        while (newY > 0 && gameState.board[newY - 1][x] === 0) {
          newY--;
          moved = true;
        }
        
        // 检查是否可以合并
        if (newY > 0 && gameState.board[newY - 1][x] === gameState.board[y][x]) {
          // 合并方块
          gameState.board[newY - 1][x] *= 2;
          gameState.score += gameState.board[newY - 1][x];
          gameState.board[y][x] = 0;
          moved = true;
          
          // 检查是否达到2048
          if (gameState.board[newY - 1][x] === 2048 && !gameState.isGameWon) {
            gameState.isGameWon = true;
          }
        } else if (newY !== y) {
          // 只是移动方块
          gameState.board[newY][x] = gameState.board[y][x];
          gameState.board[y][x] = 0;
          moved = true;
        }
      }
    }
  }
  
  return moved;
}

// 向下移动
function moveDown() {
  let moved = false;
  
  for (let x = 0; x < config.gridSize; x++) {
    // 先合并相同的方块
    for (let y = config.gridSize - 2; y >= 0; y--) {
      if (gameState.board[y][x] !== 0) {
        let newY = y;
        
        // 找到可以移动到的最下位置
        while (newY < config.gridSize - 1 && gameState.board[newY + 1][x] === 0) {
          newY++;
          moved = true;
        }
        
        // 检查是否可以合并
        if (newY < config.gridSize - 1 && gameState.board[newY + 1][x] === gameState.board[y][x]) {
          // 合并方块
          gameState.board[newY + 1][x] *= 2;
          gameState.score += gameState.board[newY + 1][x];
          gameState.board[y][x] = 0;
          moved = true;
          
          // 检查是否达到2048
          if (gameState.board[newY + 1][x] === 2048 && !gameState.isGameWon) {
            gameState.isGameWon = true;
          }
        } else if (newY !== y) {
          // 只是移动方块
          gameState.board[newY][x] = gameState.board[y][x];
          gameState.board[y][x] = 0;
          moved = true;
        }
      }
    }
  }
  
  return moved;
}

// 检查游戏是否结束
function checkGameOver() {
  // 检查是否有空格子
  for (let y = 0; y < config.gridSize; y++) {
    for (let x = 0; x < config.gridSize; x++) {
      if (gameState.board[y][x] === 0) {
        return false;
      }
    }
  }
  
  // 检查是否有可以合并的方块
  for (let y = 0; y < config.gridSize; y++) {
    for (let x = 0; x < config.gridSize; x++) {
      const value = gameState.board[y][x];
      
      // 检查右侧
      if (x < config.gridSize - 1 && gameState.board[y][x + 1] === value) {
        return false;
      }
      
      // 检查下方
      if (y < config.gridSize - 1 && gameState.board[y + 1][x] === value) {
        return false;
      }
    }
  }
  
  // 如果没有空格子也没有可以合并的方块，则游戏结束
  return true;
}

// 开始游戏
function startGame() {
  // 重置游戏状态
  gameState.isRunning = true;
  gameState.isGameOver = false;
  gameState.isGameWon = false;
  gameState.score = 0;
  
  // 初始化游戏板
  initializeBoard();
  
  // 生成初始方块
  for (let i = 0; i < config.startTiles; i++) {
    generateRandomTile();
  }
  
  // 渲染游戏板
  renderBoard();
  
  // 更新UI
  updateUI();
  
  // 禁用开始按钮
  elements.startButton.disabled = true;
  elements.startButton.classList.add('opacity-50', 'cursor-not-allowed');
  
  // 隐藏游戏结束遮罩
  elements.gameOver.classList.add('hidden');
}

// 重新开始游戏
function restartGame() {
  // 增加游戏次数
  gameState.playCount++;
  
  // 开始新游戏
  startGame();
  
  // 保存游戏数据
  saveGameData();
}

// 结束游戏
function endGame() {
  gameState.isGameOver = true;
  gameState.isRunning = false;
  
  // 更新最高分
  if (gameState.score > gameState.bestScore) {
    gameState.bestScore = gameState.score;
    localStorage.setItem('2048BestScore', gameState.bestScore.toString());
  }
  
  // 增加游戏次数
  gameState.playCount++;
  
  // 保存游戏数据
  saveGameData();
  
  // 显示游戏结束遮罩
  elements.gameOverMessage.textContent = gameState.isGameWon ? '恭喜您创建了2048！' : '游戏结束！';
  elements.finalScore.textContent = gameState.score;
  elements.bestScore.textContent = gameState.bestScore;
  elements.gameOver.classList.remove('hidden');
  
  // 启用开始按钮
  elements.startButton.disabled = false;
  elements.startButton.classList.remove('opacity-50', 'cursor-not-allowed');
}

// 更新UI
function updateUI() {
  elements.currentScore.textContent = gameState.score;
  elements.highScore.textContent = gameState.bestScore;
  elements.playCount.textContent = gameState.playCount;
}

// 保存游戏数据
function saveGameData() {
  localStorage.setItem('2048BestScore', gameState.bestScore.toString());
  localStorage.setItem('2048PlayCount', gameState.playCount.toString());
}

// 加载游戏数据
function loadGameData() {
  const bestScore = localStorage.getItem('2048BestScore');
  const playCount = localStorage.getItem('2048PlayCount');
  
  gameState.bestScore = bestScore ? parseInt(bestScore) : 0;
  gameState.playCount = playCount ? parseInt(playCount) : 0;
}

// 设置事件监听器
function setupEventListeners() {
  // 按钮事件
  elements.startButton.addEventListener('click', startGame);
  elements.restartButton.addEventListener('click', restartGame);
  elements.playAgainButton.addEventListener('click', restartGame);
  
  // 移动端控制按钮
  elements.mobileUp.addEventListener('click', () => move('up'));
  elements.mobileDown.addEventListener('click', () => move('down'));
  elements.mobileLeft.addEventListener('click', () => move('left'));
  elements.mobileRight.addEventListener('click', () => move('right'));
  
  // 移动端菜单切换
  elements.mobileMenuToggle.addEventListener('click', () => {
    elements.mobileMenu.classList.toggle('hidden');
  });
  
  // 键盘控制
  document.addEventListener('keydown', handleKeyDown);
  
  // 响应式处理
  window.addEventListener('resize', () => {
    if (gameState.isRunning) {
      renderBoard();
    }
  });
}

// 处理键盘按键
function handleKeyDown(event) {
  // 检查是否是组合键（如Alt+左箭头用于浏览器后退），如果是，则不阻止默认行为
  if (event.altKey || event.ctrlKey || event.metaKey) {
    return;
  }
  
  // 防止页面滚动
  if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'w', 's', 'a', 'd'].includes(event.key.toLowerCase())) {
    event.preventDefault();
  }
  
  // 如果游戏未运行或已结束，则不处理
  if (!gameState.isRunning || gameState.isGameOver) {
    // 空格键开始游戏
    if (event.key === ' ') {
      startGame();
    }
    return;
  }
  
  // 根据按键移动方块
  switch (event.key.toLowerCase()) {
    case 'arrowup':
    case 'w':
      move('up');
      break;
    case 'arrowdown':
    case 's':
      move('down');
      break;
    case 'arrowleft':
    case 'a':
      move('left');
      break;
    case 'arrowright':
    case 'd':
      move('right');
      break;
    case ' ': // 空格键暂停/继续游戏
      if (gameState.isRunning) {
        // 这里可以添加暂停功能
      }
      break;
    case 'r': // R键重新开始游戏
      if (event.ctrlKey || event.metaKey) return;
      restartGame();
      break;
  }
}

// 移动方块
function move(direction) {
  let moved = false;
  
  // 根据方向移动方块
  switch (direction) {
    case 'up':
      moved = moveUp();
      break;
    case 'down':
      moved = moveDown();
      break;
    case 'left':
      moved = moveLeft();
      break;
    case 'right':
      moved = moveRight();
      break;
  }
  
  // 如果有移动，生成新方块并检查游戏是否结束
  if (moved) {
    // 重新渲染游戏板
    renderBoard();
    
    // 生成新方块
    const canGenerate = generateRandomTile();
    
    // 更新UI
    updateUI();
    
    // 检查游戏是否结束
    if (!canGenerate && checkGameOver()) {
      endGame();
    } else if (gameState.isGameWon && !gameState.isGameOver) {
      // 游戏胜利但继续游戏
      // 这里可以添加胜利提示，但不结束游戏
    }
  }
}

// 初始化游戏
function initGame() {
  setupEventListeners();
  loadGameData();
  updateUI();
}

// 页面加载完成后初始化游戏
window.addEventListener('load', initGame);