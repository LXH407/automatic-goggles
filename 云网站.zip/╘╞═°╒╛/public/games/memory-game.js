// 记忆配对游戏脚本

// 游戏配置
const config = {
  difficulties: {
    easy: { pairs: 8, gridSize: '4x4' },
    medium: { pairs: 12, gridSize: '4x6' },
    hard: { pairs: 16, gridSize: '4x8' }
  },
  initialDifficulty: 'medium'
};

// 游戏状态
const gameState = {
  isRunning: false,
  isPaused: false,
  currentDifficulty: config.initialDifficulty,
  cards: [],
  flippedCards: [],
  matchedPairs: 0,
  flipsCount: 0,
  startTime: null,
  elapsedTime: 0,
  timerInterval: null,
  isProcessing: false
};

// DOM元素
const elements = {
  memoryGrid: document.getElementById('memory-grid'),
  startButton: document.getElementById('start-button'),
  restartButton: document.getElementById('restart-button'),
  difficultySelect: document.getElementById('difficulty-select'),
  flipsCount: document.getElementById('flips-count'),
  matchesCount: document.getElementById('matches-count'),
  gameTime: document.getElementById('game-time'),
  bestTime: document.getElementById('best-time'),
  gameOver: document.getElementById('game-over'),
  finalFlips: document.getElementById('final-flips'),
  finalTime: document.getElementById('final-time'),
  bestTimeDisplay: document.getElementById('best-time-display'),
  playAgainButton: document.getElementById('play-again-button'),
  mobileMenuToggle: document.getElementById('menu-toggle'),
  mobileMenu: document.getElementById('mobile-menu')
};

// 生成卡片数据
function generateCards(difficulty) {
  const pairs = config.difficulties[difficulty].pairs;
  const cards = [];
  const icons = ['fa-heart', 'fa-star', 'fa-diamond', 'fa-bolt', 'fa-leaf', 'fa-car', 'fa-plane', 'fa-rocket', 
                 'fa-key', 'fa-moon-o', 'fa-sun-o', 'fa-tree', 'fa-bell', 'fa-coffee', 'fa-book', 'fa-gamepad'];
  
  // 确保有足够的图标
  while (icons.length < pairs) {
    // 如果图标不够，复制已有的图标
    icons.push(...icons.slice(0, pairs - icons.length));
  }
  
  // 为每对创建两张相同的卡片
  for (let i = 0; i < pairs; i++) {
    const icon = icons[i];
    cards.push({
      id: i * 2,
      icon: icon,
      isFlipped: false,
      isMatched: false
    });
    cards.push({
      id: i * 2 + 1,
      icon: icon,
      isFlipped: false,
      isMatched: false
    });
  }
  
  // 打乱卡片顺序
  return shuffleArray(cards);
}

// 打乱数组顺序
function shuffleArray(array) {
  const newArray = [...array];
  for (let i = newArray.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [newArray[i], newArray[j]] = [newArray[j], newArray[i]];
  }
  return newArray;
}

// 渲染游戏网格
function renderGrid() {
  const gridSize = config.difficulties[gameState.currentDifficulty].gridSize;
  elements.memoryGrid.style.gridTemplateColumns = `repeat(${gridSize.split('x')[1]}, 1fr)`;
  elements.memoryGrid.innerHTML = '';
  
  gameState.cards.forEach(card => {
    const cardElement = document.createElement('div');
    cardElement.classList.add('memory-card');
    cardElement.dataset.id = card.id;
    
    cardElement.innerHTML = `
      <div class="card-inner ${card.isFlipped || card.isMatched ? 'card-flipped' : ''}">
        <div class="card-front bg-primary text-white">
          <i class="fa fa-puzzle-piece text-2xl"></i>
        </div>
        <div class="card-back bg-white border-2 border-primary text-primary">
          <i class="fa ${card.icon} text-3xl"></i>
        </div>
      </div>
    `;
    
    cardElement.addEventListener('click', () => handleCardClick(card));
    elements.memoryGrid.appendChild(cardElement);
  });
}

// 处理卡片点击
function handleCardClick(card) {
  // 如果游戏未运行、正在处理、卡片已经翻开或已匹配，则不处理
  if (!gameState.isRunning || gameState.isProcessing || card.isFlipped || card.isMatched) {
    return;
  }
  
  // 如果已经翻了两张牌，则不处理
  if (gameState.flippedCards.length >= 2) {
    return;
  }
  
  // 翻牌
  flipCard(card);
  gameState.flipsCount++;
  updateUI();
  
  // 检查是否翻了两张牌
  if (gameState.flippedCards.length === 2) {
    gameState.isProcessing = true;
    setTimeout(() => {
      checkMatch();
      gameState.isProcessing = false;
    }, 1000);
  }
}

// 翻牌
function flipCard(card) {
  card.isFlipped = true;
  gameState.flippedCards.push(card);
  
  // 更新DOM
  const cardElement = elements.memoryGrid.querySelector(`[data-id="${card.id}"]`);
  if (cardElement) {
    const cardInner = cardElement.querySelector('.card-inner');
    cardInner.classList.add('card-flipped');
  }
}

// 检查是否匹配
function checkMatch() {
  const [card1, card2] = gameState.flippedCards;
  
  if (card1.icon === card2.icon) {
    // 匹配成功
    card1.isMatched = true;
    card2.isMatched = true;
    gameState.matchedPairs++;
    
    // 检查游戏是否结束
    if (gameState.matchedPairs === config.difficulties[gameState.currentDifficulty].pairs) {
      endGame();
    }
  } else {
    // 匹配失败，翻回卡片
    card1.isFlipped = false;
    card2.isFlipped = false;
    
    // 更新DOM
    const cardElement1 = elements.memoryGrid.querySelector(`[data-id="${card1.id}"]`);
    const cardElement2 = elements.memoryGrid.querySelector(`[data-id="${card2.id}"]`);
    
    if (cardElement1) {
      const cardInner1 = cardElement1.querySelector('.card-inner');
      cardInner1.classList.remove('card-flipped');
    }
    
    if (cardElement2) {
      const cardInner2 = cardElement2.querySelector('.card-inner');
      cardInner2.classList.remove('card-flipped');
    }
  }
  
  // 清空已翻卡片
  gameState.flippedCards = [];
  updateUI();
}

// 开始游戏
function startGame() {
  // 重置游戏状态
  gameState.isRunning = true;
  gameState.isPaused = false;
  gameState.matchedPairs = 0;
  gameState.flipsCount = 0;
  gameState.elapsedTime = 0;
  gameState.flippedCards = [];
  
  // 生成卡片
  gameState.cards = generateCards(gameState.currentDifficulty);
  
  // 渲染网格
  renderGrid();
  
  // 更新UI
  updateUI();
  
  // 开始计时
  gameState.startTime = Date.now() - gameState.elapsedTime;
  clearInterval(gameState.timerInterval);
  gameState.timerInterval = setInterval(updateGameTime, 1000);
  
  // 隐藏游戏结束遮罩
  elements.gameOver.classList.add('hidden');
  
  // 禁用开始按钮
  elements.startButton.disabled = true;
  elements.startButton.classList.add('opacity-50', 'cursor-not-allowed');
}

// 重新开始游戏
function restartGame() {
  // 清除计时器
  clearInterval(gameState.timerInterval);
  
  // 开始新游戏
  startGame();
}

// 结束游戏
function endGame() {
  // 停止计时器
  clearInterval(gameState.timerInterval);
  
  // 更新游戏数据
  gameState.isRunning = false;
  
  // 保存游戏数据
  saveGameData();
  
  // 显示游戏结束遮罩
  elements.finalFlips.textContent = gameState.flipsCount;
  elements.finalTime.textContent = formatTime(gameState.elapsedTime);
  elements.bestTimeDisplay.textContent = getBestTime();
  elements.gameOver.classList.remove('hidden');
  
  // 启用开始按钮
  elements.startButton.disabled = false;
  elements.startButton.classList.remove('opacity-50', 'cursor-not-allowed');
}

// 更新游戏时间
function updateGameTime() {
  if (gameState.isRunning && !gameState.isPaused) {
    gameState.elapsedTime = Date.now() - gameState.startTime;
    elements.gameTime.textContent = formatTime(gameState.elapsedTime);
  }
}

// 格式化时间
function formatTime(milliseconds) {
  const totalSeconds = Math.floor(milliseconds / 1000);
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
}

// 更新UI
function updateUI() {
  elements.flipsCount.textContent = gameState.flipsCount;
  elements.matchesCount.textContent = gameState.matchedPairs;
  elements.gameTime.textContent = formatTime(gameState.elapsedTime);
  elements.bestTime.textContent = getBestTime();
}

// 获取最佳时间
function getBestTime() {
  const bestTime = localStorage.getItem(`memoryGameBestTime_${gameState.currentDifficulty}`);
  return bestTime ? formatTime(parseInt(bestTime)) : '00:00';
}

// 保存游戏数据
function saveGameData() {
  // 增加游戏次数
  const playCount = parseInt(localStorage.getItem('memoryGamePlayCount') || '0') + 1;
  localStorage.setItem('memoryGamePlayCount', playCount);
  
  // 保存最佳时间
  const bestTimeKey = `memoryGameBestTime_${gameState.currentDifficulty}`;
  const currentBestTime = localStorage.getItem(bestTimeKey);
  
  if (!currentBestTime || gameState.elapsedTime < parseInt(currentBestTime)) {
    localStorage.setItem(bestTimeKey, gameState.elapsedTime.toString());
  }
}

// 加载游戏数据
function loadGameData() {
  // 设置最佳时间显示
  elements.bestTime.textContent = getBestTime();
}

// 设置难度
function setDifficulty(difficulty) {
  gameState.currentDifficulty = difficulty;
  // 如果游戏正在运行，重新开始游戏
  if (gameState.isRunning) {
    restartGame();
  } else {
    // 否则只更新最佳时间显示
    elements.bestTime.textContent = getBestTime();
  }
}

// 设置事件监听器
function setupEventListeners() {
  // 按钮事件
  elements.startButton.addEventListener('click', startGame);
  elements.restartButton.addEventListener('click', restartGame);
  elements.playAgainButton.addEventListener('click', restartGame);
  
  // 难度选择事件
  elements.difficultySelect.addEventListener('change', (e) => setDifficulty(e.target.value));
  
  // 移动端菜单切换
  elements.mobileMenuToggle.addEventListener('click', () => {
    elements.mobileMenu.classList.toggle('hidden');
  });
  
  // 键盘控制
  document.addEventListener('keydown', handleKeyDown);
  
  // 响应式处理
  window.addEventListener('resize', () => {
    if (gameState.cards.length > 0) {
      renderGrid();
    }
  });
}

// 处理键盘按键
function handleKeyDown(event) {
  // 检查是否是组合键（如Alt+左箭头用于浏览器后退），如果是，则不阻止默认行为
  if (event.altKey || event.ctrlKey || event.metaKey) {
    return;
  }
  
  // 根据按键执行相应操作
  switch (event.key.toLowerCase()) {
    case ' ': // 空格键开始/继续游戏
      if (!gameState.isRunning) {
        startGame();
      }
      break;
    case 'r': // R键重新开始游戏
      if (event.ctrlKey || event.metaKey) return;
      restartGame();
      break;
  }
}

// 初始化游戏
function initGame() {
  setupEventListeners();
  loadGameData();
  updateUI();
  
  // 设置初始难度
  elements.difficultySelect.value = config.initialDifficulty;
}

// 页面加载完成后初始化游戏
window.addEventListener('load', initGame);