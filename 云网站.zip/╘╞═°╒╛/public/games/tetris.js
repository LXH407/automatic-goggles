// 游戏配置
const config = {
  rows: 20,
  cols: 10,
  cellSize: 25,
  initialSpeed: 1000, // 初始下落速度（毫秒）
  speedDecrement: 50, // 每升一级减少的速度（毫秒）
  minSpeed: 100, // 最小下落速度（毫秒）
  scorePerLine: 100, // 每消除一行的分数
  levelThreshold: 10, // 每升一级需要消除的行数
  // 方块形状定义
  shapes: {
    I: [
      [0, 0, 0, 0],
      [1, 1, 1, 1],
      [0, 0, 0, 0],
      [0, 0, 0, 0]
    ],
    J: [
      [1, 0, 0],
      [1, 1, 1],
      [0, 0, 0]
    ],
    L: [
      [0, 0, 1],
      [1, 1, 1],
      [0, 0, 0]
    ],
    O: [
      [1, 1],
      [1, 1]
    ],
    S: [
      [0, 1, 1],
      [1, 1, 0],
      [0, 0, 0]
    ],
    T: [
      [0, 1, 0],
      [1, 1, 1],
      [0, 0, 0]
    ],
    Z: [
      [1, 1, 0],
      [0, 1, 1],
      [0, 0, 0]
    ]
  },
  // 方块颜色
  colors: {
    I: 'tetris-i',
    J: 'tetris-j',
    L: 'tetris-l',
    O: 'tetris-o',
    S: 'tetris-s',
    T: 'tetris-t',
    Z: 'tetris-z'
  },
  // 方块旋转中心点偏移
  rotationOffsets: {
    I: [{x: 0, y: 0}, {x: 0, y: 0}, {x: 0, y: 0}, {x: 0, y: 0}],
    O: [{x: 0, y: 0}, {x: 0, y: 0}, {x: 0, y: 0}, {x: 0, y: 0}],
    J: [{x: 0, y: 0}, {x: 1, y: 0}, {x: 1, y: 1}, {x: 0, y: 1}],
    L: [{x: 0, y: 0}, {x: 1, y: 0}, {x: 1, y: 1}, {x: 0, y: 1}],
    S: [{x: 0, y: 0}, {x: 1, y: 0}, {x: 1, y: 1}, {x: 0, y: 1}],
    T: [{x: 0, y: 0}, {x: 1, y: 0}, {x: 1, y: 1}, {x: 0, y: 1}],
    Z: [{x: 0, y: 0}, {x: 1, y: 0}, {x: 1, y: 1}, {x: 0, y: 1}]
  }
};

// 游戏状态
const gameState = {
  board: [],
  currentPiece: null,
  nextPiece: null,
  score: 0,
  highScore: 0,
  level: 1,
  linesCleared: 0,
  isRunning: false,
  isPaused: false,
  gameInterval: null,
  currentSpeed: config.initialSpeed,
  dropSpeed: null
};

// DOM元素
const elements = {
  gameGrid: document.getElementById('game-grid'),
  nextPieceContainer: document.getElementById('next-piece-container'),
  currentScore: document.getElementById('current-score'),
  highScore: document.getElementById('high-score'),
  currentLevel: document.getElementById('current-level'),
  linesCleared: document.getElementById('lines-cleared'),
  startButton: document.getElementById('start-button'),
  pauseButton: document.getElementById('pause-button'),
  restartButton: document.getElementById('restart-button'),
  gameOverOverlay: document.getElementById('game-over-overlay'),
  gameOverTitle: document.getElementById('game-over-title'),
  gameOverScore: document.getElementById('game-over-score'),
  gameOverLevel: document.getElementById('game-over-level'),
  playAgainButton: document.getElementById('play-again-button'),
  menuToggle: document.getElementById('menu-toggle'),
  mobileMenu: document.getElementById('mobile-menu'),
  // 移动端控制按钮
  mobileLeft: document.getElementById('mobile-left'),
  mobileRight: document.getElementById('mobile-right'),
  mobileDown: document.getElementById('mobile-down'),
  mobileUp: document.getElementById('mobile-up'),
  mobileDrop: document.getElementById('mobile-drop'),
  mobileRotate: document.getElementById('mobile-rotate'),
  mobilePause: document.getElementById('mobile-pause'),
  mobileRestart: document.getElementById('mobile-restart')
};

// 初始化游戏
function initGame() {
  // 加载游戏数据
  loadGameData();
  
  // 初始化棋盘
  initializeBoard();
  
  // 生成第一个方块
  gameState.currentPiece = createNewPiece();
  gameState.nextPiece = createNewPiece();
  
  // 渲染棋盘和方块
  renderBoard();
  renderCurrentPiece();
  renderNextPiece();
  
  // 设置事件监听器
  setupEventListeners();
  
  // 更新UI
  updateUI();
}

// 初始化棋盘
function initializeBoard() {
  // 创建空棋盘
  gameState.board = Array(config.rows).fill().map(() => Array(config.cols).fill(null));
  
  // 设置游戏网格的尺寸
  elements.gameGrid.style.gridTemplateColumns = `repeat(${config.cols}, ${config.cellSize}px)`;
  elements.gameGrid.style.gridTemplateRows = `repeat(${config.rows}, ${config.cellSize}px)`;
  
  // 清空游戏网格
  elements.gameGrid.innerHTML = '';
  
  // 创建棋盘单元格
  for (let row = 0; row < config.rows; row++) {
    for (let col = 0; col < config.cols; col++) {
      const cell = document.createElement('div');
      cell.className = 'tetris-cell bg-white';
      cell.id = `cell-${row}-${col}`;
      elements.gameGrid.appendChild(cell);
    }
  }
}

// 创建新方块
function createNewPiece() {
  // 随机选择方块类型
  const shapeTypes = Object.keys(config.shapes);
  const shapeType = shapeTypes[Math.floor(Math.random() * shapeTypes.length)];
  
  // 获取方块形状
  const shape = config.shapes[shapeType];
  
  // 计算初始位置（居中）
  const initialCol = Math.floor((config.cols - shape[0].length) / 2);
  
  return {
    shape,
    type: shapeType,
    color: config.colors[shapeType],
    row: 0,
    col: initialCol,
    rotation: 0
  };
}

// 渲染棋盘
function renderBoard() {
  for (let row = 0; row < config.rows; row++) {
    for (let col = 0; col < config.cols; col++) {
      const cell = document.getElementById(`cell-${row}-${col}`);
      if (gameState.board[row][col]) {
        cell.className = `tetris-cell bg-${gameState.board[row][col]}`;
      } else {
        cell.className = 'tetris-cell bg-white';
      }
    }
  }
}

// 渲染当前方块
function renderCurrentPiece() {
  if (!gameState.currentPiece) return;
  
  const { shape, row, col, color } = gameState.currentPiece;
  
  for (let r = 0; r < shape.length; r++) {
    for (let c = 0; c < shape[r].length; c++) {
      if (shape[r][c]) {
        const boardRow = row + r;
        const boardCol = col + c;
        
        if (boardRow >= 0 && boardRow < config.rows && boardCol >= 0 && boardCol < config.cols) {
          const cell = document.getElementById(`cell-${boardRow}-${boardCol}`);
          cell.className = `tetris-cell bg-${color}`;
        }
      }
    }
  }
}

// 渲染下一个方块
function renderNextPiece() {
  if (!gameState.nextPiece) return;
  
  // 清空下一个方块容器
  elements.nextPieceContainer.innerHTML = '';
  
  const { shape, color } = gameState.nextPiece;
  
  // 创建一个网格来显示下一个方块
  const gridSize = Math.max(shape.length, shape[0].length);
  const cellSize = 20;
  const containerSize = gridSize * cellSize;
  
  // 设置容器尺寸
  elements.nextPieceContainer.style.width = `${containerSize}px`;
  elements.nextPieceContainer.style.height = `${containerSize}px`;
  
  // 计算偏移量以使方块居中
  const rowOffset = Math.floor((gridSize - shape.length) / 2);
  const colOffset = Math.floor((gridSize - shape[0].length) / 2);
  
  // 创建下一个方块网格
  for (let r = 0; r < gridSize; r++) {
    for (let c = 0; c < gridSize; c++) {
      const cell = document.createElement('div');
      cell.style.width = `${cellSize}px`;
      cell.style.height = `${cellSize}px`;
      cell.style.display = 'inline-block';
      cell.style.border = '1px solid rgba(0,0,0,0.05)';
      
      // 检查是否是方块的一部分
      const shapeRow = r - rowOffset;
      const shapeCol = c - colOffset;
      if (shapeRow >= 0 && shapeRow < shape.length && 
          shapeCol >= 0 && shapeCol < shape[0].length && 
          shape[shapeRow][shapeCol]) {
        cell.className = `bg-${color}`;
      } else {
        cell.className = 'bg-white';
      }
      
      elements.nextPieceContainer.appendChild(cell);
    }
    // 换行
    elements.nextPieceContainer.appendChild(document.createElement('br'));
  }
}

// 检查方块是否可以放置在指定位置
function isValidPosition(piece, newRow, newCol) {
  const { shape } = piece;
  
  for (let r = 0; r < shape.length; r++) {
    for (let c = 0; c < shape[r].length; c++) {
      if (shape[r][c]) {
        const boardRow = newRow + r;
        const boardCol = newCol + c;
        
        // 检查是否超出边界
        if (boardRow < 0 || boardRow >= config.rows || boardCol < 0 || boardCol >= config.cols) {
          return false;
        }
        
        // 检查是否与已有方块重叠
        if (gameState.board[boardRow][boardCol]) {
          return false;
        }
      }
    }
  }
  
  return true;
}

// 移动方块
function movePiece(deltaRow, deltaCol) {
  if (!gameState.currentPiece || !gameState.isRunning || gameState.isPaused) {
    return false;
  }
  
  const newRow = gameState.currentPiece.row + deltaRow;
  const newCol = gameState.currentPiece.col + deltaCol;
  
  if (isValidPosition(gameState.currentPiece, newRow, newCol)) {
    // 清除当前位置的方块
    renderBoard();
    
    // 更新方块位置
    gameState.currentPiece.row = newRow;
    gameState.currentPiece.col = newCol;
    
    // 渲染新位置的方块
    renderCurrentPiece();
    
    return true;
  }
  
  return false;
}

// 旋转方块
function rotatePiece() {
  if (!gameState.currentPiece || !gameState.isRunning || gameState.isPaused) {
    return false;
  }
  
  // 保存当前状态，以便旋转失败时恢复
  const oldShape = JSON.parse(JSON.stringify(gameState.currentPiece.shape));
  const oldRotation = gameState.currentPiece.rotation;
  
  // 计算新的旋转角度
  const newRotation = (gameState.currentPiece.rotation + 1) % 4;
  
  // 旋转方块
  const rotatedShape = rotateMatrix(gameState.currentPiece.shape);
  
  // 更新方块状态
  gameState.currentPiece.shape = rotatedShape;
  gameState.currentPiece.rotation = newRotation;
  
  // 检查旋转后的位置是否有效
  if (!isValidPosition(gameState.currentPiece, gameState.currentPiece.row, gameState.currentPiece.col)) {
    // 尝试墙踢（wall kick）
    const offsets = config.rotationOffsets[gameState.currentPiece.type][newRotation];
    
    if (isValidPosition(gameState.currentPiece, gameState.currentPiece.row + offsets.y, gameState.currentPiece.col + offsets.x)) {
      gameState.currentPiece.row += offsets.y;
      gameState.currentPiece.col += offsets.x;
    } else {
      // 旋转失败，恢复原状
      gameState.currentPiece.shape = oldShape;
      gameState.currentPiece.rotation = oldRotation;
      return false;
    }
  }
  
  // 重新渲染
  renderBoard();
  renderCurrentPiece();
  
  return true;
}

// 旋转矩阵（顺时针90度）
function rotateMatrix(matrix) {
  const rows = matrix.length;
  const cols = matrix[0].length;
  const rotated = Array(cols).fill().map(() => Array(rows).fill(0));
  
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      rotated[c][rows - 1 - r] = matrix[r][c];
    }
  }
  
  return rotated;
}

// 将当前方块固定到棋盘上
function lockPiece() {
  if (!gameState.currentPiece) return;
  
  const { shape, row, col, type } = gameState.currentPiece;
  
  // 将方块固定到棋盘上
  for (let r = 0; r < shape.length; r++) {
    for (let c = 0; c < shape[r].length; c++) {
      if (shape[r][c]) {
        const boardRow = row + r;
        const boardCol = col + c;
        
        if (boardRow >= 0 && boardRow < config.rows && boardCol >= 0 && boardCol < config.cols) {
          gameState.board[boardRow][boardCol] = type;
        }
      }
    }
  }
  
  // 检查是否有可消除的行
  clearLines();
  
  // 检查游戏是否结束
  if (isGameOver()) {
    endGame();
    return;
  }
  
  // 生成新的当前方块和下一个方块
  gameState.currentPiece = gameState.nextPiece;
  gameState.nextPiece = createNewPiece();
  
  // 重新渲染
  renderBoard();
  renderCurrentPiece();
  renderNextPiece();
  
  // 更新UI
  updateUI();
}

// 检查并消除完整的行
function clearLines() {
  let linesClearedThisTurn = 0;
  
  for (let row = config.rows - 1; row >= 0; row--) {
    let isLineComplete = true;
    
    // 检查当前行是否完整
    for (let col = 0; col < config.cols; col++) {
      if (!gameState.board[row][col]) {
        isLineComplete = false;
        break;
      }
    }
    
    // 如果行完整，消除它
    if (isLineComplete) {
      // 从当前行开始，将上面的行向下移动
      for (let r = row; r > 0; r--) {
        gameState.board[r] = [...gameState.board[r - 1]];
      }
      
      // 第一行填充为空
      gameState.board[0] = Array(config.cols).fill(null);
      
      // 增加已消除行数
      gameState.linesCleared++;
      linesClearedThisTurn++;
      
      // 重新检查当前行（因为上面的行移动下来了）
      row++;
    }
  }
  
  // 如果有消除行，计算得分
  if (linesClearedThisTurn > 0) {
    // 计算得分：单行100分，双行300分，三行500分，四行800分（经典俄罗斯方块得分规则）
    const scoreMultiplier = [0, 1, 3, 5, 8][Math.min(linesClearedThisTurn, 4)];
    const lineScore = config.scorePerLine * scoreMultiplier * gameState.level;
    gameState.score += lineScore;
    
    // 更新最高分
    if (gameState.score > gameState.highScore) {
      gameState.highScore = gameState.score;
      saveGameData();
    }
    
    // 检查是否升级
    const newLevel = Math.floor(gameState.linesCleared / config.levelThreshold) + 1;
    if (newLevel > gameState.level) {
      gameState.level = newLevel;
      
      // 更新游戏速度
      gameState.currentSpeed = Math.max(config.minSpeed, config.initialSpeed - (gameState.level - 1) * config.speedDecrement);
      
      // 更新游戏循环速度
      if (gameState.isRunning && !gameState.isPaused) {
        clearInterval(gameState.gameInterval);
        gameState.gameInterval = setInterval(gameLoop, gameState.currentSpeed);
      }
    }
    
    // 重新渲染
    renderBoard();
    renderCurrentPiece();
    
    // 更新UI
    updateUI();
  }
}

// 检查游戏是否结束
function isGameOver() {
  // 检查是否有方块堆叠到顶部
  for (let col = 0; col < config.cols; col++) {
    if (gameState.board[0][col]) {
      return true;
    }
  }
  
  // 检查新生成的方块是否能放置
  if (!isValidPosition(gameState.currentPiece, gameState.currentPiece.row, gameState.currentPiece.col)) {
    return true;
  }
  
  return false;
}

// 方块直接落地
function hardDrop() {
  if (!gameState.currentPiece || !gameState.isRunning || gameState.isPaused) {
    return;
  }
  
  // 尽可能向下移动方块
  while (movePiece(1, 0)) {}
  
  // 锁定方块
  lockPiece();
}

// 游戏主循环
function gameLoop() {
  if (!gameState.isRunning || gameState.isPaused) {
    return;
  }
  
  // 尝试向下移动方块
  if (!movePiece(1, 0)) {
    // 如果不能向下移动，锁定方块
    lockPiece();
  }
}

// 开始游戏
function startGame() {
  if (gameState.isRunning && !gameState.isPaused) return;
  
  if (gameState.isPaused) {
    // 继续游戏
    gameState.isPaused = false;
    
    // 重新启动游戏循环
    gameState.gameInterval = setInterval(gameLoop, gameState.currentSpeed);
    
    // 更新按钮状态
    elements.startButton.disabled = true;
    elements.pauseButton.disabled = false;
    elements.pauseButton.innerHTML = '<i class="fa fa-pause mr-2"></i>暂停游戏';
    
    // 隐藏游戏结束遮罩
    elements.gameOverOverlay.classList.add('hidden');
  } else {
    // 新游戏开始
    // 重置游戏状态
    gameState.score = 0;
    gameState.level = 1;
    gameState.linesCleared = 0;
    gameState.isRunning = true;
    gameState.isPaused = false;
    gameState.currentSpeed = config.initialSpeed;
    
    // 初始化棋盘
    initializeBoard();
    
    // 生成新方块
    gameState.currentPiece = createNewPiece();
    gameState.nextPiece = createNewPiece();
    
    // 渲染游戏
    renderBoard();
    renderCurrentPiece();
    renderNextPiece();
    
    // 更新按钮状态
    elements.startButton.disabled = true;
    elements.pauseButton.disabled = false;
    elements.restartButton.disabled = false;
    elements.pauseButton.innerHTML = '<i class="fa fa-pause mr-2"></i>暂停游戏';
    
    // 启动游戏循环
    gameState.gameInterval = setInterval(gameLoop, gameState.currentSpeed);
  }
  
  // 更新UI
  updateUI();
}

// 暂停游戏
function pauseGame() {
  if (!gameState.isRunning) return;
  
  if (!gameState.isPaused) {
    // 暂停游戏
    gameState.isPaused = true;
    clearInterval(gameState.gameInterval);
    
    // 更新按钮状态
    elements.startButton.disabled = false;
    elements.startButton.innerHTML = '<i class="fa fa-play mr-2"></i>继续游戏';
    elements.pauseButton.disabled = true;
  } else {
    // 继续游戏
    gameState.isPaused = false;
    gameState.gameInterval = setInterval(gameLoop, gameState.currentSpeed);
    
    // 更新按钮状态
    elements.startButton.disabled = true;
    elements.startButton.innerHTML = '<i class="fa fa-play mr-2"></i>开始游戏';
    elements.pauseButton.disabled = false;
  }
}

// 重新开始游戏
function restartGame() {
  // 清除游戏循环
  clearInterval(gameState.gameInterval);
  
  // 隐藏游戏结束遮罩
  elements.gameOverOverlay.classList.add('hidden');
  
  // 重置游戏状态
  gameState.score = 0;
  gameState.level = 1;
  gameState.linesCleared = 0;
  gameState.isRunning = false;
  gameState.isPaused = false;
  gameState.currentSpeed = config.initialSpeed;
  
  // 初始化棋盘
  initializeBoard();
  
  // 生成新方块
  gameState.currentPiece = createNewPiece();
  gameState.nextPiece = createNewPiece();
  
  // 渲染游戏
  renderBoard();
  renderCurrentPiece();
  renderNextPiece();
  
  // 更新按钮状态
  elements.startButton.disabled = false;
  elements.pauseButton.disabled = true;
  elements.restartButton.disabled = true;
  elements.startButton.innerHTML = '<i class="fa fa-play mr-2"></i>开始游戏';
  
  // 更新UI
  updateUI();
}

// 结束游戏
function endGame() {
  // 清除游戏循环
  clearInterval(gameState.gameInterval);
  
  // 更新游戏状态
  gameState.isRunning = false;
  
  // 更新游戏结束信息
  elements.gameOverScore.textContent = `最终得分: ${gameState.score}`;
  elements.gameOverLevel.textContent = `等级: ${gameState.level}`;
  
  // 显示游戏结束遮罩
  elements.gameOverOverlay.classList.remove('hidden');
  
  // 更新按钮状态
  elements.startButton.disabled = false;
  elements.pauseButton.disabled = true;
  elements.restartButton.disabled = true;
  
  // 保存游戏数据
  saveGameData();
}

// 保存游戏数据到本地存储
function saveGameData() {
  const data = {
    highScore: gameState.highScore
  };
  localStorage.setItem('tetrisGameData', JSON.stringify(data));
}

// 从本地存储加载游戏数据
function loadGameData() {
  const data = localStorage.getItem('tetrisGameData');
  if (data) {
    try {
      const parsedData = JSON.parse(data);
      gameState.highScore = parsedData.highScore || 0;
    } catch (error) {
      console.error('加载游戏数据失败:', error);
    }
  }
}

// 更新UI显示
function updateUI() {
  elements.currentScore.textContent = gameState.score;
  elements.highScore.textContent = gameState.highScore;
  elements.currentLevel.textContent = gameState.level;
  elements.linesCleared.textContent = gameState.linesCleared;
}

// 设置事件监听器
function setupEventListeners() {
  // 游戏控制按钮
  elements.startButton.addEventListener('click', startGame);
  elements.pauseButton.addEventListener('click', pauseGame);
  elements.restartButton.addEventListener('click', restartGame);
  elements.playAgainButton.addEventListener('click', restartGame);
  
  // 移动端菜单
  elements.menuToggle.addEventListener('click', () => {
    elements.mobileMenu.classList.toggle('hidden');
  });
  
  // 移动端控制按钮
  elements.mobileLeft.addEventListener('click', () => movePiece(0, -1));
  elements.mobileRight.addEventListener('click', () => movePiece(0, 1));
  elements.mobileDown.addEventListener('click', () => movePiece(1, 0));
  elements.mobileUp.addEventListener('click', rotatePiece);
  elements.mobileRotate.addEventListener('click', rotatePiece);
  elements.mobileDrop.addEventListener('click', hardDrop);
  elements.mobilePause.addEventListener('click', pauseGame);
  elements.mobileRestart.addEventListener('click', restartGame);
  
  // 键盘控制
  document.addEventListener('keydown', handleKeyDown);
  
  // 响应式处理
  window.addEventListener('resize', () => {
    // 重新渲染棋盘和方块
    renderBoard();
    renderCurrentPiece();
  });
}

// 处理键盘按键
function handleKeyDown(event) {
  // 检查是否是组合键（如Alt+左箭头用于浏览器后退），如果是，则不阻止默认行为
  if (event.altKey || event.ctrlKey || event.metaKey) {
    return;
  }
  
  // 防止页面滚动，但只在游戏运行时阻止
  if (gameState.isRunning && ['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'w', 's', 'a', 'd', ' '].includes(event.key.toLowerCase())) {
    event.preventDefault();
  }
  
  // 根据按键执行相应操作
  switch (event.key.toLowerCase()) {
    // 移动控制
    case 'arrowleft':
    case 'a':
      movePiece(0, -1);
      break;
    case 'arrowright':
    case 'd':
      movePiece(0, 1);
      break;
    case 'arrowdown':
    case 's':
      movePiece(1, 0);
      break;
    case 'arrowup':
    case 'w':
      rotatePiece();
      break;
    case ' ':
      hardDrop();
      break;
    case 'p':
      pauseGame();
      break;
    case 'r':
      if (event.ctrlKey || event.metaKey) return; // 忽略Ctrl+R或Command+R
      restartGame();
      break;
  }
}

// 当页面加载完成时初始化游戏
window.addEventListener('load', initGame);