// 游戏配置
const config = {
  gridSize: { rows: 5, cols: 9 },
  sunGenerationRate: 2000, // 每2秒生成一个阳光
  sunValue: 25, // 每个阳光值25点
  zombieGenerationRate: 8000, // 初始每8秒生成一个僵尸
  zombieSpeed: 50, // 僵尸移动速度（像素/秒）
  plantAttackRate: 1500, // 植物攻击间隔
  peaSpeed: 150, // 豌豆移动速度（像素/秒）
};

// 游戏状态
const gameState = {
  isRunning: false,
  isPaused: false,
  currentLevel: 1,
  levelProgress: 0,
  score: 0,
  sunPoints: 50,
  zombiesKilled: 0,
  selectedPlant: null,
  plants: [],
  zombies: [],
  peas: [],
  suns: [],
  gameInterval: null,
  sunGenerationInterval: null,
  zombieGenerationInterval: null,
  plantAttackInterval: null,
  lastZombieGeneration: 0,
  highScore: 0,
  playCount: 0,
  startTime: 0,
  elapsedTime: 0
};

// 植物类型定义
const plantTypes = {
  sunflower: {
    name: '向日葵',
    cost: 50,
    description: '产生阳光',
    icon: 'fa-sun-o',
    color: 'yellow',
    health: 300,
    generateSunRate: 8000, // 每8秒生成一个阳光
    attack: false
  },
  peashooter: {
    name: '豌豆射手',
    cost: 100,
    description: '发射豌豆',
    icon: 'fa-leaf',
    color: 'green',
    health: 300,
    attackRate: 1500,
    attackRange: 999,
    damage: 20,
    attack: true
  },
  wallnut: {
    name: '坚果墙',
    cost: 50,
    description: '阻挡僵尸',
    icon: 'fa-square',
    color: 'amber',
    health: 4000,
    attack: false
  },
  jalapeno: {
    name: '火爆辣椒',
    cost: 150,
    description: '直线清怪',
    icon: 'fa-fire',
    color: 'red',
    health: 300,
    attack: true,
    isExplosive: true
  }
};

// 僵尸类型定义
const zombieTypes = {
  normal: {
    name: '普通僵尸',
    health: 200,
    speed: 1,
    damage: 10,
    value: 10
  },
  conehead: {
    name: '路障僵尸',
    health: 600,
    speed: 1,
    damage: 10,
    value: 20
  },
  buckethead: {
    name: '铁桶僵尸',
    health: 1200,
    speed: 0.75,
    damage: 10,
    value: 30
  }
};

// DOM元素
const elements = {
  gameGrid: document.getElementById('game-grid'),
  gameContainer: document.getElementById('game-container'),
  score: document.getElementById('score'),
  sunPoints: document.getElementById('sun-points'),
  zombiesKilled: document.getElementById('zombies-killed'),
  currentLevel: document.getElementById('current-level'),
  levelProgress: document.getElementById('level-progress'),
  startButton: document.getElementById('start-button'),
  pauseButton: document.getElementById('pause-button'),
  restartButton: document.getElementById('restart-button'),
  plantSelection: document.getElementById('plant-selection'),
  gameOverOverlay: document.getElementById('game-over-overlay'),
  finalScore: document.getElementById('final-score'),
  finalLevel: document.getElementById('final-level'),
  finalZombies: document.getElementById('final-zombies'),
  playAgainButton: document.getElementById('play-again-button'),
  menuToggle: document.getElementById('menu-toggle'),
  mobileMenu: document.getElementById('mobile-menu')
};

// 初始化游戏
function initGame() {
  // 加载游戏数据
  loadGameData();
  
  // 渲染网格
  renderGrid();
  
  // 设置植物选择事件
  setupPlantSelection();
  
  // 设置事件监听器
  setupEventListeners();
  
  // 渲染UI
  updateUI();
}

// 渲染游戏网格
function renderGrid() {
  elements.gameGrid.innerHTML = '';
  
  for (let row = 0; row < config.gridSize.rows; row++) {
    for (let col = 0; col < config.gridSize.cols; col++) {
      const cell = document.createElement('div');
      cell.className = 'game-cell bg-white hover:bg-gray-100 cursor-pointer transition-custom';
      cell.dataset.row = row;
      cell.dataset.col = col;
      
      // 添加点击事件
      cell.addEventListener('click', () => handleCellClick(row, col));
      
      elements.gameGrid.appendChild(cell);
    }
  }
}

// 设置植物选择
function setupPlantSelection() {
  const plantCards = elements.plantSelection.querySelectorAll('.plant-card');
  
  plantCards.forEach((card, index) => {
    const plantNames = Object.keys(plantTypes);
    const plantName = plantNames[index];
    const plant = plantTypes[plantName];
    
    card.dataset.plantType = plantName;
    
    card.addEventListener('click', () => {
      // 检查阳光是否足够
      if (gameState.sunPoints >= plant.cost) {
        // 取消之前的选择
        plantCards.forEach(c => c.classList.remove('ring-2', 'ring-primary'));
        // 选择当前植物
        card.classList.add('ring-2', 'ring-primary');
        gameState.selectedPlant = plantName;
      } else {
        alert('阳光不足！');
      }
    });
  });
}

// 处理单元格点击
function handleCellClick(row, col) {
  if (!gameState.isRunning || gameState.isPaused) return;
  
  // 检查是否有选中的植物
  if (gameState.selectedPlant) {
    const plantType = plantTypes[gameState.selectedPlant];
    
    // 检查阳光是否足够
    if (gameState.sunPoints >= plantType.cost) {
      // 检查单元格是否为空
      const existingPlant = gameState.plants.find(p => p.row === row && p.col === col);
      
      if (!existingPlant) {
        // 种植植物
        plant(row, col, gameState.selectedPlant);
        // 扣除阳光
        gameState.sunPoints -= plantType.cost;
        // 取消选择
        gameState.selectedPlant = null;
        const plantCards = elements.plantSelection.querySelectorAll('.plant-card');
        plantCards.forEach(c => c.classList.remove('ring-2', 'ring-primary'));
        // 更新UI
        updateUI();
      }
    } else {
      alert('阳光不足！');
    }
  }
}

// 种植植物
function plant(row, col, plantType) {
  const plant = plantTypes[plantType];
  const newPlant = {
    id: Date.now(),
    type: plantType,
    row: row,
    col: col,
    health: plant.health,
    lastAttackTime: 0,
    lastSunGenerationTime: 0
  };
  
  gameState.plants.push(newPlant);
  
  // 渲染植物
  renderPlant(newPlant);
}

// 渲染植物
function renderPlant(plant) {
  const cell = elements.gameGrid.querySelector(`[data-row="${plant.row}"][data-col="${plant.col}"]`);
  if (cell) {
    // 清除单元格内容
    cell.innerHTML = '';
    
    // 创建植物元素
    const plantElement = document.createElement('div');
    plantElement.className = `w-full h-full flex items-center justify-center ${getPlantColorClass(plant.type)}`;
    plantElement.innerHTML = `<i class="fa ${plantTypes[plant.type].icon} text-2xl"></i>`;
    plantElement.dataset.plantId = plant.id;
    
    cell.appendChild(plantElement);
  }
}

// 获取植物颜色类
function getPlantColorClass(plantType) {
  const plant = plantTypes[plantType];
  switch (plant.color) {
    case 'yellow':
      return 'bg-yellow-100';
    case 'green':
      return 'bg-green-100';
    case 'amber':
      return 'bg-amber-100';
    case 'red':
      return 'bg-red-100';
    default:
      return 'bg-gray-100';
  }
}

// 生成僵尸
function generateZombie() {
  if (!gameState.isRunning || gameState.isPaused) return;
  
  const now = Date.now();
  // 控制僵尸生成频率
  if (now - gameState.lastZombieGeneration < getZombieGenerationRate()) {
    return;
  }
  
  gameState.lastZombieGeneration = now;
  
  // 随机选择僵尸类型
  const zombieNames = Object.keys(zombieTypes);
  const randomIndex = Math.floor(Math.random() * zombieNames.length);
  const zombieType = zombieNames[randomIndex];
  
  // 随机选择行
  const row = Math.floor(Math.random() * config.gridSize.rows);
  
  const zombie = zombieTypes[zombieType];
  const newZombie = {
    id: Date.now(),
    type: zombieType,
    row: row,
    x: elements.gameContainer.clientWidth,
    health: zombie.health,
    maxHealth: zombie.health,
    speed: zombie.speed,
    damage: zombie.damage,
    value: zombie.value
  };
  
  gameState.zombies.push(newZombie);
  
  // 渲染僵尸
  renderZombie(newZombie);
}

// 获取僵尸生成频率
function getZombieGenerationRate() {
  // 随着关卡增加，僵尸生成频率提高
  const baseRate = config.zombieGenerationRate;
  const reduction = (gameState.currentLevel - 1) * 500;
  return Math.max(2000, baseRate - reduction);
}

// 渲染僵尸
function renderZombie(zombie) {
  // 移除已存在的相同ID的僵尸元素
  const existingZombie = document.querySelector(`.zombie[data-zombie-id="${zombie.id}"]`);
  if (existingZombie) {
    existingZombie.remove();
  }
  
  // 创建僵尸元素
  const zombieElement = document.createElement('div');
  zombieElement.className = `zombie flex items-center justify-center ${getZombieColorClass(zombie.type)}`;
  zombieElement.style.width = '60px';
  zombieElement.style.height = '80px';
  zombieElement.style.left = `${zombie.x - 30}px`; // 居中
  zombieElement.style.top = `${(zombie.row * 100) + 10}px`; // 行位置
  zombieElement.innerHTML = `
    <div class="relative w-full h-full">
      <i class="fa fa-user-secret text-3xl text-gray-600"></i>
      <div class="absolute bottom-0 left-0 right-0 h-2 bg-gray-300 rounded-full">
        <div class="h-full bg-red-500 rounded-full" style="width: ${(zombie.health / zombie.maxHealth) * 100}%"></div>
      </div>
    </div>
  `;
  zombieElement.dataset.zombieId = zombie.id;
  
  elements.gameContainer.appendChild(zombieElement);
}

// 获取僵尸颜色类
function getZombieColorClass(zombieType) {
  switch (zombieType) {
    case 'normal':
      return 'bg-gray-100';
    case 'conehead':
      return 'bg-orange-100';
    case 'buckethead':
      return 'bg-blue-100';
    default:
      return 'bg-gray-100';
  }
}

// 移动僵尸
function moveZombies() {
  if (!gameState.isRunning || gameState.isPaused) return;
  
  gameState.zombies.forEach(zombie => {
    // 检查是否有植物在僵尸前面
    const plantsInRow = gameState.plants.filter(plant => plant.row === zombie.row && plant.col * (elements.gameContainer.clientWidth / config.gridSize.cols) < zombie.x);
    
    if (plantsInRow.length > 0) {
      // 找到最前面的植物
      const closestPlant = plantsInRow.reduce((closest, plant) => {
        const plantX = plant.col * (elements.gameContainer.clientWidth / config.gridSize.cols);
        const closestX = closest.col * (elements.gameContainer.clientWidth / config.gridSize.cols);
        return plantX > closestX ? plant : closest;
      });
      
      // 攻击植物
      attackPlant(zombie, closestPlant);
    } else {
      // 移动僵尸
      const cellWidth = elements.gameContainer.clientWidth / config.gridSize.cols;
      zombie.x -= (zombie.speed * cellWidth) / 20; // 每帧移动的距离
      
      // 检查是否到达最左侧
      if (zombie.x < 0) {
        endGame();
        return;
      }
    }
    
    // 更新僵尸位置
    renderZombie(zombie);
  });
}

// 攻击植物
function attackPlant(zombie, plant) {
  const now = Date.now();
  const attackInterval = 1000; // 每秒攻击一次
  
  if (now - (plant.lastAttackedTime || 0) > attackInterval) {
    plant.health -= zombie.damage;
    plant.lastAttackedTime = now;
    
    // 检查植物是否死亡
    if (plant.health <= 0) {
      removePlant(plant);
    }
  }
}

// 移除植物
function removePlant(plant) {
  // 从游戏状态中移除
  gameState.plants = gameState.plants.filter(p => p.id !== plant.id);
  
  // 清除单元格
  const cell = elements.gameGrid.querySelector(`[data-row="${plant.row}"][data-col="${plant.col}"]`);
  if (cell) {
    cell.innerHTML = '';
  }
}

// 植物攻击
function plantsAttack() {
  if (!gameState.isRunning || gameState.isPaused) return;
  
  gameState.plants.forEach(plant => {
    if (plantTypes[plant.type].attack && !plantTypes[plant.type].isExplosive) {
      const now = Date.now();
      const attackRate = plantTypes[plant.type].attackRate || config.plantAttackRate;
      
      if (now - plant.lastAttackTime > attackRate) {
        // 寻找同一行前面的僵尸
        const zombiesInRow = gameState.zombies.filter(zombie => 
          zombie.row === plant.row && 
          zombie.x > plant.col * (elements.gameContainer.clientWidth / config.gridSize.cols)
        );
        
        if (zombiesInRow.length > 0) {
          // 找到最前面的僵尸
          const closestZombie = zombiesInRow.reduce((closest, zombie) => 
            zombie.x < closest.x ? zombie : closest
          );
          
          // 发射豌豆
          shootPea(plant, closestZombie);
          plant.lastAttackTime = now;
        }
      }
    }
  });
}

// 发射豌豆
function shootPea(plant, target) {
  const pea = {
    id: Date.now(),
    row: plant.row,
    x: (plant.col + 0.5) * (elements.gameContainer.clientWidth / config.gridSize.cols),
    damage: plantTypes[plant.type].damage || 20,
    targetRow: target.row
  };
  
  gameState.peas.push(pea);
  
  // 渲染豌豆
  renderPea(pea);
}

// 渲染豌豆
function renderPea(pea) {
  // 移除已存在的相同ID的豌豆元素
  const existingPea = document.querySelector(`.pea[data-pea-id="${pea.id}"]`);
  if (existingPea) {
    existingPea.remove();
  }
  
  // 创建豌豆元素
  const peaElement = document.createElement('div');
  peaElement.className = 'pea absolute w-4 h-4 bg-green-500 rounded-full';
  peaElement.style.left = `${pea.x - 2}px`; // 居中
  peaElement.style.top = `${(pea.row * 100) + 40}px`; // 行中间
  peaElement.dataset.peaId = pea.id;
  
  elements.gameContainer.appendChild(peaElement);
}

// 移动豌豆
function movePeas() {
  if (!gameState.isRunning || gameState.isPaused) return;
  
  const remainingPeas = [];
  
  gameState.peas.forEach(pea => {
    // 移动豌豆
    const cellWidth = elements.gameContainer.clientWidth / config.gridSize.cols;
    pea.x += (config.peaSpeed * cellWidth) / 100; // 每帧移动的距离
    
    // 检查是否击中僵尸
    const hitZombie = gameState.zombies.find(zombie => 
      zombie.row === pea.targetRow && 
      Math.abs(zombie.x - pea.x) < 30 // 碰撞检测阈值
    );
    
    if (hitZombie) {
      // 伤害僵尸
      hitZombie.health -= pea.damage;
      
      // 检查僵尸是否死亡
      if (hitZombie.health <= 0) {
        killZombie(hitZombie);
      } else {
        // 更新僵尸显示
        renderZombie(hitZombie);
      }
      
      // 移除豌豆
      const peaElement = document.querySelector(`.pea[data-pea-id="${pea.id}"]`);
      if (peaElement) {
        peaElement.remove();
      }
    } else if (pea.x < elements.gameContainer.clientWidth) {
      // 更新豌豆位置
      renderPea(pea);
      remainingPeas.push(pea);
    } else {
      // 豌豆超出屏幕，移除
      const peaElement = document.querySelector(`.pea[data-pea-id="${pea.id}"]`);
      if (peaElement) {
        peaElement.remove();
      }
    }
  });
  
  gameState.peas = remainingPeas;
}

// 杀死僵尸
function killZombie(zombie) {
  // 增加分数和消灭僵尸计数
  gameState.score += zombie.value;
  gameState.zombiesKilled += 1;
  
  // 更新关卡进度
  updateLevelProgress();
  
  // 移除僵尸元素
  const zombieElement = document.querySelector(`.zombie[data-zombie-id="${zombie.id}"]`);
  if (zombieElement) {
    zombieElement.remove();
  }
  
  // 更新最高分
  if (gameState.score > gameState.highScore) {
    gameState.highScore = gameState.score;
    saveGameData();
  }
  
  // 更新UI
  updateUI();
}

// 更新关卡进度
function updateLevelProgress() {
  // 每杀死10个僵尸升一级
  const newLevel = Math.floor(gameState.zombiesKilled / 10) + 1;
  if (newLevel > gameState.currentLevel) {
    gameState.currentLevel = newLevel;
    // 每升一级增加50阳光
    gameState.sunPoints += 50;
    updateUI();
  }
  
  // 更新进度条
  const progress = (gameState.zombiesKilled % 10) / 10 * 100;
  gameState.levelProgress = progress;
  elements.levelProgress.style.width = `${progress}%`;
}

// 生成阳光
function generateSun() {
  if (!gameState.isRunning || gameState.isPaused) return;
  
  // 自动生成阳光
  if (Math.random() < 0.3) { // 30%的概率生成阳光
    const sun = {
      id: Date.now(),
      x: Math.random() * elements.gameContainer.clientWidth * 0.8 + elements.gameContainer.clientWidth * 0.1, // 屏幕内随机位置
      y: 0,
      value: config.sunValue,
      collected: false
    };
    
    gameState.suns.push(sun);
    
    // 渲染阳光
    renderSun(sun);
  }
  
  // 向日葵生成阳光
  gameState.plants.forEach(plant => {
    if (plant.type === 'sunflower') {
      const now = Date.now();
      if (now - plant.lastSunGenerationTime > plantTypes.sunflower.generateSunRate) {
        const sun = {
          id: Date.now(),
          x: (plant.col + 0.5) * (elements.gameContainer.clientWidth / config.gridSize.cols),
          y: (plant.row) * 100 + 50,
          value: config.sunValue,
          collected: false
        };
        
        gameState.suns.push(sun);
        plant.lastSunGenerationTime = now;
        
        // 渲染阳光
        renderSun(sun);
      }
    }
  });
}

// 渲染阳光
function renderSun(sun) {
  // 移除已存在的相同ID的阳光元素
  const existingSun = document.querySelector(`.sun[data-sun-id="${sun.id}"]`);
  if (existingSun) {
    existingSun.remove();
  }
  
  if (sun.collected) return;
  
  // 创建阳光元素
  const sunElement = document.createElement('div');
  sunElement.className = 'sun absolute cursor-pointer animate-bounce';
  sunElement.style.left = `${sun.x - 15}px`; // 居中
  sunElement.style.top = `${sun.y - 15}px`; // 居中
  sunElement.innerHTML = `<i class="fa fa-sun-o text-2xl text-yellow-500"></i>`;
  sunElement.dataset.sunId = sun.id;
  
  // 添加点击收集事件
  sunElement.addEventListener('click', () => {
    collectSun(sun.id);
  });
  
  elements.gameContainer.appendChild(sunElement);
}

// 移动阳光
function moveSuns() {
  if (!gameState.isRunning || gameState.isPaused) return;
  
  const remainingSuns = [];
  
  gameState.suns.forEach(sun => {
    if (!sun.collected) {
      // 阳光下落
      sun.y += 1;
      
      // 检查是否到达地面
      if (sun.y < elements.gameContainer.clientHeight) {
        // 更新阳光位置
        renderSun(sun);
        remainingSuns.push(sun);
      }
    }
  });
  
  gameState.suns = remainingSuns;
}

// 收集阳光
function collectSun(sunId) {
  const sun = gameState.suns.find(s => s.id === sunId);
  if (sun && !sun.collected) {
    sun.collected = true;
    gameState.sunPoints += sun.value;
    
    // 移除阳光元素
    const sunElement = document.querySelector(`.sun[data-sun-id="${sunId}"]`);
    if (sunElement) {
      sunElement.remove();
    }
    
    // 更新UI
    updateUI();
  }
}

// 开始游戏
function startGame() {
  if (gameState.isRunning && !gameState.isPaused) return;
  
  if (gameState.isPaused) {
    // 继续游戏
    gameState.isPaused = false;
    // 调整开始时间，减去暂停的时间
    gameState.startTime = Date.now() - (gameState.elapsedTime * 1000);
    // 启动游戏循环
    gameState.gameInterval = setInterval(gameLoop, 50); // 每50ms更新一次
  } else {
    // 新游戏开始
    resetGame();
    gameState.isRunning = true;
    gameState.isPaused = false;
    gameState.startTime = Date.now();
    
    // 增加游戏次数
    gameState.playCount++;
    saveGameData();
    
    // 启动游戏循环
    gameState.gameInterval = setInterval(gameLoop, 50); // 每50ms更新一次
    // 启动阳光生成
    gameState.sunGenerationInterval = setInterval(generateSun, config.sunGenerationRate);
  }
  
  // 更新按钮状态
  elements.startButton.disabled = true;
  elements.pauseButton.disabled = false;
  elements.restartButton.disabled = false;
  
  // 更新UI
  updateUI();
}

// 游戏主循环
function gameLoop() {
  // 更新时间
  gameState.elapsedTime = Math.floor((Date.now() - gameState.startTime) / 1000);
  
  // 生成僵尸
  generateZombie();
  
  // 移动僵尸
  moveZombies();
  
  // 植物攻击
  plantsAttack();
  
  // 移动豌豆
  movePeas();
  
  // 移动阳光
  moveSuns();
  
  // 更新UI
  updateUI();
}

// 暂停游戏
function pauseGame() {
  if (!gameState.isRunning) return;
  
  if (!gameState.isPaused) {
    // 暂停游戏
    gameState.isPaused = true;
    clearInterval(gameState.gameInterval);
    clearInterval(gameState.sunGenerationInterval);
    
    // 更新按钮状态
    elements.startButton.disabled = false;
    elements.startButton.innerHTML = '<i class="fa fa-play"></i><span>继续游戏</span>';
  } else {
    // 继续游戏
    gameState.isPaused = false;
    // 调整开始时间，减去暂停的时间
    gameState.startTime = Date.now() - (gameState.elapsedTime * 1000);
    // 重新启动游戏循环
    gameState.gameInterval = setInterval(gameLoop, 50);
    // 启动阳光生成
    gameState.sunGenerationInterval = setInterval(generateSun, config.sunGenerationRate);
    
    // 更新按钮状态
    elements.startButton.disabled = true;
    elements.startButton.innerHTML = '<i class="fa fa-play"></i><span>开始游戏</span>';
  }
}

// 重新开始游戏
function restartGame() {
  // 清除游戏循环
  clearInterval(gameState.gameInterval);
  clearInterval(gameState.sunGenerationInterval);
  
  // 隐藏游戏结束遮罩
  elements.gameOverOverlay.classList.add('hidden');
  
  // 重置游戏
  resetGame();
  
  // 开始新游戏
  startGame();
}

// 重置游戏
function resetGame() {
  // 重置游戏状态
  gameState.isRunning = false;
  gameState.isPaused = false;
  gameState.currentLevel = 1;
  gameState.levelProgress = 0;
  gameState.score = 0;
  gameState.sunPoints = 50;
  gameState.zombiesKilled = 0;
  gameState.selectedPlant = null;
  gameState.plants = [];
  gameState.zombies = [];
  gameState.peas = [];
  gameState.suns = [];
  gameState.lastZombieGeneration = 0;
  gameState.elapsedTime = 0;
  
  // 清除游戏容器中的所有元素
  const gameElements = elements.gameContainer.querySelectorAll('.zombie, .pea, .sun');
  gameElements.forEach(el => el.remove());
  
  // 重新渲染网格
  renderGrid();
  
  // 重置按钮状态
  elements.startButton.disabled = false;
  elements.pauseButton.disabled = true;
  elements.restartButton.disabled = true;
  elements.startButton.innerHTML = '<i class="fa fa-play"></i><span>开始游戏</span>';
  
  // 取消植物选择
  const plantCards = elements.plantSelection.querySelectorAll('.plant-card');
  plantCards.forEach(c => c.classList.remove('ring-2', 'ring-primary'));
  
  // 更新UI
  updateUI();
}

// 结束游戏
function endGame() {
  // 清除游戏循环
  clearInterval(gameState.gameInterval);
  clearInterval(gameState.sunGenerationInterval);
  
  // 更新游戏状态
  gameState.isRunning = false;
  
  // 显示游戏结束遮罩
  elements.finalScore.textContent = gameState.score;
  elements.finalLevel.textContent = gameState.currentLevel;
  elements.finalZombies.textContent = gameState.zombiesKilled;
  elements.gameOverOverlay.classList.remove('hidden');
  
  // 更新按钮状态
  elements.startButton.disabled = false;
  elements.pauseButton.disabled = true;
  elements.restartButton.disabled = true;
  
  // 保存游戏数据
  saveGameData();
}

// 更新UI显示
function updateUI() {
  elements.score.textContent = gameState.score;
  elements.sunPoints.textContent = gameState.sunPoints;
  elements.zombiesKilled.textContent = gameState.zombiesKilled;
  elements.currentLevel.textContent = gameState.currentLevel;
  elements.levelProgress.style.width = `${gameState.levelProgress}%`;
}

// 保存游戏数据到本地存储
function saveGameData() {
  const data = {
    highScore: gameState.highScore,
    playCount: gameState.playCount
  };
  localStorage.setItem('plantsVsZombiesData', JSON.stringify(data));
}

// 从本地存储加载游戏数据
function loadGameData() {
  const data = localStorage.getItem('plantsVsZombiesData');
  if (data) {
    try {
      const parsedData = JSON.parse(data);
      gameState.highScore = parsedData.highScore || 0;
      gameState.playCount = parsedData.playCount || 0;
    } catch (error) {
      console.error('加载游戏数据失败:', error);
    }
  }
}

// 设置事件监听器
function setupEventListeners() {
  // 游戏控制按钮
  elements.startButton.addEventListener('click', startGame);
  elements.pauseButton.addEventListener('click', pauseGame);
  elements.restartButton.addEventListener('click', restartGame);
  elements.playAgainButton.addEventListener('click', restartGame);
  
  // 移动端菜单
  elements.menuToggle.addEventListener('click', () => {
    elements.mobileMenu.classList.toggle('hidden');
  });
  
  // 响应式处理
  window.addEventListener('resize', () => {
    // 重新渲染游戏元素以适应新的尺寸
    gameState.plants.forEach(plant => renderPlant(plant));
    gameState.zombies.forEach(zombie => renderZombie(zombie));
    gameState.peas.forEach(pea => renderPea(pea));
    gameState.suns.forEach(sun => renderSun(sun));
  });
  
  // 键盘控制
  document.addEventListener('keydown', handleKeyDown);
}

// 处理键盘按键
function handleKeyDown(event) {
  // 检查是否是组合键（如Alt+左箭头用于浏览器后退），如果是，则不阻止默认行为
  if (event.altKey || event.ctrlKey || event.metaKey) {
    return;
  }
  
  switch (event.key.toLowerCase()) {
    case ' ': // 空格开始/暂停
      if (gameState.isRunning) {
        pauseGame();
      } else {
        startGame();
      }
      break;
    case 'r': // R键重新开始
      restartGame();
      break;
  }
}

// 当页面加载完成时初始化游戏
window.addEventListener('load', initGame);